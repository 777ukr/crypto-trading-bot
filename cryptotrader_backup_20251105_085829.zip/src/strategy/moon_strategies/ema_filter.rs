//! EMA фильтр и стратегия с CustomEMA условиями
//! Placeholder - полная реализация в разработке

pub struct EmaFilter;
pub struct EmaFilterCondition;

