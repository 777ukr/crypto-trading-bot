//! Spread стратегия - активные торги в зоне
//! Placeholder - полная реализация в разработке

pub struct SpreadStrategy;
pub struct SpreadConfig;
pub struct SpreadSignal;

