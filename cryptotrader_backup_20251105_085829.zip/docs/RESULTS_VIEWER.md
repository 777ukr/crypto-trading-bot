# 📊 Просмотр результатов для инвестора и трейдера

## Быстрый старт

### Просмотр всех результатов:
```bash
cargo run --bin view_results -- --all
```

### Просмотр последнего файла:
```bash
cargo run --bin view_results
```

### Просмотр конкретного файла:
```bash
cargo run --bin view_results -- -f sol_backtest.csv
```

### Только статистика (без деталей):
```bash
cargo run --bin view_results -- -f sol_backtest.csv --summary
```

## 📁 Структура файлов результатов

Все результаты сохраняются в директории `data/`:

### 1. Цены (Price History)
**Файл:** `data/sol_prices.csv`
**Формат:**
```csv
timestamp,price
1704067200,100.50
1704067300,101.20
```

**Что показывает:**
- Историю цен за период
- Минимум, максимум, среднее
- Волатильность

### 2. Результаты бэктеста (Backtest Results)
**Файл:** `data/sol_backtest.csv`
**Формат:**
```csv
entry_time,entry_price,exit_time,exit_price,side,pnl,pnl_percent
1704067200,100.00,1704068100,104.00,long,4.00,4.00
```

**Что показывает:**
- Все сделки (вход/выход)
- P&L по каждой сделке
- Win rate, profit factor
- Средняя прибыль/убыток

### 3. Отчеты стратегии (Strategy Reports)
**Файл:** `data/strategy_report_*.txt`
**Формат:** Текстовый отчет с анализом

**Что показывает:**
- Оценку стратегии (0-100)
- Сильные/слабые стороны
- Рекомендации по улучшению

## 📊 Ключевые метрики для инвестора

### Производительность:
- **Total P&L** - общая прибыль/убыток в $
- **Win Rate** - процент прибыльных сделок
- **Profit Factor** - отношение прибыли к убыткам (>1.5 = хорошо)
- **Sharpe Ratio** - риск-скорректированная доходность (>1.0 = хорошо)
- **Max Drawdown** - максимальная просадка (<20% = хорошо)

### Стабильность:
- **Consecutive Wins/Losses** - серии прибылей/убытков
- **Average Win vs Loss** - соотношение средних сделок
- **Trade Frequency** - частота сделок

## 🎯 Что смотреть трейдеру

### 1. Входные точки:
- Когда открывались позиции?
- При каких условиях?
- Правильно ли работают сигналы?

### 2. Выходные точки:
- Закрывались ли позиции вовремя?
- Работают ли стоп-лоссы?
- Фиксируется ли прибыль?

### 3. Паттерны:
- В какое время лучше торговать?
- Какие условия чаще приводят к прибыли?
- Где возникают убытки?

## 📈 Примеры использования

### Просмотр всех результатов:
```bash
$ cargo run --bin view_results -- --all

📁 Available result files:

  1. sol_backtest.csv (2.3 KB) - 2024-01-15 10:30:00
  2. sol_prices.csv (15.2 KB) - 2024-01-15 10:25:00

📊 Trading Results Viewer

💰 Backtest Results

  📊 Performance Summary:
    Total Trades: 15
    Wins: 10 | Losses: 5
    Win Rate: 66.7%
    Total P&L: $125.50
    Avg Win: $18.50
    Avg Loss: -$12.00
    Profit Factor: 3.08
```

### Детальный просмотр:
```bash
$ cargo run --bin view_results -- -f sol_backtest.csv

💰 Backtest Results

  📊 Performance Summary:
    ...
  
  📋 Recent Trades (last 10):
    ✅ Trade 1: long 100.50→104.20 $3.70
    ✅ Trade 2: long 99.80→102.10 $2.30
    ❌ Trade 3: long 103.00→101.50 -$1.50
    ...
```

## 🔍 Анализ CSV файлов вручную

### Excel/Google Sheets:
1. Откройте CSV файл
2. Используйте фильтры для анализа
3. Постройте графики P&L

### Python (опционально):
```python
import pandas as pd

# Загрузка данных
df = pd.read_csv('data/sol_backtest.csv')

# Анализ
print(f"Win Rate: {(df['pnl'] > 0).mean() * 100:.1f}%")
print(f"Total P&L: ${df['pnl'].sum():.2f}")
print(f"Avg Win: ${df[df['pnl'] > 0]['pnl'].mean():.2f}")
print(f"Avg Loss: ${df[df['pnl'] < 0]['pnl'].mean():.2f}")
```

## 📝 Интерпретация результатов

### Хорошие показатели:
- ✅ Win Rate > 55%
- ✅ Profit Factor > 2.0
- ✅ Sharpe Ratio > 1.5
- ✅ Max Drawdown < 15%

### Требуют улучшения:
- ⚠️ Win Rate < 50% → улучшить входы
- ⚠️ Profit Factor < 1.5 → улучшить риск/награду
- ⚠️ Max Drawdown > 25% → усилить риск-менеджмент

## 🚀 Автоматизация

Создайте алиас для быстрого просмотра:
```bash
# В ~/.bashrc или ~/.zshrc
alias view-results='cargo run --bin view_results -- --all'
alias view-latest='cargo run --bin view_results'
```

## 📌 Следующие шаги

1. **Запустите бэктест:**
   ```bash
   cargo run --bin sol_backtest
   ```

2. **Просмотрите результаты:**
   ```bash
   cargo run --bin view_results -- --all
   ```

3. **Анализируйте CSV файлы** в Excel/Python

4. **Проверьте отчеты** стратегии для рекомендаций

