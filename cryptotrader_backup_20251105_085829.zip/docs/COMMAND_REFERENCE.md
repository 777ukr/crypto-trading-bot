# 🎯 Справочник команд для анализа

## 📊 Основные команды

### 1. Реальный анализ торговли (ГЛАВНАЯ КОМАНДА)
```bash
cargo run --bin gate_real_analysis --features gate_exec
```

**Что делает:**
- Получает реальный депозит с Gate.io (1250 USDT)
- Получает комиссию Gate.io
- Получает историю сделок за 2-3 дня
- Анализирует канальную торговлю с учетом:
  - Комиссии (Maker 0.015%, Taker 0.05%)
  - Плеча x100
  - Стоп-лоссов в канале
- Рассчитывает P&L для каждой сделки
- Сравнивает симуляцию с реальными сделками
- Сохраняет результаты в CSV

**Вывод показывает:**
- Текущий депозит на Gate.io
- Количество реальных сделок за период
- Сколько было бы прибыли/убытка при торговле в канале
- Сколько сработок стоп-лосса
- Сравнение с реальной торговлей

### 2. Просмотр результатов
```bash
cargo run --bin view_results -- --all
cargo run --bin view_results -f data/channel_analysis.csv
```

### 3. Веб-дашборд
```bash
cargo run --bin dashboard_server --features dashboard
```
Затем откройте: http://localhost:8080

### 4. Бэктест SOL
```bash
cargo run --bin sol_backtest
```

### 5. Онлайн мониторинг
```bash
cargo run --bin online_monitor
```

## 📋 Пример вывода

```
🔍 Gate.io Real Trading Analysis

============================================================
STEP 1: Fetching Real Data from Gate.io
============================================================

💰 Current Deposit:
  Total: $1250.00
  Available: $1200.00
  Locked: $50.00

💳 Commission Rate:
  Maker: 0.0150%
  Taker: 0.0500%
  Using: 0.0325% (average)

📈 Fetching Trade History (last 3 days)...
  Found 15 trades

============================================================
STEP 2: Channel Trading Analysis
============================================================

📊 Fetching historical price data...
  Loaded 72 price points

============================================================
STEP 3: Analysis Results
============================================================

📊 Channel Trading Analysis:
  Initial Deposit: $1250.00
  Final Balance: $1285.50
  ROI: 2.84%

  Total Trades: 8
  Wins: 5 | Losses: 3
  Win Rate: 62.5%

  P&L Before Fees: $40.50
  Total Fees: $5.00
  P&L After Fees: $35.50

  Profit Factor: 2.15
  Max Drawdown: 3.20%
  Stop-Loss Triggers: 2

  Recent Trades:
    ✅ Trade 1: long 110000→110500 | P&L: $12.50 | Fee: $0.71
    ❌ Trade 2: long 110200→109800 | P&L: -$8.00 | Fee: $0.71
    ...

============================================================
STEP 4: Real Trades Comparison
============================================================

📋 Real Trades Summary:
  Total real trades: 15
  Real P&L: $32.50
  Real Wins: 10 | Losses: 5

📊 Comparison:
  Simulated P&L: $35.50
  Real P&L: $32.50
  Difference: $3.00
```

## 🎯 Что вы получаете

### Для инвестора:
1. **ROI** - доходность стратегии
2. **Total P&L** - общая прибыль/убыток
3. **Win Rate** - процент прибыльных сделок
4. **Profit Factor** - отношение прибыли к убыткам
5. **Max Drawdown** - максимальная просадка

### Для трейдера:
1. **Все сделки** - детали каждой сделки
2. **Сработки стоп-лосса** - сколько раз сработал стоп
3. **Комиссия** - сколько потрачено на комиссии
4. **P&L до/после комиссии** - влияние комиссии
5. **Сравнение** - симуляция vs реальность

## 📁 Выходные файлы

- `data/channel_analysis.csv` - детали всех сделок
- Все результаты доступны в веб-дашборде

## 💡 Использование

1. **Запустите анализ:**
   ```bash
   cargo run --bin gate_real_analysis --features gate_exec
   ```

2. **Просмотрите результаты:**
   ```bash
   cargo run --bin view_results -f data/channel_analysis.csv
   ```

3. **Откройте в дашборде:**
   ```bash
   cargo run --bin dashboard_server --features dashboard
   ```
   http://localhost:8080

## 🔧 Настройка параметров

Отредактируйте в `src/bin/gate_real_analysis.rs`:
- Плечо (leverage): 100.0
- Ширина канала: 1.0%
- Стоп-лосс: 2.0%
- Тейк-профит: 4.0%

