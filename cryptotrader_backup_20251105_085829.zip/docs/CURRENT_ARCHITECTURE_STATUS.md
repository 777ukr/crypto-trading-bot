# 📊 Текущая архитектура vs SaaS архитектура

## ❓ Ваш вопрос:

> "Такое у нас применено? чтобы инвесторы могли выбирать стратегии и сохранять себе чтобы делать типа как заказ магазин и чтобы мы подключали его API ключи и отторговывали и допиливали индивидуальные стратегии под клиента?"

## ✅ ЧТО У НАС ЕСТЬ СЕЙЧАС:

### Структура проекта:
```
cryptotrader.com/
├── src/
│   ├── bin/
│   │   ├── investor_portal.rs    ✅ Веб-портал (Axum)
│   │   ├── investor_demo.rs      ✅ Бэктест-раннер
│   │   └── investor_dashboard.rs  ✅ Простой дашборд
│   ├── strategy/                  ✅ 5+ стратегий
│   ├── database/                 ✅ PostgreSQL интеграция
│   └── utils/                    ✅ Комиссии с rebate
└── templates/                     ✅ HTML шаблоны
```

**Статус:** ✅ **Простая структура, все в одном проекте**

### Что работает:
- ✅ Выбор стратегий через веб-интерфейс
- ✅ Выбор плеча (3x-125x)
- ✅ Запуск бэктестов
- ✅ Визуализация результатов
- ✅ Сохранение в PostgreSQL

### Что НЕ работает (SaaS функции):
- ❌ **Multi-tenant** - нет разделения по клиентам
- ❌ **API ключи клиентов** - нет хранения и управления
- ❌ **Аутентификация** - нет системы пользователей
- ❌ **Индивидуальные стратегии** - нет кастомизации под клиента
- ❌ **Trading sessions** - нет запуска live торговли от имени клиента

---

## 🏗️ ЧТО НУЖНО ДЛЯ SaaS (как у 3Commas/Cryptohopper):

### 1. Архитектура:

**Текущая (простая):**
```
investor_portal (Axum)
    ↓
investor_demo (бэктесты)
    ↓
PostgreSQL
```

**Нужна для SaaS (разделенная):**
```
┌─────────────────┐
│  Frontend       │ React или Rocket
│  (Dashboard)    │
└────────┬────────┘
         │ REST/WebSocket
         ↓
┌─────────────────┐
│  Backend API    │ Actix
│  (Auth, Orders) │
└────────┬────────┘
         │
         ├──→ Redis Queue
         │      ↓
         │   ┌──────────────┐
         │   │ Worker       │ Tokio
         │   │ (Backtests,  │
         │   │  Trading)    │
         │   └──────────────┘
         ↓
┌─────────────────┐
│  PostgreSQL     │ Multi-tenant БД
│  (Users,        │
│   Strategies)   │
└─────────────────┘
```

### 2. База данных для SaaS:

```sql
-- Пользователи (клиенты)
CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  email TEXT UNIQUE,
  password_hash TEXT,
  subscription_tier TEXT, -- 'free', 'pro', 'enterprise'
  created_at TIMESTAMP
);

-- Биржевые аккаунты клиентов (API ключи)
CREATE TABLE exchange_accounts (
  id SERIAL PRIMARY KEY,
  user_id INT REFERENCES users(id),
  exchange TEXT, -- 'gateio'
  api_key_encrypted TEXT, -- AES-256 шифрование
  api_secret_encrypted TEXT,
  is_active BOOLEAN,
  permissions TEXT[], -- ['read', 'trade']
  created_at TIMESTAMP
);

-- Стратегии клиентов
CREATE TABLE custom_strategies (
  id SERIAL PRIMARY KEY,
  user_id INT REFERENCES users(id),
  name TEXT,
  base_strategy TEXT, -- 'ema_reversal', 'channel_split'
  config JSONB, -- Параметры: dip_levels, leverage, etc.
  is_active BOOLEAN,
  created_at TIMESTAMP
);

-- Торговые сессии (боты клиентов)
CREATE TABLE trading_sessions (
  id SERIAL PRIMARY KEY,
  user_id INT REFERENCES users(id),
  exchange_account_id INT REFERENCES exchange_accounts(id),
  strategy_id INT REFERENCES custom_strategies(id),
  symbol TEXT,
  leverage INT,
  status TEXT, -- 'running', 'stopped'
  current_balance NUMERIC,
  total_pnl NUMERIC,
  started_at TIMESTAMP
);
```

### 3. API для SaaS:

**Backend (Actix):**
```
POST /api/v1/auth/register          # Регистрация
POST /api/v1/auth/login             # Вход
GET  /api/v1/users/me               # Текущий пользователь

POST /api/v1/accounts/exchange      # Добавить Gate.io аккаунт
GET  /api/v1/accounts/exchange      # Список аккаунтов
DELETE /api/v1/accounts/:id         # Удалить аккаунт

POST /api/v1/strategies             # Создать стратегию
GET  /api/v1/strategies             # Мои стратегии
PUT  /api/v1/strategies/:id         # Обновить
DELETE /api/v1/strategies/:id       # Удалить

POST /api/v1/trading/start          # Запустить бота
POST /api/v1/trading/stop          # Остановить
GET  /api/v1/trading/sessions      # Активные сессии

POST /api/v1/backtest/run          # Бэктест
GET  /api/v1/backtest/:id          # Результаты

WebSocket: /ws/trading/:user_id    # Live обновления
```

**Dashboard (Rocket/React):**
```
GET /dashboard/              # Главная
GET /dashboard/strategies    # Стратегии
GET /dashboard/create        # Создать стратегию
GET /dashboard/trading       # Live торговля
GET /dashboard/settings      # Настройки (API ключи)
```

### 4. Как это работает (поток):

```
1. Клиент регистрируется → создается user в БД
   ↓
2. Клиент добавляет Gate.io API ключи → шифруются и сохраняются
   ↓
3. Клиент выбирает стратегию (или создает свою) → сохраняется в custom_strategies
   ↓
4. Клиент настраивает параметры (символ, плечо) → config JSON
   ↓
5. Клиент нажимает "Запустить" → создается trading_session
   ↓
6. Worker берет задачу из очереди → расшифровывает API ключи
   ↓
7. Worker подключается к Gate.io от имени клиента → торгует по стратегии
   ↓
8. Результаты сохраняются в БД → клиент видит через WebSocket
   ↓
9. Клиент может остановить/изменить в любой момент
```

### 5. Индивидуальные стратегии:

**Вариант А: Параметризация (проще):**
- Базовая стратегия EMA Reversal
- Клиент настраивает: `dip_levels: [0.3, 0.5, 0.8]`, `leverage: 100`, `stop_loss: 0.5`
- Каждый набор = уникальная стратегия

**Вариант Б: Визуальный редактор (сложнее):**
- Drag-and-drop блоки (условия, действия)
- Генерация кода стратегии
- Компиляция или интерпретация

**Вариант В: API для программистов:**
- Клиент пишет стратегию на Rust/Python
- Загружает через API
- Система компилирует и запускает

---

## 💡 МОЯ РЕКОМЕНДАЦИЯ:

### **СЕЙЧАС (Этап 1):**
✅ Оставить простую структуру  
✅ Доделать работающее демо  
✅ Показать инвестору  

**Структура:** `src/bin/` (все в одном проекте)

### **ПОТОМ (Этап 2):**
✅ Рефакторинг в backend/dashboard/shared  
✅ Multi-tenant БД  
✅ Аутентификация  
✅ Управление API ключами  

**Структура:**
```
project/
├── backend/     # Actix API
├── dashboard/   # Rocket веб-панель  
├── shared/      # Общие модули
└── worker/      # Tokio воркеры
```

---

## ❓ ОТВЕТ НА ВАШИ ВОПРОСЫ:

### 1. "Такое у нас применено?"
**НЕТ** - пока простая структура, не SaaS-ready

### 2. "Можем ли делать как магазин?"
**ДА, но нужно добавить:**
- Multi-tenant БД
- Аутентификацию
- Управление API ключами
- Trading sessions

### 3. "Подключать API ключи и торговать?"
**ДА, но нужно:**
- Шифрование ключей
- Worker для торговли
- Подключение к бирже от имени клиента

### 4. "Индивидуальные стратегии?"
**ДА** - ваша EMA стратегия как база + параметризация для клиентов

---

## 🎯 ПЛАН ДЕЙСТВИЙ:

### СЕЙЧАС (1-2 дня):
1. ✅ Исправить ошибки компиляции
2. ✅ Интегрировать EMA стратегию
3. ✅ Добавить учет rebate
4. ✅ Протестировать портал
5. ✅ Показать инвестору

### ПОТОМ (2-4 недели):
1. Рефакторинг в модульную структуру
2. Multi-tenant БД
3. Аутентификация
4. API ключи клиентов
5. Trading sessions

**Готов продолжить в любом направлении!** 🚀



