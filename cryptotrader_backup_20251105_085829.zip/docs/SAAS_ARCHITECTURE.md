# 🏢 SaaS Architecture для Trading Bot

## Как работают успешные SaaS боты

### 1. Архитектура типичного SaaS бота:

```
┌─────────────┐
│   Client    │ → Browser
└──────┬──────┘
       │ HTTPS
       ↓
┌─────────────────────────────────┐
│      Frontend (React/Rocket)     │
│  - Dashboard                     │
│  - Strategy selection             │
│  - Results visualization          │
└──────┬────────────────────────────┘
       │
       │ REST API / WebSocket
       ↓
┌─────────────────────────────────┐
│      Backend (Actix)             │
│  - Authentication                │
│  - Strategy management           │
│  - Backtest orchestration        │
│  - Trading session control       │
└──────┬────────────────────────────┘
       │
       ├──→ Redis Queue
       │      ↓
       │   ┌─────────────────┐
       │   │ Worker (Tokio)   │
       │   │ - Backtests      │
       │   │ - Live trading   │
       │   └─────────────────┘
       │
       ↓
┌─────────────────────────────────┐
│   PostgreSQL                     │
│  - Users                         │
│  - Strategies                    │
│  - Trading sessions              │
│  - Results                       │
└─────────────────────────────────┘
       │
       ↓ (Encrypted)
┌─────────────────────────────────┐
│   Exchange API (Gate.io)         │
│  - Using client's API keys       │
└─────────────────────────────────┘
```

## Ключевые компоненты SaaS

### 1. Multi-Tenancy (множественные клиенты)

**Каждый клиент:**
- Имеет свой аккаунт
- Хранит свои API ключи (зашифрованные)
- Видит только свои стратегии и результаты
- Может запускать несколько ботов одновременно

### 2. Безопасность API ключей

```rust
// Шифрование перед сохранением
use aes_gcm::Aes256Gcm;
use rand::Rng;

pub fn encrypt_api_key(key: &str, master_key: &[u8; 32]) -> Vec<u8> {
    // AES-256-GCM шифрование
    // Никогда не хранить в открытом виде
}

pub fn decrypt_api_key(encrypted: &[u8], master_key: &[u8; 32]) -> String {
    // Расшифровка только при использовании
}
```

**Важно:**
- API ключи шифруются при сохранении
- Расшифровка только в памяти воркера
- Используются только для запросов к бирже
- Логи не содержат ключей

### 3. Управление стратегиями

**Типы стратегий:**
1. **Встроенные** - предоставлены платформой (EMA, Channel, Market Making)
2. **Кастомные** - клиент создает через UI или API
3. **Marketplace** - стратегии других трейдеров (платные/бесплатные)

**Параметры стратегии:**
```json
{
  "type": "ema_reversal",
  "params": {
    "dip_levels": [0.3, 0.5, 0.8],
    "leverage": 100,
    "stop_loss": 0.5,
    "take_profit": [1.0, 2.0, 3.0]
  },
  "risk_limits": {
    "max_position_size": 1000,
    "max_daily_loss": 100
  }
}
```

### 4. Trading Session Management

```rust
pub struct TradingSession {
    pub user_id: i64,
    pub strategy_id: i64,
    pub exchange_account_id: i64,
    pub symbol: String,
    pub leverage: i32,
    pub status: SessionStatus,
    pub started_at: DateTime<Utc>,
    pub current_balance: Decimal,
    pub total_pnl: Decimal,
}

pub enum SessionStatus {
    Running,
    Paused,
    Stopped,
    Error(String),
}
```

**Управление сессиями:**
- Клиент запускает через UI
- Worker берет задачу из очереди
- Подключается к бирже через API ключи клиента
- Торгует согласно стратегии
- Сохраняет результаты в БД
- Клиент видит live обновления через WebSocket

### 5. Индивидуальные стратегии для клиентов

**Подход 1: Визуальный редактор (сложнее)**
- Drag-and-drop блоки
- Условия: "Если EMA(12) > EMA(26) и RSI < 30"
- Действия: "Купить 10% баланса, стоп 0.5%"
- Сохранение в JSON конфиг

**Подход 2: Текстовый/API (проще)**
- Клиент описывает логику текстом или JSON
- Парсим и генерируем код стратегии
- Компилируем в runtime или интерпретируем

**Подход 3: Готовые шаблоны + параметры (рекомендую)**
- Базовая стратегия EMA Reversal
- Клиент настраивает: уровни просадки, плечо, стопы
- Каждый набор параметров = новая стратегия

### 6. Интеграция с биржами

```rust
pub struct ExchangeAccount {
    pub user_id: i64,
    pub exchange: Exchange, // Gate.io, Binance, etc.
    pub api_key_encrypted: Vec<u8>,
    pub api_secret_encrypted: Vec<u8>,
    pub permissions: Vec<Permission>, // ["read", "trade"]
    pub is_active: bool,
}

// При запуске торговли:
// 1. Расшифровать ключи
// 2. Создать клиент биржи
// 3. Запустить стратегию
// 4. Сохранять результаты
```

## 📊 План миграции к SaaS

### Шаг 1: Подготовка БД
```sql
-- Добавить таблицы для multi-tenant
ALTER TABLE backtest_results ADD COLUMN user_id INT;
ALTER TABLE strategies ADD COLUMN user_id INT;
-- и т.д.
```

### Шаг 2: Аутентификация
```rust
// Добавить JWT middleware
// Проверка user_id в каждом запросе
```

### Шаг 3: Разделение данных
```rust
// Все запросы фильтровать по user_id
// Клиент видит только свои данные
```

### Шаг 4: API ключи клиентов
```rust
// Интерфейс для добавления Gate.io API ключей
// Шифрование и сохранение
```

### Шаг 5: Trading Sessions
```rust
// Запуск торговли от имени клиента
// Использование его API ключей
```

## 💡 Рекомендации

### Для начала (сейчас):
✅ Оставить простую структуру  
✅ Сделать работающее демо  
✅ Показать инвестору  

### Для SaaS (потом):
✅ Добавить multi-tenant БД  
✅ Разделить на backend/dashboard  
✅ Аутентификация  
✅ Управление API ключами  

### Приоритет:
1. **Работающее демо** - чтобы показать ценность
2. **SaaS архитектура** - для масштабирования
3. **Индивидуальные стратегии** - для дифференциации



