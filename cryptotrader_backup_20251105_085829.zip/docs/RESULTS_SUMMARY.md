# 📊 Резюме: Просмотр результатов

## ✅ Создано

1. **Утилита просмотра**: `src/bin/view_results.rs`
2. **Полная документация**: `docs/RESULTS_VIEWER.md`
3. **Шпаргалка для инвестора**: `docs/INVESTOR_QUICK_GUIDE.md`

## 🚀 Использование

```bash
# Все файлы
cargo run --bin view_results -- --all

# Последний файл
cargo run --bin view_results

# Конкретный файл
cargo run --bin view_results -f sol_backtest.csv

# Только статистика
cargo run --bin view_results -f sol_backtest.csv --summary
```

## 📁 Структура файлов

Все результаты в `data/`:
- `*_prices.csv` - история цен
- `*_backtest.csv` - результаты торговли
- `strategy_report_*.txt` - анализ стратегии

## 📊 Что показывает

### Для инвестора:
- Total P&L (общая прибыль)
- Win Rate (процент прибыльных сделок)
- Profit Factor (отношение прибыли к убыткам)
- Sharpe Ratio (риск-скорректированная доходность)
- Max Drawdown (максимальная просадка)

### Для трейдера:
- Детали каждой сделки (вход/выход)
- Паттерны прибыльности
- Статистика по времени
- Рекомендации по улучшению

## 🎯 Быстрый старт

1. Запустите бэктест: `cargo run --bin sol_backtest`
2. Просмотрите результаты: `cargo run --bin view_results -- --all`
3. Откройте CSV в Excel для детального анализа

