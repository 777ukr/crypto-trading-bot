# SOL Бэктестер - Простой и быстрый

## Быстрый старт

### 1. Путь к файлу .env

**📍 Абсолютный путь:**
```
/home/crypto/sites/cryptotrader.com/.env
```

**Создание файла:**
```bash
cd /home/crypto/sites/cryptotrader.com
nano .env
```

**Содержимое .env:**
```
GATEIO_API_KEY=ваш_ключ_здесь
GATEIO_SECRET_KEY=ваш_секрет_здесь
```

### 2. Запуск бэктестера

```bash
cargo run --bin sol_backtest
```

### 3. Результаты

Файлы создаются в `data/`:
- `data/sol_prices.csv` - история цен SOL
- `data/sol_backtest.csv` - результаты симуляции торговли

## Формат файлов

### sol_prices.csv
```csv
timestamp,price
1704067200,98.50
1704067210,98.65
...
```

### sol_backtest.csv
```csv
entry_time,entry_price,exit_time,exit_price,side,pnl,pnl_percent
1704067200,98.50,1704068100,100.25,long,1.75,1.78
...
```

## Логика стратегии

- **Вход**: Покупка когда цена в нижней части канала (20 периодов)
- **Выход**: Продажа на верхней части канала или стоп-лосс -2%
- **Канал**: 2% от min/max за последние 20 свечей

## Вывод в консоль

```
🚀 SOL Backtest: Starting price collection...
12:00:10 | SOL: $98.50
12:00:20 | SOL: $98.65
...

📊 Backtest Summary:
  Total trades: 5
  Wins: 3
  Losses: 2
  Win rate: 60.0%
  Total P&L: $12.50
  Max drawdown: 3.25%

✅ Done! Results saved to:
  - data/sol_prices.csv
  - data/sol_backtest.csv
```

## Настройка

В файле `src/bin/sol_backtest.rs` можно изменить:
- `SYMBOL` - монета (по умолчанию "SOL_USDT")
- `duration` - время сбора данных (по умолчанию 1 час)
- `interval` - интервал сбора (по умолчанию 10 секунд)
- `channel_size` - размер канала (по умолчанию 2%)
- `window` - размер окна для канала (по умолчанию 20)

