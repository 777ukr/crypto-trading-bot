# 💰 Investor Dashboard

Веб-дашборд для визуализации результатов всех 3 стратегий (Channel Split, Market Making, HFT) на SOL, ETH, BTC.

## 🚀 Запуск

### 1. Сначала запустите backtest:

```bash
cargo run --bin investor_demo --features gate_exec
```

Это создаст файл `data/investor_demo_results.csv` с результатами.

### 2. Запустите веб-дашборд:

```bash
cargo run --bin investor_dashboard --features dashboard
```

## 🌐 Доступ к дашборду

После запуска откройте в браузере:

- **Локально**: http://localhost:8080
- **По сети**: http://<ваш-ip>:8080
- **IP сервера**: http://38.180.29.92:8080

## 📊 Что показывается

### Summary Cards
- Total Strategies (количество протестированных стратегий)
- Best Performance (лучший ROI)
- Average ROI (средний ROI по всем стратегиям)
- Total P&L (общая прибыль/убыток)

### Strategy Sections
Для каждой стратегии:
- ROI по символам (SOL, ETH, BTC)
- Общая статистика (P&L, количество сделок, Win Rate, Profit Factor, Max Drawdown)
- График ROI по символам

### Comparison Table
Сравнительная таблица всех результатов с фильтрацией по стратегии и символу.

## 🔄 Auto-refresh

Дашборд автоматически обновляется каждую минуту. Также есть кнопка "🔄 Refresh" в правом нижнем углу.

## 🛠 Технологии

- **Backend**: Rust + Axum (легкий, быстрый)
- **Frontend**: Чистый HTML/CSS/JavaScript
- **Charts**: Chart.js (без дополнительных зависимостей)
- **No Frameworks**: Минимализм, скорость, простота

## 📝 Примечания

- Дашборд читает данные из `data/investor_demo_results.csv`
- Если файл не найден, показывается сообщение с инструкцией
- Все данные в реальном времени из Gate.io API
- Учитываются комиссии и x100 плечо


