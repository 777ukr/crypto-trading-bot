# 🏗️ Архитектурный план: от MVP к SaaS

## 📊 Текущее состояние

### Текущая структура (MVP):
```
cryptotrader.com/
├── src/
│   ├── bin/           # Binaries (investor_demo, investor_dashboard, investor_portal)
│   ├── strategy/      # Все стратегии в одном месте
│   ├── database/      # PostgreSQL интеграция
│   ├── execution/     # Gate.io клиент
│   └── utils/         # Утилиты (gate_commission)
├── templates/         # HTML шаблоны
└── database/         # SQL схема
```

**Плюсы текущего подхода:**
- ✅ Простая структура
- ✅ Быстрый старт
- ✅ Легко тестировать
- ✅ Все в одном репозитории

**Минусы:**
- ❌ Нет разделения на модули
- ❌ Нет multi-tenant архитектуры
- ❌ Нет системы аккаунтов/клиентов
- ❌ Нет индивидуальных стратегий

## 🎯 План развития: 3 этапа

### Этап 1: Рабочее демо (СЕЙЧАС) ⏳

**Цель:** Работающий продукт для демонстрации инвестору

**Что делаем:**
- ✅ Веб-портал с выбором стратегий и плеча
- ✅ 5+ стратегий (включая вашу EMA Reversal)
- ✅ Бэктесты по 3 монетам
- ✅ Визуализация результатов
- ✅ Учет комиссий с rebate
- ✅ PostgreSQL для хранения

**Структура (простая):**
```
src/
├── bin/
│   ├── investor_portal.rs    # Веб-сервер (Axum)
│   └── investor_demo.rs      # Бэктест-раннер
├── strategy/                 # Все стратегии
├── database/                 # PostgreSQL
└── utils/                    # Комиссии, утилиты
```

**Срок:** Готово за 1-2 дня

---

### Этап 2: SaaS-ready архитектура (ЧЕРЕЗ 2-4 НЕДЕЛИ) 📅

**Цель:** Поддержка множественных клиентов с индивидуальными стратегиями

**Что добавляем:**

#### 2.1 Разделение на модули:
```
project/
├── backend/              # Actix API сервер
│   ├── handlers/        # API endpoints
│   ├── services/       # Бизнес-логика
│   └── main.rs
├── dashboard/          # Rocket веб-панель
│   ├── routes/         # Страницы
│   ├── components/     # UI компоненты
│   └── main.rs
├── shared/             # Общие модули
│   ├── models/         # Модели данных
│   ├── strategies/     # Все стратегии
│   └── database/       # DB слой
└── worker/             # Tokio воркеры
    ├── backtest/       # Бэктест-воркеры
    └── trading/        # Live trading воркеры
```

#### 2.2 Multi-tenant архитектура:

**Таблицы БД:**
```sql
-- Пользователи/клиенты
CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  email TEXT UNIQUE,
  api_key_hash TEXT,
  api_secret_hash TEXT,
  created_at TIMESTAMP,
  subscription_tier TEXT -- 'free', 'pro', 'enterprise'
);

-- Аккаунты на биржах (для каждого клиента)
CREATE TABLE exchange_accounts (
  id SERIAL PRIMARY KEY,
  user_id INT REFERENCES users(id),
  exchange TEXT, -- 'gateio', 'binance'
  api_key_encrypted TEXT,
  api_secret_encrypted TEXT,
  is_active BOOLEAN,
  created_at TIMESTAMP
);

-- Индивидуальные стратегии клиентов
CREATE TABLE custom_strategies (
  id SERIAL PRIMARY KEY,
  user_id INT REFERENCES users(id),
  name TEXT,
  strategy_type TEXT, -- 'ema_reversal', 'custom'
  config JSONB, -- Параметры стратегии
  is_active BOOLEAN,
  created_at TIMESTAMP
);

-- Торговые сессии (какая стратегия работает на каком аккаунте)
CREATE TABLE trading_sessions (
  id SERIAL PRIMARY KEY,
  user_id INT REFERENCES users(id),
  exchange_account_id INT REFERENCES exchange_accounts(id),
  strategy_id INT REFERENCES custom_strategies(id),
  symbol TEXT,
  leverage INT,
  status TEXT, -- 'running', 'stopped', 'paused'
  started_at TIMESTAMP,
  stopped_at TIMESTAMP
);

-- Результаты торговли по клиентам
CREATE TABLE user_trading_results (
  id SERIAL PRIMARY KEY,
  user_id INT REFERENCES users(id),
  session_id INT REFERENCES trading_sessions(id),
  timestamp TIMESTAMP,
  pnl NUMERIC,
  balance NUMERIC
);
```

#### 2.3 API структура:

**Backend (Actix):**
```rust
// POST /api/v1/auth/register
// POST /api/v1/auth/login
// GET /api/v1/users/me

// POST /api/v1/strategies          # Создать стратегию
// GET /api/v1/strategies           # Список стратегий клиента
// PUT /api/v1/strategies/:id        # Обновить стратегию
// DELETE /api/v1/strategies/:id    # Удалить

// POST /api/v1/accounts/exchange   # Добавить биржевой аккаунт
// GET /api/v1/accounts/exchange    # Список аккаунтов

// POST /api/v1/trading/start       # Запустить торговлю
// POST /api/v1/trading/stop        # Остановить
// GET /api/v1/trading/status       # Статус торговли

// POST /api/v1/backtest/run        # Запустить бэктест
// GET /api/v1/backtest/:id         # Результаты бэктеста
// WebSocket: /ws/trading/:user_id  # Live обновления
```

**Dashboard (Rocket):**
```
GET /dashboard/              # Главная страница
GET /dashboard/strategies    # Список стратегий
GET /dashboard/create        # Создать стратегию
GET /dashboard/backtest      # Бэктесты
GET /dashboard/trading       # Live торговля
GET /dashboard/results       # Результаты
```

#### 2.4 Безопасность:

- **Шифрование API ключей** (AES-256)
- **JWT токены** для аутентификации
- **Rate limiting** по подписке
- **Audit logs** всех действий
- **Multi-sign** для вывода средств (опционально)

---

### Этап 3: Индивидуальные стратегии (ДАЛЬШЕ) 🚀

**Цель:** Клиенты могут создавать свои стратегии через UI

**Что добавляем:**

#### 3.1 Визуальный редактор стратегий:
- Drag-and-drop блоки (EMA, RSI, условия)
- Параметры через формы
- Тестирование на исторических данных

#### 3.2 DCA стратегии:
- Поддержка Dollar Cost Averaging
- Настройка интервалов покупки
- Автоматическое усреднение

#### 3.3 Теханализ модули:
- Индикаторы (как вы предпочитаете)
- Паттерны (голова-плечи, треугольники)
- EMA алгебра (как вы упомянули)

#### 3.4 Marketplace стратегий:
- Публичные стратегии (платные/бесплатные)
- Рейтинг и отзывы
- Подписка на стратегии других трейдеров

---

## 🔐 Как работают SaaS боты (референс)

### Примеры:
1. **3Commas** - Multi-exchange, копирование сделок, боты
2. **Cryptohopper** - Marketplace стратегий, DCA, Grid
3. **Pionex** - Grid trading, DCA, Infinity Grid

### Общая модель:
```
Клиент регистрируется
    ↓
Добавляет API ключи биржи (read-only или trade)
    ↓
Выбирает стратегию из каталога или создает свою
    ↓
Настраивает параметры (символ, плечо, размер)
    ↓
Запускает бота
    ↓
Бот торгует через API клиента
    ↓
Результаты сохраняются и показываются в dashboard
    ↓
Клиент может остановить/изменить стратегию в любой момент
```

### Монетизация:
- **Free tier:** 1 активный бот, базовые стратегии
- **Pro:** Unlimited боты, все стратегии, приоритет
- **Enterprise:** Индивидуальные стратегии, API доступ

---

## ✅ Рекомендация: Поэтапный подход

### **СЕЙЧАС (Этап 1):**
1. ✅ Доделать рабочее демо
2. ✅ Интегрировать вашу EMA стратегию
3. ✅ Запустить investor_portal
4. ✅ Протестировать все стратегии
5. ✅ Показать инвестору

**Структура остается простой (все в одном проекте)**

### **ПОТОМ (Этап 2):**
1. Рефакторинг в модульную структуру (backend/dashboard/shared)
2. Добавление multi-tenant таблиц в БД
3. Аутентификация и авторизация
4. API для управления клиентами
5. Шифрование API ключей

### **В БУДУЩЕМ (Этап 3):**
1. Визуальный редактор стратегий
2. Marketplace
3. DCA модуль
4. Расширенный теханализ

---

## 🎯 Что делаем ПРЯМО СЕЙЧАС:

### Вариант А: Простое демо (рекомендую)
- Оставить текущую структуру
- Доделать investor_portal с реальными бэктестами
- Добавить EMA стратегию
- Все работает, можно показывать инвестору

### Вариант Б: Сразу SaaS-ready
- Рефакторинг в backend/dashboard/shared
- Multi-tenant БД
- Аутентификация
- Больше времени, но масштабируемо

**Моя рекомендация: Вариант А** - сначала демо, потом рефакторинг под SaaS.

---

## 📝 Готовое техническое задание для команды

Если решите делать SaaS сразу, вот структура:

### Backend (Actix):
- `POST /api/v1/backtest` - запуск бэктеста
- `GET /api/v1/strategies` - список стратегий
- `POST /api/v1/trading/start` - запуск торговли
- WebSocket для live обновлений

### Dashboard (Rocket или React):
- Страница выбора стратегий
- Настройка параметров
- Просмотр результатов
- Управление API ключами

### Worker (Tokio):
- Фоновые бэктесты
- Live торговля
- Redis queue для задач

---

## ❓ Ваш выбор?

1. **Доделать простое демо сейчас** (1-2 дня) → показать инвестору → потом SaaS
2. **Сразу делать SaaS архитектуру** (1-2 недели) → полноценный продукт

Что выбираете?



