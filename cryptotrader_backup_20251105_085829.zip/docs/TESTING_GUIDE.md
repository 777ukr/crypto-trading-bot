# 🧪 Testing Guide

## ✅ Результаты тестирования

### Тесты стратегий

Всего создано **9 тестов** для 3 стратегий:

1. **Channel Split Strategy** (2 теста)
   - ✅ `test_channel_split_strategy_entry` - Проверка входа в позицию
   - ✅ `test_channel_split_order_splitting` - Проверка дробления на 3 части

2. **Market Making Strategy** (2 теста)
   - ✅ `test_market_making_basic` - Базовая проверка работы
   - ✅ `test_market_making_spread_calculation` - Проверка расчета спреда

3. **HFT Strategy** (2 теста)
   - ✅ `test_hft_entry_signal` - Проверка сигналов входа
   - ✅ `test_hft_exit_conditions` - Проверка условий выхода

4. **Интеграционные тесты** (3 теста)
   - ✅ `test_all_strategies_reset` - Проверка reset функции
   - ✅ `test_strategy_integration_simulation` - Симуляция работы всех стратегий

## 🚀 Запуск тестов

### Все тесты
```bash
cargo test --features gate_exec
```

### Только тесты стратегий
```bash
cargo test --features gate_exec --lib strategy_tests::tests
```

### Конкретная стратегия
```bash
# Channel Split
cargo test --features gate_exec --lib test_channel_split

# Market Making
cargo test --features gate_exec --lib test_market_making

# HFT
cargo test --features gate_exec --lib test_hft
```

### С выводом
```bash
cargo test --features gate_exec --lib -- --nocapture
```

## 📊 Покрытие тестами

- ✅ Channel Split Strategy - полное покрытие основных функций
- ✅ Market Making Strategy - проверка спреда и ордеров
- ✅ HFT Strategy - проверка входа/выхода
- ✅ Интеграционные тесты - проверка совместной работы

## 🔍 Что тестируется

### Channel Split Strategy
- Вход в нижней части канала
- Дробление ордера на 3 части
- Правильные цены для каждой части
- Размеры частей примерно равны

### Market Making Strategy
- Выставление bid/ask ордеров
- Расчет спреда (0.1%)
- Динамическая корректировка
- Bid < Ask всегда

### HFT Strategy
- Сигналы входа на основе тренда
- Выход по времени (60 сек)
- Выход по тейк-профиту (0.02%)
- Выход по стоп-лоссу (разворот)

## ⚠️ Известные ограничения

1. Тесты не используют реальные API вызовы (unit тесты)
2. Симуляция данных упрощенная
3. Для полной проверки нужны integration тесты с реальными данными

## 🔧 Отладка тестов

Если тест падает:
```bash
# С детальным выводом
RUST_BACKTRACE=1 cargo test --features gate_exec --lib -- --nocapture test_name

# Один конкретный тест
cargo test --features gate_exec --lib -- --exact test_name
```

## 📈 Метрики

После каждого запуска проверяйте:
- Количество пройденных тестов
- Количество упавших тестов
- Время выполнения

Цель: **100% passing tests** перед деплоем!


