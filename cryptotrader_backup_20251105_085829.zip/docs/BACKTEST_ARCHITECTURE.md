# 🎯 Архитектура Backtest Engine

## Философия бэктестинга в скальпинге

**"Бэктест не для точного воспроизведения результата, а для анализа поведения стратегии"**

Наш бэктестер реализует **статистический эмулятор**, а не детерминированный симулятор, как в MoonBot.

## Ключевые принципы

### 1. Случайность и вариативность

- **Лаг трейдов**: 10-20 мс случайная задержка
- **Дискретность пересчета**: стратегии пересчитываются не каждый тик
- **Случайная задержка на перестановку**: 10-20 мс для Sell ордеров
- **Вероятность пропуска трейда**: эмуляция "не успел"

### 2. Монте-Карло симуляция

Многократные прогоны (N=100) с разными seed для получения распределения доходности.

### 3. Защита от реальных ордеров

Принудительное включение режима `Emulator` при бэктесте.

## Структура модуля

```
src/backtest/
├── mod.rs              # Публичный интерфейс
├── engine.rs           # Основной движок бэктеста
├── emulator.rs         # Эмулятор рынка и исполнения
├── market.rs           # Состояние рынка и потоки данных
├── metrics.rs          # Метрики и результаты
├── replay.rs           # Воспроизведение .bin файлов
└── bin_format.rs       # Формат .bin файлов
```

## Компоненты

### BacktestEngine

Основной движок, который:
- Управляет потоками данных
- Применяет случайные задержки
- Обрабатывает дискретные пересчеты
- Собирает метрики

### MarketEmulator

Эмулирует:
- Размещение лимитных ордеров
- Заполнение ордеров с вероятностью
- Скольжение цены (slippage)
- Частичные заполнения

### TradeStream

Поток исторических трейдов из .bin файла.

## Использование

```rust
use rust_test::backtest::*;

// Настройки бэктеста
let settings = BacktestSettings {
    tick_interval_ms: 2,
    latency_ms_range: (10, 20),
    execution_delay_ms_range: (10, 20),
    reposition_delay_ms_range: (10, 20),
    recalculation_interval_ms: 50,
    random_seed: Some(12345), // Для воспроизводимости
    ..Default::default()
};

// Создаем движок
let mut engine = BacktestEngine::new(settings);

// Загружаем .bin файл
let mut replay = ReplayEngine::new(Default::default());
replay.load_bin_file("data/Demo_BTC.bin")?;

// Добавляем потоки в движок
for stream in replay.take_streams() {
    engine.add_stream(stream);
}

// Запускаем бэктест
let result = engine.run()?;

println!("P&L: {:.2}", result.total_pnl);
println!("Trades: {}", result.total_trades);
println!("Win Rate: {:.2}%", result.win_rate);

// Монте-Карло симуляция
let results = engine.run_monte_carlo(100)?;
```

## Факторы случайности

1. **Network latency jitter**: Случайная задержка 10-20 мс на каждое действие
2. **Orderbook update lag**: Бот видит цену не в тот же тик
3. **Execution slippage**: Случайное отклонение цены исполнения
4. **Out-of-sync recalculation**: Пересчеты не каждый тик
5. **Random missed trade**: Вероятность пропуска трейда

## Формат .bin файлов

Каждый трейд = 24 байта:
- timestamp (i64, 8 bytes)
- price (f64, 8 bytes)
- volume (f64, 8 bytes)
- side (bool, 1 byte в последнем байте)

Совместимо с форматом MoonBot.

## Метрики

- Total P&L
- Win Rate
- Profit Factor
- Max Drawdown
- Sharpe Ratio
- Average Profit/Loss
- Largest Win/Loss

## Интеграция со стратегиями

Стратегии реализуют trait `Strategy` и получают события:
- `on_tick(tick)` - новый трейд
- `on_order_filled(order)` - ордер исполнен

## Примечания

- Результаты могут различаться между прогонами из-за случайности
- Используйте Монте-Карло для статистической значимости
- Режим `Emulator` принудительно включен для безопасности

