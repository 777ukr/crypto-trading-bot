# Быстрая справка - Все что нужно знать

## 📍 Путь к .env файлу:

```
/home/crypto/sites/cryptotrader.com/.env
```

**Быстрое редактирование:**
```bash
nano /home/crypto/sites/cryptotrader.com/.env
```

**Содержимое:**
```
GATEIO_API_KEY=ваш_ключ
GATEIO_SECRET_KEY=ваш_секрет
```

## 🚀 Быстрый запуск:

### Тест API ключей:
```bash
cargo test --features gate_exec api_validation
```

### Полная аналитика BTC (3 суток):
```bash
cargo run --bin btc_analytics --features gate_exec
```

### Бэктест SOL:
```bash
cargo run --bin sol_backtest
```

## 📊 3 варианта стратегий:

1. **TrailingStop** - трейлинг стоп при прорыве канала
2. **EarlyExit** - ранний выход при развороте  
3. **ExtendedTarget** - бесконечное оттягивание цели

## 📁 Файлы результатов:

- `data/sol_prices.csv` - цены
- `data/sol_backtest.csv` - результаты бэктеста
- `backtest_results/` - сравнение стратегий
- Все в `.cursorignore` - не индексируются

## ✅ Что готово:

- ✅ Тесты валидации API
- ✅ Аналитика производительности
- ✅ 3 адаптивные стратегии
- ✅ Система сравнения стратегий
- ✅ Бэктестер для SOL

## 🎯 Следующие шаги:

1. Добавить ключи в `.env`
2. Запустить валидацию
3. Получить историю за 3 суток
4. Протестировать стратегии
5. Выбрать лучшую

