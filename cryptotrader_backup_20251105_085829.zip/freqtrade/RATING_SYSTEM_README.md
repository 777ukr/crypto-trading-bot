# 🏆 Strategy Rating System - Ninja Style

Система рейтинга стратегий по образцу [ninja.trade](https://ninja.trade), которая:
- Анализирует результаты бэктестов Freqtrade
- Рассчитывает Ninja Score (взвешенная оценка)
- Фильтрует стратегии (lookahead bias, tight trailing stops, leverage)
- Сохраняет в PostgreSQL
- Отображает рейтинг в веб-интерфейсе

## 📋 Установка

### 1. Создание базы данных

```bash
# Создайте базу данных (если еще не создана)
createdb cryptotrader

# Установите переменную окружения
export DATABASE_URL="postgresql://postgres:postgres@localhost:5432/cryptotrader"
```

### 2. Применение схемы

```bash
cd /home/crypto/sites/cryptotrader.com
psql "$DATABASE_URL" -f database/strategy_rating_schema.sql
```

Или используйте автоматический скрипт:
```bash
cd freqtrade
./setup_rating_system.sh
```

### 3. Установка Python зависимостей

```bash
cd freqtrade
source .venv/bin/activate
pip install psycopg2-binary
```

## 🚀 Использование

### Шаг 1: Запустите бэктесты

```bash
cd freqtrade
source .venv/bin/activate
python3 run_full_backtest_suite.py
```

Это создаст ZIP файлы с результатами в `user_data/backtest_results/`

### Шаг 2: Рассчитайте рейтинг

```bash
python3 strategy_rating_system.py
```

Скрипт:
- Парсит все ZIP файлы с результатами бэктестов
- Извлекает метрики (win rate, profit factor, sharpe, etc.)
- Проверяет на lookahead bias и tight trailing stops
- Рассчитывает медианные значения
- Вычисляет Ninja Score
- Сохраняет в PostgreSQL

### Шаг 3: Создайте веб-интерфейс

```bash
python3 rating_web_interface.py
```

Откроется HTML страница с рейтингом: `user_data/web/strategy_rankings.html`

## 📊 Ninja Score

Ninja Score рассчитывается по формуле с весами:

```python
stat_weights = {
    "buys": 9,
    "avgprof": 26,
    "totprofp": 26,
    "winp": 24,
    "ddp": -25,              # Отрицательный (меньше = лучше)
    "stoploss": 7,
    "sharpe": 7,
    "sortino": 7,
    "calmar": 7,
    "expectancy": 8,
    "profit_factor": 9,
    "cagr": 10,
    "rejected_signals": -25, # Отрицательный
    "backtest_win_percentage": 10
}
```

## 🔍 Фильтры

Стратегии исключаются из рейтинга если:

1. **Leverage > 1x** - только стратегии с leverage = 1
2. **Lookahead Bias** - обнаружены паттерны:
   - `.iat[-1]` - прямой доступ к последнему элементу
   - `.shift(-1)` - сдвиг в будущее
   - Операции на всем DataFrame без rolling window
   - TA индикаторы с period = 1
3. **Tight Trailing Stop** - `trailing_stop_positive_offset <= 0.05` и `trailing_stop_positive <= 0.0025`
4. **Недостаточно данных** - меньше 3 бэктестов или меньше 10 сделок

## 🚫 Stalled Strategies

Стратегии помечаются как "stalled" если:

1. **Negative** - средний profit < -0.30 и все бэктесты отрицательные
2. **90% Negative** - >= 12 бэктестов, >= 90% отрицательных
3. **Biased** - обнаружен lookahead bias
4. **No Trades** - нет сделок в нескольких бэктестах

## 📁 Структура базы данных

### `strategy_ratings`
Агрегированные метрики стратегий (медианные значения):
- `strategy_name`, `exchange`, `stake_currency`
- `median_win_rate`, `median_total_profit_pct`, `median_profit_factor`
- `median_sharpe_ratio`, `median_max_drawdown`
- `ninja_score`, `backtest_win_percentage`
- `has_lookahead_bias`, `has_tight_trailing_stop`, `is_stalled`

### `strategy_backtest_metrics`
Детальные метрики каждого бэктеста (для расчета медиан)

### `strategy_ranking_history`
Исторические снимки рейтинга (для отслеживания изменений)

## 🔗 Интеграция с существующей системой

Система интегрируется с:
- ✅ `backtest_results` - использует существующие результаты бэктестов
- ✅ PostgreSQL - использует ту же базу данных
- ✅ Freqtrade - парсит стандартные ZIP файлы результатов

## 📝 Примеры использования

### Получить топ-10 стратегий:

```sql
SELECT strategy_name, ninja_score, median_total_profit_pct, median_win_rate
FROM strategy_ratings
WHERE is_active = TRUE
  AND leverage = 1
  AND has_lookahead_bias = FALSE
ORDER BY ninja_score DESC
LIMIT 10;
```

### Найти стратегии с высоким win rate:

```sql
SELECT strategy_name, median_win_rate, median_profit_factor, ninja_score
FROM strategy_ratings
WHERE median_win_rate >= 60
  AND is_active = TRUE
ORDER BY median_win_rate DESC;
```

## 🎯 Результат

После выполнения всех шагов вы получите:
- ✅ Рейтинг стратегий в PostgreSQL
- ✅ Веб-интерфейс с визуализацией
- ✅ Автоматическая фильтрация плохих стратегий
- ✅ Ninja Score для сравнения стратегий

Это поможет выбрать лучшие стратегии для торговли! 🚀



