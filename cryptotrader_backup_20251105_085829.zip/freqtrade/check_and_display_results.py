#!/usr/bin/env python3
"""
Проверка и отображение результатов бэктестов в веб-интерфейсе
Решает проблему с пустой страницей Backtesting
"""

import json
import requests
from pathlib import Path
from typing import Dict, List, Optional
import sys

FREQTRADE_DIR = Path(__file__).parent
CONFIG_PATH = FREQTRADE_DIR.parent / "config" / "freqtrade_config.json"
RESULTS_DIR = FREQTRADE_DIR / "user_data" / "backtest_results"
WEB_UI_URL = "http://127.0.0.1:8081"


def get_password() -> str:
    """Получает пароль из конфига"""
    try:
        with open(CONFIG_PATH) as f:
            config = json.load(f)
            return config.get("api_server", {}).get("password", "")
    except:
        return ""


def check_api_connection() -> bool:
    """Проверяет доступность API"""
    try:
        response = requests.get(f"{WEB_UI_URL}/api/v1/ping", timeout=2)
        return response.status_code == 200
    except:
        return False


def get_backtest_history() -> List[Dict]:
    """Получает список всех бэктестов через API"""
    password = get_password()
    if not password:
        print("⚠️  Пароль не найден в конфиге")
        return []
    
    try:
        response = requests.get(
            f"{WEB_UI_URL}/api/v1/backtest/history",
            auth=("freqtrader", password),
            timeout=5
        )
        
        if response.status_code == 200:
            return response.json()
        elif response.status_code == 401:
            print("❌ Ошибка авторизации - проверьте пароль")
            return []
        else:
            print(f"⚠️  API вернул код {response.status_code}")
            return []
    except requests.exceptions.ConnectionError:
        print("❌ Не удалось подключиться к веб-серверу")
        print(f"💡 Убедитесь, что freqtrade запущен: freqtrade trade --config ../config/freqtrade_config.json")
        return []
    except Exception as e:
        print(f"❌ Ошибка при запросе API: {e}")
        return []


def check_local_files() -> List[Dict]:
    """Проверяет локальные файлы результатов"""
    results = []
    
    # Ищем .meta.json файлы
    for meta_file in sorted(RESULTS_DIR.glob("*.meta.json"), key=lambda x: x.stat().st_mtime, reverse=True):
        try:
            meta_data = json.loads(meta_file.read_text())
            strategy_name = list(meta_data.keys())[0] if meta_data else "Unknown"
            
            filename = meta_file.name.replace(".meta.json", "")
            zip_file = RESULTS_DIR / f"{filename}.zip"
            
            results.append({
                "filename": f"{filename}.zip",
                "strategy": strategy_name,
                "meta_file": meta_file.name,
                "zip_exists": zip_file.exists(),
                "size": zip_file.stat().st_size if zip_file.exists() else 0,
                "timestamp": meta_file.stat().st_mtime
            })
        except Exception as e:
            print(f"⚠️  Ошибка при чтении {meta_file.name}: {e}")
    
    return results


def display_results_summary(api_results: List[Dict], local_results: List[Dict]):
    """Выводит сводку результатов"""
    print(f"\n{'='*70}")
    print("📊 СВОДКА РЕЗУЛЬТАТОВ БЭКТЕСТОВ")
    print(f"{'='*70}\n")
    
    print(f"🌐 API результаты: {len(api_results)}")
    if api_results:
        for i, result in enumerate(api_results[:10], 1):
            filename = result.get("filename", "N/A")
            strategy = result.get("strategy", "N/A")
            print(f"   {i}. {strategy}: {filename}")
    else:
        print("   ⚠️  API не вернул результатов")
    
    print(f"\n📁 Локальные файлы: {len(local_results)}")
    if local_results:
        for i, result in enumerate(local_results[:10], 1):
            strategy = result.get("strategy", "N/A")
            filename = result.get("filename", "N/A")
            size_kb = result.get("size", 0) / 1024
            print(f"   {i}. {strategy}: {filename} ({size_kb:.1f} KB)")
    else:
        print("   ⚠️  Локальные файлы не найдены")
    
    print(f"\n{'='*70}\n")


def diagnose_web_ui_issue():
    """Диагностика проблемы с веб-интерфейсом"""
    print("🔍 Диагностика проблемы с веб-интерфейсом\n")
    
    # 1. Проверка API
    print("1️⃣  Проверка API...")
    if check_api_connection():
        print("   ✅ API доступен")
    else:
        print("   ❌ API недоступен")
        print("   💡 Запустите: freqtrade trade --config ../config/freqtrade_config.json")
        return False
    
    # 2. Проверка истории через API
    print("\n2️⃣  Проверка истории бэктестов через API...")
    api_results = get_backtest_history()
    
    # 3. Проверка локальных файлов
    print("\n3️⃣  Проверка локальных файлов...")
    local_results = check_local_files()
    
    # 4. Сравнение
    print("\n4️⃣  Сравнение результатов...")
    display_results_summary(api_results, local_results)
    
    # 5. Рекомендации
    print("💡 РЕКОМЕНДАЦИИ:\n")
    
    if not api_results and local_results:
        print("   ⚠️  Проблема: API не возвращает результаты, но файлы есть")
        print("   ✅ Решение:")
        print("      1. Перезапустите freqtrade веб-сервер")
        print("      2. Обновите страницу в браузере (F5)")
        print("      3. Проверьте права доступа к файлам")
        print(f"      4. Откройте напрямую: {WEB_UI_URL}/backtesting")
    
    elif api_results:
        print("   ✅ API работает правильно!")
        print(f"   🌐 Откройте: {WEB_UI_URL}/backtesting")
        print("   📋 Если страница пустая:")
        print("      - Обновите страницу (F5 или Ctrl+Shift+R)")
        print("      - Проверьте консоль браузера (F12)")
        print("      - Убедитесь, что вы вошли в систему")
    
    elif not local_results:
        print("   ⚠️  Нет результатов бэктестов")
        print("   ✅ Решение:")
        print("      1. Запустите бэктесты:")
        print("         python3 run_full_backtest_suite.py")
        print("      2. Проверьте, что стратегии генерируют сделки")
    
    return True


def create_quick_access_html():
    """Создает HTML страницу с быстрым доступом к результатам"""
    local_results = check_local_files()
    
    if not local_results:
        return None
    
    html = """<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Freqtrade Backtest Results - Quick Access</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 0; padding: 20px; background: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        h1 { color: #333; border-bottom: 3px solid #4CAF50; padding-bottom: 10px; }
        .alert { padding: 15px; background: #fff3cd; border: 1px solid #ffc107; border-radius: 5px; margin: 20px 0; }
        .results-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px; margin: 20px 0; }
        .result-card { border: 1px solid #ddd; border-radius: 8px; padding: 15px; background: #f9f9f9; }
        .result-card h3 { margin: 0 0 10px 0; color: #4CAF50; }
        .btn { display: inline-block; padding: 10px 20px; background: #4CAF50; color: white; text-decoration: none; border-radius: 5px; margin: 5px 5px 5px 0; }
        .btn:hover { background: #45a049; }
        .btn-secondary { background: #2196F3; }
        .btn-secondary:hover { background: #0b7dda; }
    </style>
</head>
<body>
    <div class="container">
        <h1>📊 Freqtrade Backtest Results - Quick Access</h1>
        
        <div class="alert">
            <strong>💡 Важно:</strong> Если страница http://127.0.0.1:8081/backtesting пустая:
            <ul>
                <li>Обновите страницу (F5 или Ctrl+Shift+R)</li>
                <li>Проверьте, что вы вошли в систему (логин: freqtrader)</li>
                <li>Проверьте консоль браузера (F12) на наличие ошибок</li>
            </ul>
        </div>
        
        <h2>🌐 Прямые ссылки:</h2>
        <a href="http://127.0.0.1:8081/backtesting" class="btn btn-secondary" target="_blank">Открыть Backtesting</a>
        <a href="http://127.0.0.1:8081/dashboard" class="btn" target="_blank">Dashboard</a>
        
        <h2>📁 Доступные результаты:</h2>
        <div class="results-grid">
"""
    
    for result in local_results[:20]:  # Показываем последние 20
        strategy = result.get("strategy", "Unknown")
        filename = result.get("filename", "")
        size_kb = result.get("size", 0) / 1024
        
        html += f"""
            <div class="result-card">
                <h3>{strategy}</h3>
                <p><strong>Файл:</strong> {filename}</p>
                <p><strong>Размер:</strong> {size_kb:.1f} KB</p>
                <a href="http://127.0.0.1:8081/api/v1/backtest/history/result?filename={filename}&strategy={strategy}" 
                   class="btn" target="_blank">Открыть через API</a>
            </div>
"""
    
    html += """
        </div>
        
        <h2>🔧 Команды для просмотра:</h2>
        <pre style="background: #f5f5f5; padding: 15px; border-radius: 5px;">
# Показать все результаты
freqtrade backtesting-show

# Показать конкретный результат
freqtrade backtesting-show --backtest-filename=backtest-result-YYYYMMDD_HHMMSS.zip

# Запустить новый бэктест
python3 run_full_backtest_suite.py
        </pre>
    </div>
</body>
</html>
"""
    
    html_file = FREQTRADE_DIR / "user_data" / "quick_access_results.html"
    html_file.parent.mkdir(parents=True, exist_ok=True)
    html_file.write_text(html, encoding='utf-8')
    
    return html_file


def main():
    """Главная функция"""
    print("🔍 Проверка и диагностика результатов бэктестов\n")
    
    # Диагностика
    if not diagnose_web_ui_issue():
        return
    
    # Создаем HTML страницу для быстрого доступа
    html_file = create_quick_access_html()
    if html_file:
        print(f"\n📄 HTML страница для быстрого доступа:")
        print(f"   file://{html_file.absolute()}")
    
    print(f"\n{'='*70}")
    print("✅ Диагностика завершена!")
    print(f"{'='*70}\n")


if __name__ == "__main__":
    try:
        import requests
    except ImportError:
        print("❌ Требуется библиотека requests")
        print("💡 Установите: pip install requests")
        sys.exit(1)
    
    main()

