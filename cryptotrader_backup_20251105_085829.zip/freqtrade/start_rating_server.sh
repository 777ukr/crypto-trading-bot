#!/bin/bash
# Скрипт для запуска Rating API Server

cd "$(dirname "$0")"
source .venv/bin/activate

echo "🚀 Запуск Strategy Rating API Server..."
echo "📊 API будет доступен на: http://localhost:8889"
echo "🌐 Веб-интерфейс: http://localhost:8889"
echo ""
echo "⚠️  Для остановки нажмите Ctrl+C"
echo ""

python3 rating_api_server.py



