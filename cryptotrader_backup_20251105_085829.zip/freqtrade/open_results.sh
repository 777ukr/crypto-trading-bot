#!/bin/bash
# Скрипт для открытия HTML отчета с результатами

cd "$(dirname "$0")"
REPORT_DIR="user_data/strategy_reports"

# Найти последний HTML отчет
LATEST_REPORT=$(ls -t "$REPORT_DIR"/*.html 2>/dev/null | head -1)

if [ -z "$LATEST_REPORT" ]; then
    echo "❌ HTML отчеты не найдены!"
    echo "💡 Запустите сначала: python3 test_all_strategies.py"
    exit 1
fi

echo "📊 Открываю отчет: $LATEST_REPORT"
echo "🌐 URL: file://$(pwd)/$LATEST_REPORT"

# Попытка открыть в браузере
if command -v xdg-open &> /dev/null; then
    xdg-open "$LATEST_REPORT"
elif command -v open &> /dev/null; then
    open "$LATEST_REPORT"
else
    echo "⚠️  Не удалось автоматически открыть браузер"
    echo "📋 Откройте вручную: file://$(pwd)/$LATEST_REPORT"
fi

