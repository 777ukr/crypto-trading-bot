# 📊 Как смотреть результаты стратегий

## 🎯 Где смотреть результаты в Freqtrade Web UI

### ⚠️ ВАЖНО: Dashboard НЕ показывает результаты бэктестов!

**Dashboard** (`http://127.0.0.1:8081/dashboard`) показывает только:
- Текущие открытые позиции (live торговля)
- Статус бота
- Баланс
- **НО НЕ результаты бэктестов!**

### ✅ Правильное место: **Backtesting** раздел

1. **Откройте:** http://127.0.0.1:8081
2. **Войдите:**
   - Логин: `freqtrader`
   - Пароль: см. `config/freqtrade_config.json` (секция `api_server.password`)
3. **Перейдите в меню:** `Backtesting` (НЕ Dashboard!)
4. **Там вы увидите:**
   - Результаты последнего бэктеста
   - Графики equity curve
   - Таблицы со статистикой
   - Распределение сделок по месяцам/дням
   - Сравнение стратегий

## 📁 Файлы с результатами

### CSV файлы (детальные сделки):
```bash
freqtrade/user_data/backtest_results/
  ├── MShotStrategy_BTC_USDT_trades.csv
  ├── HookStrategy_BTC_USDT_trades.csv
  ├── MStrikeStrategy_BTC_USDT_trades.csv
  └── AdvancedIndicatorStrategy_BTC_USDT_trades.csv
```

### JSON файлы (рейтинги):
```bash
freqtrade/user_data/backtest_results/
  └── strategy_rankings_*.json
```

### HTML отчеты (визуальный рейтинг):
```bash
freqtrade/user_data/strategy_reports/
  └── ranking_*.html
```

## 🚀 Быстрые команды

### 1. Запустить тест всех стратегий:
```bash
cd /home/crypto/sites/cryptotrader.com/freqtrade
source .venv/bin/activate
python3 quick_test_all.py
```

### 2. Показать результаты последнего бэктеста:
```bash
freqtrade backtesting-show
```

### 3. Показать рейтинг по парам:
```bash
freqtrade backtesting-show --show-pair-list
```

### 4. Открыть HTML отчет:
```bash
./open_results.sh
```

## 📊 Структура результатов

### В веб-интерфейсе (Backtesting):
- **Total Profit %** - общая прибыль в %
- **Total Trades** - количество сделок
- **Win Rate** - процент прибыльных сделок
- **Profit Factor** - отношение прибыли к убыткам
- **Max Drawdown** - максимальная просадка
- **Sharpe Ratio** - коэффициент Шарпа
- **Equity Curve** - график изменения баланса

### В CSV файлах:
- `open_date` - дата входа
- `close_date` - дата выхода
- `profit_abs` - абсолютная прибыль
- `profit_ratio` - прибыль в долях
- `profit_pct` - прибыль в %
- `duration` - длительность сделки

## 🏆 Как найти лучшую стратегию

1. **По рейтингу:** Чем выше Overall Rating (0-10), тем лучше
2. **По прибыльности:** PNL % должен быть положительным
3. **По стабильности:** Больше сделок = стабильнее
4. **По риску:** Меньше Max Drawdown = безопаснее
5. **По универсальности:** Хорошие результаты на всех парах

## 💡 Пример интерпретации

### Хорошая стратегия:
- ✅ PNL % > 5%
- ✅ Win Rate > 50%
- ✅ Profit Factor > 1.5
- ✅ Max Drawdown < 10%
- ✅ Total Trades > 20

### Плохая стратегия:
- ❌ PNL % < 0%
- ❌ Win Rate < 40%
- ❌ Profit Factor < 1.0
- ❌ Max Drawdown > 20%

## 🔍 Примеры результатов

### MShotStrategy (BTC/USDT):
- Total Trades: 10
- PNL: -6.07%
- Win Rate: 70%
- Profit Factor: 0.33
- Max Drawdown: 6.49%

**Вывод:** Стратегия не прибыльна, нужна оптимизация параметров.

## 📝 Следующие шаги

1. **Оптимизировать параметры** стратегий через `hyperopt`
2. **Тестировать на разных парах** (ETH/USDT, SOL/USDT)
3. **Сравнивать стратегии** на одних и тех же данных
4. **Анализировать equity curve** - плавный рост лучше резких скачков

