# 📊 Просмотр результатов стратегий в Freqtrade Web UI

## 🎯 Главная ссылка

### ⭐ **Backtesting страница:**
```
http://127.0.0.1:8081/backtesting
```

**⚠️ ВАЖНО:** Это НЕ Dashboard! Dashboard (`http://127.0.0.1:8081/dashboard`) показывает только live торговлю.

## 🔐 Доступ

1. **Откройте:** http://127.0.0.1:8081
2. **Логин:** `freqtrader`
3. **Пароль:** см. `config/freqtrade_config.json` (секция `api_server.password`)

## 📍 Навигация в веб-интерфейсе

### Главное меню Freqtrade:
- **Dashboard** - текущие позиции (live торговля)
- **Backtesting** ⭐ - результаты бэктестов (ЗДЕСЬ смотреть!)
- **Trades** - история всех сделок
- **Settings** - настройки

### В разделе Backtesting вы увидите:
- ✅ **Run Backtest** - запустить новый бэктест
- ✅ **Backtest History** - история всех бэктестов
- ✅ **Results** - детальные результаты
- ✅ **Graphs** - графики equity curve
- ✅ **Statistics** - статистика по стратегиям

## 🔗 Прямые ссылки API

### Список всех бэктестов:
```
GET http://127.0.0.1:8081/api/v1/backtest/history
```

### Конкретный результат:
```
GET http://127.0.0.1:8081/api/v1/backtest/history/result?filename=backtest-result-YYYYMMDD_HHMMSS.zip&strategy=StrategyName
```

### Пример:
```bash
curl -u freqtrader:PASSWORD \
  "http://127.0.0.1:8081/api/v1/backtest/history/result?filename=backtest-result-2025-11-04_15-19-32.zip&strategy=MShotStrategy"
```

## 🚀 Быстрый старт

### 1. Запустить тест всех стратегий:
```bash
cd /home/crypto/sites/cryptotrader.com/freqtrade
source .venv/bin/activate
python3 integrate_with_webui.py
```

### 2. Показать все ссылки:
```bash
./create_web_links.sh
```

### 3. Открыть в браузере:
```bash
xdg-open http://127.0.0.1:8081/backtesting
```

## 📁 Где находятся результаты

### Автоматически созданные файлы:
```
user_data/backtest_results/
  ├── backtest-result-YYYYMMDD_HHMMSS.zip      (данные)
  ├── backtest-result-YYYYMMDD_HHMMSS.meta.json (метаданные)
  └── index.json                                 (индекс)
```

### Формат именования Freqtrade:
- `backtest-result-YYYYMMDD_HHMMSS.zip` - ZIP архив с результатами
- `backtest-result-YYYYMMDD_HHMMSS.meta.json` - метаданные

## 📊 Что показывается в веб-интерфейсе

### После запуска бэктеста видны:
- ✅ **Total Profit %** - общая прибыль
- ✅ **Total Trades** - количество сделок
- ✅ **Win Rate** - процент прибыльных сделок
- ✅ **Profit Factor** - отношение прибыли к убыткам
- ✅ **Max Drawdown** - максимальная просадка
- ✅ **Sharpe Ratio** - коэффициент Шарпа
- ✅ **Equity Curve** - график изменения баланса
- ✅ **Trade Distribution** - распределение сделок

## 🎨 Дизайн веб-интерфейса

Freqtrade использует стандартный дизайн:
- **Темная/светлая тема** (автоматически)
- **Адаптивный дизайн** (работает на мобильных)
- **Интерактивные графики** (Chart.js)
- **Таблицы с сортировкой**
- **Фильтры и поиск**

## 💡 Примеры использования

### Запустить бэктест через CLI:
```bash
freqtrade backtesting \
  --config ../config/freqtrade_config.json \
  --strategy MShotStrategy \
  --timerange 20251005-20251104 \
  --timeframe 5m \
  --pairs BTC/USDT \
  --export trades
```

### Просмотреть результаты:
1. Откройте: http://127.0.0.1:8081/backtesting
2. Результаты автоматически появятся в разделе "Backtest History"
3. Кликните на результат для детального просмотра

### Сравнить стратегии:
1. Запустите бэктесты для разных стратегий
2. В разделе Backtesting выберите "Compare"
3. Выберите стратегии для сравнения
4. Увидите сравнительные графики и таблицы

## ⚠️ Troubleshooting

### Страница не открывается:
- Проверьте, что веб-сервер запущен: `ps aux | grep freqtrade`
- Проверьте порт: `netstat -tuln | grep 8081`
- Проверьте конфиг: `api_server.enabled: true`

### Нет результатов:
- Запустите бэктест через веб-интерфейс или CLI
- Проверьте файлы: `ls -la user_data/backtest_results/`
- Обновите страницу в браузере (F5)

### Ошибка авторизации:
- Проверьте логин/пароль в `config/freqtrade_config.json`
- Убедитесь, что `api_server.enabled: true`
- Проверьте логи: `tail -f freqtrade.log`

### Результаты не отображаются:
- Убедитесь, что файлы созданы в правильном формате
- Проверьте права доступа: `chmod 644 user_data/backtest_results/*`
- Проверьте логи браузера (F12 → Console)

## 📚 Дополнительные ресурсы

- `QUICK_START_VIEW_RESULTS.md` - быстрый старт
- `WEB_UI_INTEGRATION.md` - полная интеграция
- `HOW_TO_VIEW_RESULTS.md` - подробная инструкция
- [Freqtrade Documentation](https://www.freqtrade.io/en/latest/)

## ✅ Чеклист

- [ ] Веб-сервер запущен (`freqtrade trade` или `freqtrade webserver`)
- [ ] Порт 8081 открыт
- [ ] Бэктесты выполнены
- [ ] Файлы созданы в `user_data/backtest_results/`
- [ ] Вход в веб-интерфейс выполнен
- [ ] Раздел Backtesting открыт
- [ ] Результаты видны в истории

