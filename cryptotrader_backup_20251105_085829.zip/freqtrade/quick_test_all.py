#!/usr/bin/env python3
"""
Быстрое тестирование всех стратегий только на BTC/USDT
с генерацией HTML отчета
"""

import json
import subprocess
import sys
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional
import pandas as pd

FREQTRADE_DIR = Path(__file__).parent
CONFIG_PATH = FREQTRADE_DIR.parent / "config" / "freqtrade_config.json"
STRATEGIES_DIR = FREQTRADE_DIR / "user_data" / "strategies"
RESULTS_DIR = FREQTRADE_DIR / "user_data" / "backtest_results"
REPORT_DIR = FREQTRADE_DIR / "user_data" / "strategy_reports"

END_DATE = datetime.now().strftime("%Y%m%d")
START_DATE = (datetime.now() - timedelta(days=30)).strftime("%Y%m%d")
TIMERANGE = f"{START_DATE}-{END_DATE}"
TIMEFRAME = "5m"
PAIR = "BTC/USDT"  # Только BTC, так как данные уже есть


def find_strategies() -> List[str]:
    """Находит все стратегии"""
    strategies = []
    for file in STRATEGIES_DIR.glob("*.py"):
        if file.name != "__init__.py" and not file.name.startswith("_"):
            strategy_name = file.stem
            if strategy_name != "TestStrategy":
                strategies.append(strategy_name)
    return strategies


def run_backtest(strategy_name: str) -> Optional[Dict]:
    """Запускает бэктест"""
    print(f"\n{'='*60}")
    print(f"🧪 {strategy_name} на {PAIR}")
    print(f"{'='*60}")
    
    export_filename = f"{strategy_name}_{PAIR.replace('/', '_')}"
    
    cmd = [
        "freqtrade", "backtesting",
        "--config", str(CONFIG_PATH),
        "--strategy", strategy_name,
        "--timerange", TIMERANGE,
        "--timeframe", TIMEFRAME,
        "--pairs", PAIR,
        "--export", "trades",
        "--export-filename", export_filename,
        "--breakdown", "month",
        "--cache", "none"
    ]
    
    try:
        result = subprocess.run(
            cmd,
            cwd=str(FREQTRADE_DIR),
            capture_output=True,
            text=True,
            timeout=300
        )
        
        if result.returncode != 0:
            print(f"❌ Ошибка")
            return None
        
        # Парсим CSV
        csv_file = RESULTS_DIR / f"{export_filename}_trades.csv"
        metrics = {"strategy": strategy_name, "pair": PAIR}
        
        if csv_file.exists():
            try:
                df = pd.read_csv(csv_file)
                if not df.empty:
                    metrics["total_trades"] = len(df)
                    metrics["winning_trades"] = len(df[df["profit_abs"] > 0])
                    metrics["losing_trades"] = len(df[df["profit_abs"] <= 0])
                    metrics["total_profit"] = df["profit_abs"].sum()
                    
                    if "profit_ratio" in df.columns:
                        metrics["profit_pct"] = df["profit_ratio"].sum() * 100
                    else:
                        metrics["profit_pct"] = (metrics["total_profit"] / 1000.0) * 100  # Примерно
                    
                    metrics["win_rate"] = (metrics["winning_trades"] / metrics["total_trades"] * 100) if metrics["total_trades"] > 0 else 0
                    
                    wins = df[df["profit_abs"] > 0]["profit_abs"].sum()
                    losses = abs(df[df["profit_abs"] < 0]["profit_abs"].sum())
                    metrics["profit_factor"] = wins / losses if losses > 0 else 0
                    
                    if "cumulative_profit" in df.columns:
                        cumulative = df["cumulative_profit"]
                        running_max = cumulative.expanding().max()
                        drawdown = (cumulative - running_max) / running_max.abs()
                        metrics["max_drawdown"] = abs(drawdown.min() * 100) if not drawdown.empty else 0.0
                    else:
                        metrics["max_drawdown"] = 0.0
                    
                    print(f"✅ {metrics['total_trades']} сделок, PNL: {metrics['profit_pct']:.2f}%, Win Rate: {metrics['win_rate']:.1f}%")
                else:
                    print("⚠️  Нет сделок")
                    metrics.update({
                        "total_trades": 0,
                        "winning_trades": 0,
                        "losing_trades": 0,
                        "total_profit": 0.0,
                        "profit_pct": 0.0,
                        "win_rate": 0.0,
                        "profit_factor": 0.0,
                        "max_drawdown": 0.0,
                    })
            except Exception as e:
                print(f"⚠️  Ошибка парсинга: {e}")
                return None
        else:
            print("⚠️  CSV файл не найден")
            return None
        
        return metrics
        
    except Exception as e:
        print(f"❌ Ошибка: {e}")
        return None


def calculate_rating(metrics: Dict) -> Dict:
    """Вычисляет рейтинг"""
    profit_score = min(abs(metrics["profit_pct"]) / 10.0, 10.0) if metrics["profit_pct"] > 0 else 0
    pf_score = min(metrics["profit_factor"] / 5.0 * 10.0, 10.0) if metrics["profit_factor"] > 0 else 0
    wr_score = metrics["win_rate"] / 10.0
    profitability_score = (profit_score * 0.4 + pf_score * 0.3 + wr_score * 0.3)
    
    stability_score = min(metrics["total_trades"] / 100.0 * 10.0, 10.0)
    risk_score = max(0, 10.0 - (metrics["max_drawdown"] / 10.0))
    fill_rate_score = min(metrics["win_rate"] / 10.0, 10.0)
    
    overall_rating = (
        profitability_score * 0.35 +
        stability_score * 0.25 +
        risk_score * 0.25 +
        fill_rate_score * 0.15
    )
    
    stars = min(5, int(overall_rating / 2.0))
    
    return {
        "profitability_score": round(profitability_score, 2),
        "stability_score": round(stability_score, 2),
        "risk_score": round(risk_score, 2),
        "fill_rate_score": round(fill_rate_score, 2),
        "overall_rating": round(overall_rating, 2),
        "stars": stars
    }


def generate_html_report(results: List[Dict]):
    """Генерирует HTML отчет"""
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    
    sorted_results = sorted(results, key=lambda x: x.get("overall_rating", 0), reverse=True)
    
    html = f"""<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🏆 Рейтинг стратегий Freqtrade</title>
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 0; padding: 20px; background: #f5f5f5; }}
        .container {{ max-width: 1400px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
        h1 {{ color: #333; border-bottom: 3px solid #4CAF50; padding-bottom: 10px; }}
        .stats-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin: 30px 0; }}
        .stat-card {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 8px; }}
        .stat-card h3 {{ margin: 0 0 10px 0; font-size: 14px; opacity: 0.9; }}
        .stat-card .value {{ font-size: 32px; font-weight: bold; }}
        table {{ width: 100%; border-collapse: collapse; margin-top: 20px; }}
        th {{ background: #4CAF50; color: white; padding: 12px; text-align: left; font-weight: 600; }}
        td {{ padding: 12px; border-bottom: 1px solid #ddd; }}
        tr:hover {{ background: #f9f9f9; }}
        .rating {{ font-size: 18px; font-weight: bold; color: #4CAF50; }}
        .stars {{ color: #FFD700; font-size: 20px; }}
        .positive {{ color: #4CAF50; }}
        .negative {{ color: #f44336; }}
        .info-box {{ margin-top: 30px; padding: 20px; background: #e3f2fd; border-radius: 8px; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🏆 Рейтинг стратегий Freqtrade</h1>
        <p><strong>Период:</strong> {TIMERANGE} ({TIMEFRAME})</p>
        <p><strong>Пара:</strong> {PAIR}</p>
        <p><strong>Дата:</strong> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
        
        <div class="stats-grid">
            <div class="stat-card">
                <h3>Всего стратегий</h3>
                <div class="value">{len(set(r['strategy'] for r in sorted_results))}</div>
            </div>
            <div class="stat-card">
                <h3>Лучший рейтинг</h3>
                <div class="value">{sorted_results[0]['overall_rating']:.2f}</div>
            </div>
            <div class="stat-card">
                <h3>Средний рейтинг</h3>
                <div class="value">{sum(r['overall_rating'] for r in sorted_results) / len(sorted_results):.2f}</div>
            </div>
        </div>
        
        <table>
            <thead>
                <tr>
                    <th>№</th>
                    <th>Стратегия</th>
                    <th>⭐ Рейтинг</th>
                    <th>PNL %</th>
                    <th>Сделок</th>
                    <th>Win Rate</th>
                    <th>Profit Factor</th>
                    <th>Drawdown</th>
                </tr>
            </thead>
            <tbody>
"""
    
    for i, result in enumerate(sorted_results, 1):
        strategy = result.get("strategy", "N/A")
        rating = result.get("overall_rating", 0.0)
        stars = "⭐" * result.get("stars", 0)
        pnl = result.get("profit_pct", 0.0)
        trades = result.get("total_trades", 0)
        wr = result.get("win_rate", 0.0)
        pf = result.get("profit_factor", 0.0)
        dd = result.get("max_drawdown", 0.0)
        pnl_class = "positive" if pnl >= 0 else "negative"
        
        html += f"""
                <tr>
                    <td><strong>{i}</strong></td>
                    <td><strong>{strategy}</strong></td>
                    <td><span class="rating">{rating:.2f}</span> <span class="stars">{stars}</span></td>
                    <td class="{pnl_class}"><strong>{pnl:+.2f}%</strong></td>
                    <td>{trades}</td>
                    <td>{wr:.1f}%</td>
                    <td>{pf:.2f}</td>
                    <td class="negative">{dd:.2f}%</td>
                </tr>
"""
    
    html += f"""
            </tbody>
        </table>
        
        <div class="info-box">
            <h2>📊 Где смотреть результаты в Freqtrade Web UI</h2>
            <ol>
                <li><strong>Откройте:</strong> <a href="http://127.0.0.1:8081" target="_blank">http://127.0.0.1:8081</a></li>
                <li><strong>Войдите:</strong> логин: <code>freqtrader</code>, пароль: см. config/freqtrade_config.json</li>
                <li><strong>Перейдите в раздел:</strong> <strong>Backtesting</strong> в меню (НЕ Dashboard!)</li>
                <li><strong>Там вы увидите:</strong>
                    <ul>
                        <li>Результаты последнего бэктеста</li>
                        <li>Графики equity curve</li>
                        <li>Таблицы со статистикой</li>
                        <li>Распределение сделок</li>
                    </ul>
                </li>
            </ol>
            
            <h3>📁 Файлы с результатами:</h3>
            <ul>
                <li>CSV: <code>user_data/backtest_results/</code></li>
                <li>JSON: <code>user_data/backtest_results/strategy_rankings_*.json</code></li>
                <li>HTML: <code>user_data/strategy_reports/</code></li>
            </ul>
            
            <h3>💡 Команды для просмотра:</h3>
            <pre>freqtrade backtesting-show</pre>
            <pre>freqtrade backtesting-show --show-pair-list</pre>
        </div>
    </div>
</body>
</html>
"""
    
    report_file = REPORT_DIR / f"ranking_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"
    with open(report_file, 'w', encoding='utf-8') as f:
        f.write(html)
    
    return report_file


def main():
    """Главная функция"""
    print("🚀 Быстрое тестирование всех стратегий на BTC/USDT")
    print(f"📅 Период: {TIMERANGE}")
    
    strategies = find_strategies()
    print(f"\n🔍 Найдено стратегий: {len(strategies)}")
    
    results = []
    for strategy in strategies:
        metrics = run_backtest(strategy)
        if metrics:
            rating = calculate_rating(metrics)
            result = {**metrics, **rating}
            results.append(result)
    
    if results:
        # Сохраняем JSON
        RESULTS_DIR.mkdir(parents=True, exist_ok=True)
        json_file = RESULTS_DIR / f"quick_ranking_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(json_file, 'w') as f:
            json.dump(results, f, indent=2)
        
        # Генерируем HTML
        report_file = generate_html_report(results)
        
        # Выводим рейтинг
        sorted_results = sorted(results, key=lambda x: x.get("overall_rating", 0), reverse=True)
        print(f"\n{'='*80}")
        print("🏆 РЕЙТИНГ")
        print(f"{'='*80}")
        print(f"{'№':<4} {'Стратегия':<25} {'Рейтинг':<8} {'⭐':<6} {'PNL%':<10} {'Сделок':<8} {'Win%':<8}")
        print(f"{'-'*80}")
        for i, r in enumerate(sorted_results, 1):
            print(f"{i:<4} {r['strategy']:<25} {r['overall_rating']:<8.2f} {'⭐'*r['stars']:<6} {r['profit_pct']:+10.2f} {r['total_trades']:<8} {r['win_rate']:<8.1f}")
        print(f"{'='*80}")
        
        print(f"\n📊 HTML отчет: {report_file}")
        print(f"🌐 Откройте: file://{report_file.absolute()}")
        print(f"\n💡 Или в веб-интерфейсе: http://127.0.0.1:8081 → Backtesting")
    else:
        print("❌ Нет результатов")


if __name__ == "__main__":
    main()

