# 📊 Где смотреть результаты стратегий

## 🌐 Freqtrade Web UI (http://127.0.0.1:8081)

### Доступ к веб-интерфейсу:
1. Откройте браузер: **http://127.0.0.1:8081**
2. Войдите:
   - **Логин:** `freqtrader`
   - **Пароль:** см. `config/freqtrade_config.json` (секция `api_server.password`)

### Где смотреть результаты:

#### 1. **Backtesting** (Главное место для результатов)
- **Путь:** Меню → **Backtesting**
- **Что показывает:**
  - Результаты последнего бэктеста
  - Графики equity curve
  - Таблицы со статистикой
  - Распределение сделок по месяцам/дням
  - Сравнение стратегий

#### 2. **Dashboard** (Общая статистика)
- **Путь:** Главная страница `/dashboard`
- **Что показывает:**
  - Текущие открытые позиции
  - Статус бота
  - Баланс
  - **НО:** Не показывает результаты бэктестов (только live торговля)

#### 3. **Trades** (История сделок)
- **Путь:** Меню → **Trades**
- **Что показывает:**
  - История всех сделок (live + backtest)
  - Фильтры по стратегиям
  - Экспорт данных

### ⚠️ Важно:
- **Backtesting результаты показываются только если:**
  1. Бот запущен с `--strategy` и `--timerange`
  2. Или вы используете веб-интерфейс для запуска бэктеста
  3. Результаты сохраняются в `user_data/backtest_results/`

## 📁 Файлы с результатами

### CSV файлы (торговые сделки):
```
freqtrade/user_data/backtest_results/
  ├── MShotStrategy_BTC_USDT_trades.csv
  ├── MShotStrategy_ETH_USDT_trades.csv
  ├── HookStrategy_BTC_USDT_trades.csv
  └── ...
```

### JSON файлы (рейтинги):
```
freqtrade/user_data/backtest_results/
  └── strategy_rankings_YYYYMMDD_HHMMSS.json
```

### HTML отчеты (визуальный рейтинг):
```
freqtrade/user_data/strategy_reports/
  └── strategy_ranking_YYYYMMDD_HHMMSS.html
```

## 🚀 Быстрый просмотр результатов

### Вариант 1: Через веб-интерфейс
1. Запустите бэктест через веб-интерфейс:
   - Откройте http://127.0.0.1:8081
   - Перейдите в Backtesting
   - Выберите стратегию и параметры
   - Запустите бэктест

### Вариант 2: Через командную строку
```bash
cd /home/crypto/sites/cryptotrader.com/freqtrade
source .venv/bin/activate

# Показать результаты последнего бэктеста
freqtrade backtesting-show

# Показать результаты конкретного файла
freqtrade backtesting-show --backtest-filename=backtest_results_2025-11-04_15-30-00.json

# Показать рейтинг по парам
freqtrade backtesting-show --show-pair-list
```

### Вариант 3: HTML отчет (автоматический)
```bash
# Запустить полное тестирование с генерацией HTML отчета
python3 test_all_strategies.py

# Открыть HTML отчет в браузере
firefox user_data/strategy_reports/strategy_ranking_*.html
# или
xdg-open user_data/strategy_reports/strategy_ranking_*.html
```

## 📊 Структура HTML отчета

HTML отчет включает:
- **Рейтинг стратегий** (0-10, с звездами 0-5)
- **Метрики по каждой стратегии:**
  - PNL %
  - Количество сделок
  - Win Rate
  - Profit Factor
  - Max Drawdown
  - Sharpe Ratio
- **Сравнение по парам** (BTC/USDT, ETH/USDT, SOL/USDT)
- **Ссылки на CSV файлы** с детальными данными

## 🔍 Как найти лучшую стратегию

1. **По рейтингу:** Чем выше Overall Rating, тем лучше
2. **По прибыльности:** PNL % должен быть положительным
3. **По стабильности:** Больше сделок = стабильнее
4. **По риску:** Меньше Max Drawdown = безопаснее
5. **По универсальности:** Хорошие результаты на всех парах

## 💡 Советы

- **Сравнивайте стратегии на одной паре** для справедливого сравнения
- **Проверяйте Win Rate** - высокий win rate при низком profit factor может быть обманчивым
- **Смотрите на Max Drawdown** - важно знать максимальную просадку
- **Анализируйте equity curve** - плавный рост лучше резких скачков

