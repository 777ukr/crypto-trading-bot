#!/usr/bin/env python3
"""
Исправление отображения результатов в веб-интерфейсе
Проверяет и исправляет проблемы с пустой страницей Backtesting
"""

import json
import subprocess
from pathlib import Path
from datetime import datetime
from typing import List, Dict

FREQTRADE_DIR = Path(__file__).parent
RESULTS_DIR = FREQTRADE_DIR / "user_data" / "backtest_results"
CONFIG_PATH = FREQTRADE_DIR.parent / "config" / "freqtrade_config.json"


def verify_backtest_files():
    """Проверяет и исправляет структуру файлов бэктестов"""
    print("🔍 Проверка файлов бэктестов...\n")
    
    zip_files = list(RESULTS_DIR.glob("*.zip"))
    meta_files = list(RESULTS_DIR.glob("*.meta.json"))
    
    print(f"📦 ZIP файлов: {len(zip_files)}")
    print(f"📄 Meta файлов: {len(meta_files)}")
    
    # Проверяем соответствие
    missing_meta = []
    missing_zip = []
    
    for zip_file in zip_files:
        meta_file = zip_file.with_suffix(".meta.json")
        if not meta_file.exists():
            missing_meta.append(zip_file.name)
    
    for meta_file in meta_files:
        zip_file = meta_file.with_suffix(".zip")
        if not zip_file.exists():
            missing_zip.append(meta_file.name)
    
    if missing_meta:
        print(f"\n⚠️  ZIP файлы без метаданных: {len(missing_meta)}")
    if missing_zip:
        print(f"\n⚠️  Meta файлы без ZIP: {len(missing_zip)}")
    
    if not missing_meta and not missing_zip:
        print("\n✅ Все файлы корректны!")
    
    return len(zip_files), len(meta_files)


def create_results_catalog():
    """Создает каталог результатов для удобного просмотра"""
    catalog = {
        "generated_at": datetime.now().isoformat(),
        "total_backtests": 0,
        "strategies": {},
        "files": []
    }
    
    # Собираем информацию о всех бэктестах
    for meta_file in sorted(RESULTS_DIR.glob("*.meta.json"), key=lambda x: x.stat().st_mtime, reverse=True):
        try:
            meta_data = json.loads(meta_file.read_text())
            strategy_name = list(meta_data.keys())[0] if meta_data else "Unknown"
            
            filename = meta_file.name.replace(".meta.json", "")
            zip_file = RESULTS_DIR / f"{filename}.zip"
            
            if zip_file.exists():
                entry = {
                    "filename": f"{filename}.zip",
                    "strategy": strategy_name,
                    "meta_file": meta_file.name,
                    "size_bytes": zip_file.stat().st_size,
                    "created_at": datetime.fromtimestamp(meta_file.stat().st_mtime).isoformat(),
                    "web_ui_url": f"http://127.0.0.1:8081/backtesting",
                    "api_url": f"http://127.0.0.1:8081/api/v1/backtest/history/result?filename={filename}.zip&strategy={strategy_name}"
                }
                
                catalog["files"].append(entry)
                catalog["total_backtests"] += 1
                
                if strategy_name not in catalog["strategies"]:
                    catalog["strategies"][strategy_name] = 0
                catalog["strategies"][strategy_name] += 1
        except Exception as e:
            print(f"⚠️  Ошибка при обработке {meta_file.name}: {e}")
    
    # Сохраняем каталог
    catalog_file = RESULTS_DIR / "catalog.json"
    with open(catalog_file, 'w') as f:
        json.dump(catalog, f, indent=2)
    
    print(f"\n📋 Каталог создан: {catalog_file}")
    print(f"   Всего бэктестов: {catalog['total_backtests']}")
    print(f"   Стратегий: {len(catalog['strategies'])}")
    for strategy, count in catalog['strategies'].items():
        print(f"      - {strategy}: {count} бэктестов")
    
    return catalog


def generate_web_ui_guide():
    """Генерирует руководство по использованию веб-интерфейса"""
    guide = f"""# 📊 Руководство по просмотру результатов в Freqtrade Web UI

## 🎯 Проблема: Пустая страница Backtesting

Если страница http://127.0.0.1:8081/backtesting пустая, выполните следующие шаги:

### ✅ Шаг 1: Проверка файлов

```bash
cd /home/crypto/sites/cryptotrader.com/freqtrade
python3 fix_web_ui_display.py
```

Это проверит все файлы и создаст каталог результатов.

### ✅ Шаг 2: Перезапуск веб-сервера

Если API возвращает 503 или результаты не видны:

1. **Остановите текущий процесс freqtrade:**
   ```bash
   # Найдите процесс
   ps aux | grep freqtrade
   # Остановите (Ctrl+C или kill PID)
   ```

2. **Перезапустите:**
   ```bash
   cd /home/crypto/sites/cryptotrader.com/freqtrade
   source .venv/bin/activate
   freqtrade trade --config ../config/freqtrade_config.json --strategy TestStrategy
   ```

3. **Подождите 10-15 секунд** для инициализации

4. **Обновите страницу** http://127.0.0.1:8081/backtesting

### ✅ Шаг 3: Использование CLI (если веб-интерфейс не работает)

```bash
# Показать все результаты
freqtrade backtesting-show

# Показать конкретный результат
freqtrade backtesting-show --backtest-filename=backtest-result-2025-11-04_15-51-46.zip

# Показать рейтинг по парам
freqtrade backtesting-show --show-pair-list
```

### ✅ Шаг 4: Прямой доступ к результатам

Откройте HTML страницу с быстрым доступом:
```
file:///home/crypto/sites/cryptotrader.com/freqtrade/user_data/quick_access_results.html
```

## 📊 Текущие результаты

Всего бэктестов: {len(list(RESULTS_DIR.glob("*.zip")))}

### Доступные стратегии:
"""
    
    strategies = set()
    for meta_file in RESULTS_DIR.glob("*.meta.json"):
        try:
            meta_data = json.loads(meta_file.read_text())
            strategy = list(meta_data.keys())[0] if meta_data else "Unknown"
            strategies.add(strategy)
        except:
            pass
    
    for strategy in sorted(strategies):
        guide += f"- {strategy}\n"
    
    guide += f"""
## 🔗 Прямые ссылки

- **Backtesting:** http://127.0.0.1:8081/backtesting
- **Dashboard:** http://127.0.0.1:8081/dashboard
- **API History:** http://127.0.0.1:8081/api/v1/backtest/history

## 💡 Если ничего не помогает

1. Проверьте логи: `tail -f freqtrade.log`
2. Проверьте права доступа: `chmod 644 user_data/backtest_results/*`
3. Попробуйте другой браузер
4. Очистите кэш браузера (Ctrl+Shift+Delete)
"""
    
    guide_file = FREQTRADE_DIR / "WEB_UI_TROUBLESHOOTING.md"
    guide_file.write_text(guide, encoding='utf-8')
    
    print(f"\n📖 Руководство создано: {guide_file}")
    return guide_file


def main():
    """Главная функция"""
    print("🔧 Исправление отображения результатов в веб-интерфейсе\n")
    print(f"{'='*70}\n")
    
    # 1. Проверка файлов
    zip_count, meta_count = verify_backtest_files()
    
    # 2. Создание каталога
    print(f"\n{'='*70}")
    catalog = create_results_catalog()
    
    # 3. Генерация руководства
    print(f"\n{'='*70}")
    guide_file = generate_web_ui_guide()
    
    print(f"\n{'='*70}")
    print("✅ Проверка завершена!")
    print(f"{'='*70}\n")
    
    print("📊 Итоги:")
    print(f"   - ZIP файлов: {zip_count}")
    print(f"   - Meta файлов: {meta_count}")
    print(f"   - Всего бэктестов: {catalog['total_backtests']}")
    print(f"   - Стратегий: {len(catalog['strategies'])}")
    
    print(f"\n🌐 Откройте веб-интерфейс:")
    print(f"   http://127.0.0.1:8081/backtesting")
    
    print(f"\n💡 Если страница пустая:")
    print(f"   1. Перезапустите freqtrade веб-сервер")
    print(f"   2. Обновите страницу (F5 или Ctrl+Shift+R)")
    print(f"   3. Проверьте руководство: {guide_file.name}")
    print(f"   4. Используйте CLI: freqtrade backtesting-show")


if __name__ == "__main__":
    main()

