#!/usr/bin/env python3
"""
FastAPI Server for Strategy Rating System
Full-featured web interface for managing strategies, running backtests, and viewing rankings
"""

import os
import json
import subprocess
import asyncio
from pathlib import Path
from datetime import datetime, timedelta
from typing import List, Dict, Optional
import psycopg2
from psycopg2.extras import RealDictCursor, execute_values
from psycopg2.pool import ThreadedConnectionPool

from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

# Configuration
FREQTRADE_DIR = Path(__file__).parent
CONFIG_PATH = FREQTRADE_DIR.parent / "config" / "freqtrade_config.json"
STRATEGIES_DIR = FREQTRADE_DIR / "user_data" / "strategies"
RESULTS_DIR = FREQTRADE_DIR / "user_data" / "backtest_results"
WEB_DIR = FREQTRADE_DIR / "user_data" / "web"

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql://postgres:postgres@localhost:5432/cryptotrader"
)

app = FastAPI(title="Strategy Rating System", version="1.0.0")

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Static files
app.mount("/static", StaticFiles(directory=str(WEB_DIR)), name="static")

# Database pool
db_pool = None

def get_db_connection():
    """Get database connection"""
    global db_pool
    if db_pool is None:
        db_pool = ThreadedConnectionPool(1, 10, DATABASE_URL)
    return db_pool.getconn()

def return_db_connection(conn):
    """Return connection to pool"""
    if db_pool:
        db_pool.putconn(conn)

# Pydantic models
class BacktestRequest(BaseModel):
    strategy_name: str
    pairs: List[str] = ["BTC/USDT"]
    timerange: Optional[str] = None
    timeframe: str = "5m"
    leverage: int = 1

class StrategyFilter(BaseModel):
    min_trades: int = 0
    min_profit: float = -100
    max_leverage: Optional[int] = None
    exclude_stalled: bool = True
    exclude_bias: bool = True
    pairs: Optional[List[str]] = None

# API Routes
@app.get("/")
async def root():
    """Main page"""
    html_file = WEB_DIR / "rating_ui.html"
    if html_file.exists():
        return HTMLResponse(content=html_file.read_text())
    return {"message": "Strategy Rating System API"}

@app.get("/api/strategies")
async def get_strategies():
    """Get list of all strategies"""
    strategies = []
    for file in STRATEGIES_DIR.glob("*.py"):
        if file.name != "__init__.py" and not file.name.startswith("_"):
            strategies.append({
                "name": file.stem,
                "file": file.name,
                "size": file.stat().st_size,
                "modified": datetime.fromtimestamp(file.stat().st_mtime).isoformat()
            })
    return {"strategies": strategies}

@app.get("/api/rankings")
async def get_rankings(
    min_trades: int = 0,
    min_profit: float = -100,
    max_leverage: Optional[int] = None,
    exclude_stalled: bool = True,
    exclude_bias: bool = True,
    sort_by: str = "ninja_score",
    order: str = "desc",
    limit: int = 100
):
    """Get strategy rankings with filters"""
    conn = get_db_connection()
    try:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            where_clauses = ["is_active = TRUE"]
            params = []
            
            if min_trades > 0:
                where_clauses.append(f"median_total_trades >= %s")
                params.append(min_trades)
            
            if min_profit > -100:
                where_clauses.append(f"median_total_profit_pct >= %s")
                params.append(min_profit)
            
            if max_leverage:
                where_clauses.append(f"leverage <= %s")
                params.append(max_leverage)
            
            if exclude_stalled:
                where_clauses.append("is_stalled = FALSE")
            
            if exclude_bias:
                where_clauses.append("has_lookahead_bias = FALSE")
            
            # Не фильтруем по leverage - показываем все (1x, 2x, 5x, 10x и т.д.)
            
            order_by = "DESC" if order.lower() == "desc" else "ASC"
            
            sql = f"""
                SELECT 
                    strategy_name, exchange, stake_currency,
                    total_backtests, median_total_trades, median_win_rate,
                    median_total_profit_pct, median_profit_factor,
                    median_max_drawdown, median_sharpe_ratio,
                    median_sortino_ratio, median_calmar_ratio,
                    backtest_win_percentage, ninja_score,
                    leverage, is_stalled, has_lookahead_bias,
                    updated_at
                FROM strategy_ratings
                WHERE {' AND '.join(where_clauses)}
                ORDER BY {sort_by} {order_by}
                LIMIT %s
            """
            params.append(limit)
            
            cur.execute(sql, params)
            results = cur.fetchall()
            
            return {
                "rankings": [dict(r) for r in results],
                "total": len(results)
            }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        return_db_connection(conn)

@app.post("/api/backtest/run")
async def run_backtest(request: BacktestRequest, background_tasks: BackgroundTasks):
    """Run backtest for strategy"""
    # Validate strategy exists
    strategy_file = STRATEGIES_DIR / f"{request.strategy_name}.py"
    if not strategy_file.exists():
        raise HTTPException(status_code=404, detail=f"Strategy {request.strategy_name} not found")
    
    # Generate timerange if not provided
    if not request.timerange:
        end_date = datetime.now().strftime("%Y%m%d")
        start_date = (datetime.now() - timedelta(days=30)).strftime("%Y%m%d")
        timerange = f"{start_date}-{end_date}"
    else:
        timerange = request.timerange
    
    # Add to background tasks
    background_tasks.add_task(
        execute_backtest,
        request.strategy_name,
        request.pairs,
        timerange,
        request.timeframe,
        request.leverage
    )
    
    return {
        "status": "started",
        "strategy": request.strategy_name,
        "pairs": request.pairs,
        "message": "Backtest started in background"
    }

async def execute_backtest(strategy_name: str, pairs: List[str], timerange: str, timeframe: str, leverage: int):
    """Execute backtest in background and save to PostgreSQL"""
    from strategy_rating_system_postgresql import StrategyRatingSystemPostgreSQL
    
    cmd = [
        "freqtrade", "backtesting",
        "--config", str(CONFIG_PATH),
        "--strategy", strategy_name,
        "--timerange", timerange,
        "--timeframe", timeframe,
        "--pairs", ",".join(pairs),
        "--export", "trades",
        "--breakdown", "month",
        "--cache", "none"
    ]
    
    try:
        result = subprocess.run(
            cmd,
            cwd=str(FREQTRADE_DIR),
            capture_output=True,
            text=True,
            timeout=600
        )
        
        if result.returncode == 0:
            # После успешного бэктеста обновляем рейтинг в БД
            print(f"✅ Бэктест завершен для {strategy_name}, обновление рейтинга...")
            rating_system = StrategyRatingSystemPostgreSQL()
            rating_system.process_and_save_to_db()
        else:
            print(f"❌ Ошибка бэктеста для {strategy_name}: {result.stderr[:200]}")
        
    except Exception as e:
        print(f"Error running backtest: {e}")

@app.get("/api/backtest/history")
async def get_backtest_history(strategy_name: Optional[str] = None, limit: int = 50):
    """Get backtest history"""
    conn = get_db_connection()
    try:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            if strategy_name:
                cur.execute("""
                    SELECT * FROM backtest_results
                    WHERE strategy_name = %s
                    ORDER BY created_at DESC
                    LIMIT %s
                """, (strategy_name, limit))
            else:
                cur.execute("""
                    SELECT * FROM backtest_results
                    ORDER BY created_at DESC
                    LIMIT %s
                """, (limit,))
            
            results = cur.fetchall()
            return {"history": [dict(r) for r in results]}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        return_db_connection(conn)

@app.delete("/api/strategies/{strategy_name}")
async def delete_strategy(strategy_name: str):
    """Delete strategy and its backtests"""
    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            # Mark strategy as inactive
            cur.execute("""
                UPDATE strategy_ratings
                SET is_active = FALSE
                WHERE strategy_name = %s
            """, (strategy_name,))
            
            conn.commit()
            
            return {"status": "deleted", "strategy": strategy_name}
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        return_db_connection(conn)

@app.get("/api/stats")
async def get_stats():
    """Get overall statistics"""
    conn = get_db_connection()
    try:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            # Total strategies
            cur.execute("SELECT COUNT(*) as total FROM strategy_ratings WHERE is_active = TRUE")
            total_strategies = cur.fetchone()["total"]
            
            # Total backtests
            cur.execute("SELECT COUNT(*) as total FROM backtest_results")
            total_backtests = cur.fetchone()["total"]
            
            # Top strategy
            cur.execute("""
                SELECT strategy_name, ninja_score, median_total_profit_pct
                FROM strategy_ratings
                WHERE is_active = TRUE
                ORDER BY ninja_score DESC
                LIMIT 1
            """)
            top_strategy = dict(cur.fetchone()) if cur.rowcount > 0 else None
            
            return {
                "total_strategies": total_strategies,
                "total_backtests": total_backtests,
                "top_strategy": top_strategy
            }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        return_db_connection(conn)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8889)

