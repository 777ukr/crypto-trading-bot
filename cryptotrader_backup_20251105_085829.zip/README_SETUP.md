# 🚀 Быстрый старт - Crypto Trader

## Что нужно для работы

### 1. Обязательные зависимости
- **PostgreSQL** - база данных
- **Rust** 1.70+ - компилятор
- **Cargo** - менеджер пакетов

### 2. Переменные окружения

Создайте файл `.env` в корне проекта:

```bash
# ОБЯЗАТЕЛЬНО: PostgreSQL connection string
DATABASE_URL=postgresql://postgres:password@localhost:5432/cryptotrader

# ОПЦИОНАЛЬНО: Gate.io API ключи (для загрузки исторических данных)
GATE_API_KEY=your_api_key_here
GATE_API_SECRET=your_api_secret_here

# ОПЦИОНАЛЬНО: Уровень логирования (по умолчанию: info)
RUST_LOG=info
```

### 3. Настройка PostgreSQL

```bash
# Создать базу данных
createdb cryptotrader

# Применить схему
psql cryptotrader < database/schema.sql

# Проверить подключение
psql cryptotrader -c "SELECT 1;"
```

## Запуск

### 1. Загрузка исторических данных

```bash
# Загрузить данные BTC, ETH, SOL за последние 180 дней
cargo run --bin load_historical_data --features database,gate_exec

# Или с указанием уровня логирования
RUST_LOG=debug cargo run --bin load_historical_data --features database,gate_exec
```

**Примечание**: API ключи не обязательны - скрипт использует публичные endpoints Gate.io

### 2. Запуск Investor Portal

```bash
# Запустить веб-портал
cargo run --bin investor_portal --features dashboard,database,gate_exec

# Откройте в браузере: http://localhost:8080
```

### 3. Запуск тестов

```bash
# Все тесты
cargo test --features gate_exec

# Интеграционные тесты API
cargo test --features dashboard --test integration_tests
```

## Логирование

### Уровни логирования через RUST_LOG:

```bash
# Только ошибки
RUST_LOG=error cargo run --bin investor_portal

# Отладка конкретного модуля
RUST_LOG=rust_test::backtest=debug cargo run --bin investor_portal

# Полная отладка
RUST_LOG=debug cargo run --bin investor_portal
```

### Доступные уровни:
- `error` - только ошибки
- `warn` - предупреждения
- `info` - информационные сообщения (по умолчанию)
- `debug` - отладочная информация
- `trace` - максимальная детализация

## Что нужно предоставить

### Для полной работы нужны:

1. ✅ **DATABASE_URL** - строка подключения к PostgreSQL
2. ⚠️ **GATE_API_KEY** (опционально) - для полного доступа к данным
3. ⚠️ **GATE_API_SECRET** (опционально) - для полного доступа к данным

### Как получить Gate.io API ключи:

1. Зарегистрируйтесь на [Gate.io](https://www.gate.io/)
2. API Management → Create API Key
3. Выберите права: **Read Only** (достаточно для загрузки данных)
4. Скопируйте ключи в `.env`

**Без API ключей**:
- ✅ Загрузка исторических данных работает (публичные endpoints)
- ✅ Бэктестинг работает
- ✅ Investor Portal работает
- ❌ Live торговля не работает (нужны Trade права)

## Структура проекта

```
├── src/
│   ├── bin/
│   │   ├── investor_portal.rs      # Веб-портал
│   │   └── load_historical_data.rs # Загрузка данных
│   ├── backtest/                   # Бэктестер
│   ├── strategy/                   # Торговые стратегии
│   ├── database/                   # PostgreSQL репозиторий
│   └── utils/
│       └── logging.rs              # Система логирования
├── tests/
│   └── integration_tests.rs        # API тесты
├── database/
│   └── schema.sql                  # SQL схема
└── templates/
    └── investor_portal.html        # Веб-интерфейс
```

## Проверка работоспособности

### 1. Проверка БД
```bash
cargo run --bin investor_portal --features dashboard,database,gate_exec
# Должно быть: ✅ Подключено к PostgreSQL
```

### 2. Проверка загрузки данных
```bash
cargo run --bin load_historical_data --features database,gate_exec
# Должно загрузить данные для BTC_USDT, ETH_USDT, SOL_USDT
```

### 3. Проверка API
```bash
# Запустить portal
cargo run --bin investor_portal --features dashboard,database,gate_exec

# В другом терминале проверить endpoints
curl http://localhost:8080/api/strategies
curl http://localhost:8080/api/leverages
curl http://localhost:8080/api/symbols
```

## Следующие шаги

1. ✅ Настройте `.env` с `DATABASE_URL`
2. ✅ Запустите `load_historical_data` для загрузки данных
3. ✅ Запустите `investor_portal` для веб-интерфейса
4. ✅ Запустите бэктесты через веб-интерфейс
5. ✅ Анализируйте результаты

## Дополнительная документация

- `docs/API_SETUP.md` - Детальная настройка API ключей
- `docs/HFT_BACKTEST_SPEC.md` - Спецификация бэктестера
- `docs/API_ENDPOINTS.md` - Документация API
