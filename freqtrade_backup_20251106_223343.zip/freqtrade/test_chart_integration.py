#!/usr/bin/env python3
"""
Интеграционные тесты для графика
Проверяет полный цикл: API → данные → визуализация
"""

import subprocess
import time
import requests
from pathlib import Path

API_URL = "http://localhost:8889"
FREQTRADE_DIR = Path(__file__).parent

def check_api_server():
    """Проверка доступности API сервера"""
    try:
        res = requests.get(f"{API_URL}/api/strategies", timeout=5)
        return res.status_code == 200
    except:
        return False

def test_chart_integration():
    """Полный тест интеграции графика"""
    print("🧪 Интеграционное тестирование графика...")
    
    if not check_api_server():
        print("❌ API сервер недоступен. Запустите: python3 rating_api_server.py")
        return False
    
    # 1. Получаем список стратегий
    print("1️⃣  Получение списка стратегий...")
    try:
        res = requests.get(f"{API_URL}/api/strategies", timeout=5)
        strategies = res.json().get("strategies", [])
        if not strategies:
            print("⚠️  Нет стратегий для тестирования")
            return True
        print(f"   ✅ Найдено стратегий: {len(strategies)}")
    except Exception as e:
        print(f"   ❌ Ошибка: {e}")
        return False
    
    # 2. Тестируем получение данных графика
    print("2️⃣  Тестирование получения данных графика...")
    strategy_name = strategies[0]["name"]
    
    try:
        res = requests.get(
            f"{API_URL}/api/strategies/{strategy_name}/chart-data",
            params={"pair": "BTC/USDT", "timeframe": "5m"},
            timeout=10
        )
        
        if res.status_code != 200:
            print(f"   ❌ Ошибка: {res.status_code}")
            return False
        
        data = res.json()
        
        # Проверяем наличие данных
        if data.get('has_data'):
            print(f"   ✅ Данные получены:")
            print(f"      - OHLCV: {len(data.get('ohlcv', []))} свечей")
            print(f"      - Входы: {len(data.get('entry_points', []))}")
            print(f"      - Выходы: {len(data.get('exit_points', []))}")
        else:
            print(f"   ⚠️  Нет данных (нужно запустить бэктест)")
        
        return True
        
    except Exception as e:
        print(f"   ❌ Ошибка: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_error_handling():
    """Тест обработки ошибок"""
    print("3️⃣  Тестирование обработки ошибок...")
    
    test_cases = [
        ("NonExistentStrategy", "Несуществующая стратегия"),
        ("", "Пустое имя"),
        ("StrategyWithSpecialChars!@#", "Специальные символы"),
    ]
    
    for strategy, description in test_cases:
        try:
            res = requests.get(
                f"{API_URL}/api/strategies/{strategy}/chart-data",
                timeout=5
            )
            # Должен вернуть 200 с пустыми данными
            if res.status_code == 200:
                data = res.json()
                if not data.get('has_data', True):
                    print(f"   ✅ {description}: корректно обработано")
                else:
                    print(f"   ⚠️  {description}: вернул данные (неожиданно)")
            else:
                print(f"   ⚠️  {description}: статус {res.status_code}")
        except Exception as e:
            print(f"   ❌ {description}: ошибка {e}")
    
    return True

if __name__ == "__main__":
    print("=" * 60)
    print("ИНТЕГРАЦИОННОЕ ТЕСТИРОВАНИЕ ГРАФИКА")
    print("=" * 60)
    
    success = True
    success &= test_chart_integration()
    success &= test_error_handling()
    
    print("\n" + "=" * 60)
    if success:
        print("✅ ИНТЕГРАЦИОННЫЕ ТЕСТЫ ПРОЙДЕНЫ")
    else:
        print("❌ НЕКОТОРЫЕ ТЕСТЫ ПРОВАЛЕНЫ")
    print("=" * 60)




