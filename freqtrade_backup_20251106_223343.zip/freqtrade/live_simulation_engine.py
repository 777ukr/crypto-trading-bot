#!/usr/bin/env python3
"""
Live Simulation Engine - Real-time trading simulation with demo account
Uses Freqtrade dry-run mode for risk-free testing
"""

import asyncio
import subprocess
import json
import logging
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from dataclasses import dataclass, asdict
import time

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

FREQTRADE_DIR = Path(__file__).parent
CONFIG_PATH = FREQTRADE_DIR.parent / "config" / "freqtrade_config.json"
RESULTS_DIR = FREQTRADE_DIR / "user_data" / "backtest_results"
SIMULATION_DIR = FREQTRADE_DIR / "user_data" / "simulations"
SIMULATION_DIR.mkdir(parents=True, exist_ok=True)

@dataclass
class Trade:
    """Trade record"""
    timestamp: str
    pair: str
    side: str  # 'long' or 'short'
    entry_price: float
    exit_price: Optional[float]
    amount: float
    profit_pct: float
    profit_abs: float
    stop_loss: float
    take_profit: float
    status: str  # 'open', 'closed', 'stopped', 'taken'

@dataclass
class SimulationState:
    """Simulation state"""
    strategy_name: str
    demo_balance: float
    total_stop_loss: float  # Total stop-loss percentage
    active_trades: List[Trade]
    closed_trades: List[Trade]
    total_profit: float
    total_profit_pct: float
    start_time: str
    last_update: str

class StrategyAutoSwitcher:
    """Auto-switch between long and short strategies (Hummingbot-inspired)"""
    
    def __init__(self, long_strategy: str, short_strategy: str, switch_threshold: float = -0.20):
        self.long_strategy = long_strategy
        self.short_strategy = short_strategy
        self.switch_threshold = switch_threshold
        self.current_strategy = long_strategy
        self.current_direction = "long"
        self.switch_history: List[Dict] = []
    
    def check_switch_condition(self, current_pnl: float) -> bool:
        """Check if should switch strategy"""
        if current_pnl <= self.switch_threshold:
            return True
        return False
    
    async def switch_strategy(self, current_pnl: float) -> Optional[str]:
        """Execute strategy switch"""
        if not self.check_switch_condition(current_pnl):
            return None
        
        # Switch to opposite strategy
        if self.current_direction == "long":
            new_strategy = self.short_strategy
            new_direction = "short"
            reason = f"Long strategy hit {current_pnl:.2%} PnL, switching to short"
        else:
            new_strategy = self.long_strategy
            new_direction = "long"
            reason = f"Short strategy hit {current_pnl:.2%} PnL, switching to long"
        
        # Log switch
        switch_record = {
            "timestamp": datetime.now().isoformat(),
            "from_strategy": self.current_strategy,
            "to_strategy": new_strategy,
            "from_direction": self.current_direction,
            "to_direction": new_direction,
            "pnl_at_switch": current_pnl,
            "reason": reason
        }
        self.switch_history.append(switch_record)
        
        # Update current strategy
        old_strategy = self.current_strategy
        self.current_strategy = new_strategy
        self.current_direction = new_direction
        
        logger.info(f"Авто-смена стратегии: {old_strategy} -> {new_strategy} ({reason})")
        
        return new_strategy
    
    def get_opposite_strategy(self) -> str:
        """Get opposite strategy name"""
        if self.current_direction == "long":
            return self.short_strategy
        else:
            return self.long_strategy

class LiveSimulationEngine:
    """Real-time trading simulation using Freqtrade dry-run with auto-switching"""
    
    def __init__(self, strategy_name: str, demo_balance: float = 10000, 
                 total_stop_loss: float = -0.20, opposite_strategy: Optional[str] = None,
                 auto_switch_enabled: bool = False):
        self.strategy_name = strategy_name
        self.demo_balance = demo_balance
        self.initial_balance = demo_balance
        self.total_stop_loss = total_stop_loss
        self.active_trades: List[Trade] = []
        self.closed_trades: List[Trade] = []
        self.state_file = SIMULATION_DIR / f"{strategy_name}_state.json"
        self.trade_log_file = SIMULATION_DIR / f"{strategy_name}_trades.jsonl"
        self.is_running = False
        self.process = None
        
        # Auto-switching support (Hummingbot-inspired)
        self.auto_switch_enabled = auto_switch_enabled
        if auto_switch_enabled and opposite_strategy:
            # Determine long/short from strategy names
            long_strat = strategy_name if "short" not in strategy_name.lower() else opposite_strategy
            short_strat = opposite_strategy if "short" not in strategy_name.lower() else strategy_name
            self.strategy_switcher = StrategyAutoSwitcher(
                long_strategy=long_strat,
                short_strategy=short_strat,
                switch_threshold=total_stop_loss
            )
        else:
            self.strategy_switcher = None
        
    def start_simulation(self, pairs: List[str] = ["BTC/USDT"], 
                        timeframe: str = "30s"):
        """Start live simulation"""
        # Store pairs and timeframe for potential restarts
        self.simulation_pairs = pairs
        self.simulation_timeframe = timeframe
        
        logger.info(f"Запуск live-симуляции для {self.strategy_name}")
        logger.info(f"   Демо-баланс: ${self.demo_balance:.2f}")
        logger.info(f"   Пары: {', '.join(pairs)}")
        logger.info(f"   Timeframe: {timeframe}")
        
        # Save initial state
        self._save_state()
        
        # Start Freqtrade in dry-run mode
        cmd = [
            "freqtrade", "trade",
            "--config", str(CONFIG_PATH),
            "--strategy", self.strategy_name,
            "--dry-run",
            "--dry-run-wallet", str(self.demo_balance),
            "--pairs", ",".join(pairs),
            "--timeframe", timeframe
        ]
        
        # Start process in background
        self.process = subprocess.Popen(
            cmd,
            cwd=str(FREQTRADE_DIR),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        
        self.is_running = True
        logger.info(f"Симуляция запущена (PID: {self.process.pid})")
        
        # Start monitoring
        asyncio.create_task(self._monitor_simulation())
    
    async def _monitor_simulation(self):
        """Monitor simulation and update state"""
        while self.is_running:
            try:
                # Check for new trades
                await self._update_trades()
                
                # Check total stop-loss and auto-switch if enabled
                if self._check_total_stop_loss():
                    if self.auto_switch_enabled and self.strategy_switcher:
                        # Try to switch to opposite strategy
                        current_pnl = self._get_total_pnl_pct()
                        new_strategy = await self.strategy_switcher.switch_strategy(current_pnl)
                        
                        if new_strategy:
                            logger.info(f"Переключение на противоположную стратегию: {new_strategy}")
                            await self._switch_to_strategy(new_strategy)
                            # Reset balance tracking for new strategy
                            self.initial_balance = self.demo_balance
                            continue
                    
                    # If no auto-switch or switch failed, stop simulation
                    logger.warning("Общий стоп-лосс достигнут! Остановка стратегии...")
                    await self.stop_simulation()
                    break
                
                # Save state
                self._save_state()
                
                await asyncio.sleep(5)  # Update every 5 seconds
                
            except Exception as e:
                logger.error(f"Ошибка мониторинга: {e}", exc_info=True)
                await asyncio.sleep(10)
    
    async def _update_trades(self):
        """Update trade list from Freqtrade logs"""
        # Read Freqtrade trade logs
        # This is a simplified version - in production, parse actual Freqtrade logs
        pass
    
    def _check_total_stop_loss(self) -> bool:
        """Check if total stop-loss reached"""
        if self.demo_balance <= 0:
            return True
        
        total_profit_pct = (self.demo_balance - self.initial_balance) / self.initial_balance
        return total_profit_pct <= self.total_stop_loss
    
    def _get_total_pnl_pct(self) -> float:
        """Get total PnL percentage"""
        if self.initial_balance <= 0:
            return 0.0
        return (self.demo_balance - self.initial_balance) / self.initial_balance
    
    async def _switch_to_strategy(self, new_strategy: str):
        """Switch to a new strategy and restart simulation"""
        # Stop current simulation
        if self.process:
            self.process.terminate()
            try:
                self.process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self.process.kill()
        
        # Update strategy name
        self.strategy_name = new_strategy
        self.state_file = SIMULATION_DIR / f"{new_strategy}_state.json"
        self.trade_log_file = SIMULATION_DIR / f"{new_strategy}_trades.jsonl"
        
        # Reset initial balance for new strategy
        self.initial_balance = self.demo_balance
        
        logger.info(f"Переключено на стратегию: {new_strategy}")
        logger.info(f"   Новый начальный баланс: ${self.initial_balance:.2f}")
        
        # Restart simulation with new strategy
        pairs = getattr(self, 'simulation_pairs', ["BTC/USDT"])
        timeframe = getattr(self, 'simulation_timeframe', "30s")
        self.start_simulation(pairs=pairs, timeframe=timeframe)
    
    async def stop_simulation(self):
        """Stop simulation"""
        if self.process:
            self.process.terminate()
            try:
                self.process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self.process.kill()
        
        self.is_running = False
        self._save_state()
        logger.info("Симуляция остановлена")
    
    def _save_state(self):
        """Save simulation state to JSON"""
        state = SimulationState(
            strategy_name=self.strategy_name,
            demo_balance=self.demo_balance,
            total_stop_loss=self.total_stop_loss,
            active_trades=[asdict(t) for t in self.active_trades],
            closed_trades=[asdict(t) for t in self.closed_trades],
            total_profit=self.demo_balance - self.initial_balance,
            total_profit_pct=(self.demo_balance - self.initial_balance) / self.initial_balance * 100,
            start_time=datetime.now().isoformat(),
            last_update=datetime.now().isoformat()
        )
        
        with open(self.state_file, 'w') as f:
            json.dump(asdict(state), f, indent=2)
    
    def get_state(self) -> Dict:
        """Get current simulation state"""
        if self.state_file.exists():
            with open(self.state_file, 'r') as f:
                return json.load(f)
        return {}
    
    def log_trade(self, trade: Trade):
        """Log trade to file"""
        with open(self.trade_log_file, 'a') as f:
            f.write(json.dumps(asdict(trade)) + '\n')

if __name__ == "__main__":
    # Test
    engine = LiveSimulationEngine("EMA_PullbackStrategy", demo_balance=10000)
    engine.start_simulation(["BTC/USDT"], timeframe="30s")
    
    # Run for 60 seconds
    time.sleep(60)
    asyncio.run(engine.stop_simulation())



