#!/bin/bash
# Запуск бэктестов для всех стратегий

API_URL="http://localhost:8889/api/backtest/run"
PAIRS="BTC/USDT ETH/USDT SOL/USDT"
TIMEFRAME="5m"
TIMERANGE="20240101-"

echo "🚀 Запуск бэктестов для всех стратегий..."
echo ""

# Список всех стратегий (кроме MShotStrategy, у которой уже есть данные)
STRATEGIES=(
    "AdvancedIndicatorStrategy"
    "E0V1E_20231004_085308"
    "ElliotV5_SMA"
    "EMA_PullbackStrategy"
    "EMA_ShortPeakStrategy"
    "HookStrategy"
    "MStrikeStrategy"
    "ShortBreakdownStrategy"
    "ShortScalpingStrategy"
    "ShortTrendStrategy"
    "TestStrategy"
)

for strategy in "${STRATEGIES[@]}"; do
    echo "📊 Запуск бэктеста для: $strategy"
    
    # Формируем JSON запрос
    JSON_DATA=$(cat <<EOF
{
    "strategy_name": "$strategy",
    "pairs": ["BTC/USDT", "ETH/USDT", "SOL/USDT"],
    "timeframe": "$TIMEFRAME",
    "timerange": "$TIMERANGE"
}
EOF
)
    
    # Отправляем запрос
    RESPONSE=$(curl -s -X POST "$API_URL" \
        -H "Content-Type: application/json" \
        -d "$JSON_DATA")
    
    if echo "$RESPONSE" | grep -q "started"; then
        echo "  ✅ Запущен"
    else
        echo "  ❌ Ошибка: $RESPONSE"
    fi
    
    # Небольшая задержка между запросами
    sleep 2
done

echo ""
echo "✅ Все бэктесты запущены!"
echo "📊 Проверьте статус: curl http://localhost:8889/api/backtest/progress"
echo "⏱️  Ожидаемое время: 10-30 минут для всех стратегий"

