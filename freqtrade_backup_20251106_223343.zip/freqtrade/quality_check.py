#!/usr/bin/env python3
"""
Quality Check - Проверка качества кода
"""

import ast
import subprocess
from pathlib import Path
from typing import List, Dict

FREQTRADE_DIR = Path(__file__).parent

def check_python_syntax():
    """Проверка синтаксиса Python"""
    print("🔍 Проверка синтаксиса Python...")
    
    errors = []
    python_files = list(FREQTRADE_DIR.glob("*.py"))
    
    for py_file in python_files[:20]:  # Проверяем первые 20 файлов
        try:
            with open(py_file, 'r', encoding='utf-8') as f:
                ast.parse(f.read())
        except SyntaxError as e:
            errors.append(f"{py_file.name}: {e}")
    
    if errors:
        print(f"  ❌ Найдено ошибок: {len(errors)}")
        for error in errors[:5]:
            print(f"    - {error}")
        return False
    else:
        print(f"  ✅ Все файлы валидны ({len(python_files)} проверено)")
        return True

def check_imports():
    """Проверка импортов"""
    print("🔍 Проверка импортов...")
    
    try:
        # Проверяем основные модули
        import fastapi
        import uvicorn
        import requests
        print("  ✅ Основные модули доступны")
        return True
    except ImportError as e:
        print(f"  ❌ Ошибка импорта: {e}")
        return False

def check_file_structure():
    """Проверка структуры файлов"""
    print("🔍 Проверка структуры файлов...")
    
    required_files = [
        "rating_api_server.py",
        "strategy_rating_system_standalone.py",
        "user_data/web/rating_ui.html",
    ]
    
    missing = []
    for file_path in required_files:
        full_path = FREQTRADE_DIR / file_path
        if not full_path.exists():
            missing.append(file_path)
    
    if missing:
        print(f"  ❌ Отсутствуют файлы: {', '.join(missing)}")
        return False
    else:
        print("  ✅ Все необходимые файлы на месте")
        return True

def main():
    """Главная функция"""
    import sys
    
    print("=" * 70)
    print("🔍 QUALITY CHECK")
    print("=" * 70)
    print()
    
    checks = [
        ("Python Syntax", check_python_syntax),
        ("Imports", check_imports),
        ("File Structure", check_file_structure),
    ]
    
    results = []
    for name, check_func in checks:
        try:
            result = check_func()
            results.append((name, result))
        except Exception as e:
            print(f"  ❌ Ошибка проверки {name}: {e}")
            results.append((name, False))
        print()
    
    # Итоги
    print("=" * 70)
    passed = sum(1 for _, result in results if result)
    total = len(results)
    print(f"✅ Успешно: {passed}/{total}")
    print("=" * 70)
    
    return passed == total

if __name__ == "__main__":
    import sys
    success = main()
    sys.exit(0 if success else 1)

