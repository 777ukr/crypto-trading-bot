#!/usr/bin/env python3
"""
Run New Backtests for Effective Strategies
Запускает новые бэктесты для наиболее эффективных стратегий
"""

import subprocess
import sys
from pathlib import Path
import logging
import json
import time

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

FREQTRADE_DIR = Path(__file__).parent
STRATEGIES_DIR = FREQTRADE_DIR / "user_data" / "strategies"

# Default pairs and timeframes
DEFAULT_PAIRS = ["BTC/USDT", "ETH/USDT", "SOL/USDT"]
DEFAULT_TIMEFRAME = "5m"
DEFAULT_TIMERANGE = "20240101-"  # From Jan 1, 2024 to now

def get_all_strategies():
    """Get all strategy files"""
    strategies = []
    for file in STRATEGIES_DIR.glob("*.py"):
        if file.name != "__init__.py" and not file.name.startswith("_"):
            strategies.append(file.stem)
    return sorted(strategies)

def run_backtest(strategy_name: str, pairs: list = None, timeframe: str = None, 
                 timerange: str = None):
    """Run backtest for a strategy"""
    if pairs is None:
        pairs = DEFAULT_PAIRS
    if timeframe is None:
        timeframe = DEFAULT_TIMEFRAME
    if timerange is None:
        timerange = DEFAULT_TIMERANGE
    
    pairs_str = " ".join(pairs)
    
    # Try different ways to run freqtrade
    # First try direct command
    cmd = [
        "freqtrade", "backtesting",
        "--strategy", strategy_name,
        "--pairs", *pairs,
        "--timeframe", timeframe,
        "--timerange", timerange,
        "--breakdown", "month"
    ]
    
    # If freqtrade is not in PATH, try python -m freqtrade
    import shutil
    if not shutil.which("freqtrade"):
        cmd = [
            sys.executable, "-m", "freqtrade", "backtesting",
            "--strategy", strategy_name,
            "--pairs", *pairs,
            "--timeframe", timeframe,
            "--timerange", timerange,
            "--breakdown", "month"
        ]
    
    logger.info(f"🚀 Running backtest for {strategy_name} on {pairs_str} ({timeframe})")
    
    try:
        result = subprocess.run(
            cmd,
            cwd=str(FREQTRADE_DIR),
            capture_output=True,
            text=True,
            timeout=600  # 10 minutes timeout
        )
        
        if result.returncode == 0:
            logger.info(f"✅ Backtest completed for {strategy_name}")
            return True
        else:
            logger.error(f"❌ Backtest failed for {strategy_name}: {result.stderr}")
            return False
    except subprocess.TimeoutExpired:
        logger.error(f"⏱️  Backtest timeout for {strategy_name}")
        return False
    except Exception as e:
        logger.error(f"❌ Error running backtest for {strategy_name}: {e}")
        return False

def run_backtests_for_strategies(strategy_names: list = None, 
                                  pairs: list = None,
                                  timeframe: str = None):
    """Run backtests for multiple strategies"""
    if strategy_names is None:
        # Get top strategies (you can filter by ranking here)
        strategy_names = get_all_strategies()
    
    logger.info(f"📊 Running backtests for {len(strategy_names)} strategies")
    
    results = {}
    for i, strategy in enumerate(strategy_names, 1):
        logger.info(f"\n[{i}/{len(strategy_names)}] Processing {strategy}...")
        success = run_backtest(strategy, pairs=pairs, timeframe=timeframe)
        results[strategy] = success
        
        # Small delay between backtests
        if i < len(strategy_names):
            time.sleep(2)
    
    # Summary
    successful = sum(1 for v in results.values() if v)
    logger.info(f"\n📊 Summary: {successful}/{len(strategy_names)} backtests successful")
    
    return results

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Run new backtests for strategies")
    parser.add_argument("--strategies", nargs="+", help="Strategy names to test")
    parser.add_argument("--pairs", nargs="+", default=DEFAULT_PAIRS, help="Trading pairs")
    parser.add_argument("--timeframe", default=DEFAULT_TIMEFRAME, help="Timeframe")
    parser.add_argument("--all", action="store_true", help="Test all strategies")
    
    args = parser.parse_args()
    
    if args.all:
        strategies = get_all_strategies()
    elif args.strategies:
        strategies = args.strategies
    else:
        # Default: test top strategies (you can customize this)
        strategies = get_all_strategies()[:10]  # Top 10 strategies
    
    run_backtests_for_strategies(
        strategy_names=strategies,
        pairs=args.pairs,
        timeframe=args.timeframe
    )

