#!/bin/bash
# Комплексное тестирование всей системы

echo "=========================================="
echo "🧪 ПОЛНОЕ ТЕСТИРОВАНИЕ СИСТЕМЫ"
echo "=========================================="
echo ""

cd /home/crypto/sites/cryptotrader.com/freqtrade

# Цвета для вывода
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 1. Проверка API сервера
echo "1️⃣  Проверка API сервера..."
if curl -s http://localhost:8889/api/strategies > /dev/null 2>&1; then
    echo -e "   ${GREEN}✅ API сервер доступен${NC}"
else
    echo -e "   ${RED}❌ API сервер недоступен${NC}"
    echo "   Запустите: python3 rating_api_server.py"
    exit 1
fi

# 2. Комплексное тестирование
echo ""
echo "2️⃣  Комплексное тестирование..."
python3 comprehensive_test_suite.py
COMPREHENSIVE_EXIT=$?

# 3. Интеграционные тесты
echo ""
echo "3️⃣  Интеграционные тесты..."
python3 integration_test_suite.py
INTEGRATION_EXIT=$?

# 4. Тесты API
echo ""
echo "4️⃣  Тесты API..."
python3 test_api_endpoints.py
API_EXIT=$?

# 5. Тесты графика
echo ""
echo "5️⃣  Тесты графика..."
python3 test_chart_api.py
CHART_EXIT=$?

# 6. Тесты системы
echo ""
echo "6️⃣  Тесты системы..."
python3 test_complete_system.py
SYSTEM_EXIT=$?

# 7. Проверка синтаксиса
echo ""
echo "7️⃣  Проверка синтаксиса Python..."
find . -name "*.py" -type f ! -path "./.venv/*" ! -path "./freqtrade/*" ! -path "./build_helpers/*" | head -10 | while read file; do
    python3 -m py_compile "$file" 2>&1 | grep -q "Error" && echo -e "   ${RED}❌ $file${NC}" || echo -e "   ${GREEN}✅ $(basename $file)${NC}"
done

# Итоги
echo ""
echo "=========================================="
echo "📊 ИТОГИ ТЕСТИРОВАНИЯ"
echo "=========================================="

CRITICAL_FAILED=0
[ $API_EXIT -ne 0 ] && CRITICAL_FAILED=$((CRITICAL_FAILED + 1))
[ $CHART_EXIT -ne 0 ] && CRITICAL_FAILED=$((CRITICAL_FAILED + 1))
[ $SYSTEM_EXIT -ne 0 ] && CRITICAL_FAILED=$((CRITICAL_FAILED + 1))

# Comprehensive и Integration могут иметь не критичные провалы
NON_CRITICAL=0
[ $COMPREHENSIVE_EXIT -ne 0 ] && NON_CRITICAL=$((NON_CRITICAL + 1))
[ $INTEGRATION_EXIT -ne 0 ] && NON_CRITICAL=$((NON_CRITICAL + 1))

if [ $CRITICAL_FAILED -eq 0 ]; then
    if [ $NON_CRITICAL -eq 0 ]; then
        echo -e "${GREEN}✅ ВСЕ ТЕСТЫ ПРОЙДЕНЫ!${NC}"
    else
        echo -e "${YELLOW}⚠️  ВСЕ КРИТИЧНЫЕ ТЕСТЫ ПРОЙДЕНЫ${NC}"
        echo -e "${YELLOW}   (Не критичные провалы: $NON_CRITICAL - это нормально)${NC}"
    fi
    echo ""
    echo "🎯 Система готова к использованию!"
    echo "   Откройте: http://localhost:8889"
    exit 0
else
    echo -e "${RED}❌ КРИТИЧНЫЕ ТЕСТЫ ПРОВАЛЕНЫ: $CRITICAL_FAILED${NC}"
    exit 1
fi

