#!/bin/bash
# Скрипт для запуска сервера и тестов Playwright

cd "$(dirname "$0")"

PORT=8889
MAX_WAIT=30

echo "🚀 Запуск сервера и тестов..."
echo ""

# 1. Остановка старых процессов
echo "1️⃣  Остановка старых процессов..."
pkill -f "uvicorn.*rating_api_server" 2>/dev/null
sleep 2
echo "   ✅ Готово"
echo ""

# 2. Проверка порта
echo "2️⃣  Проверка порта $PORT..."
if lsof -Pi :$PORT -sTCP:LISTEN -t >/dev/null 2>&1 ; then
    echo "   ⚠️  Порт $PORT занят, пытаемся освободить..."
    PID=$(lsof -ti :$PORT)
    kill -9 $PID 2>/dev/null
    sleep 2
fi

if lsof -Pi :$PORT -sTCP:LISTEN -t >/dev/null 2>&1 ; then
    echo "   ❌ Не удалось освободить порт $PORT"
    exit 1
fi
echo "   ✅ Порт свободен"
echo ""

# 3. Запуск сервера в фоне
echo "3️⃣  Запуск API сервера на порту $PORT..."
python3 -m uvicorn rating_api_server:app --host 0.0.0.0 --port $PORT > /tmp/rating_server.log 2>&1 &
SERVER_PID=$!
echo "   PID: $SERVER_PID"
echo "   Лог: /tmp/rating_server.log"
echo ""

# 4. Ожидание запуска сервера
echo "4️⃣  Ожидание запуска сервера..."
for i in $(seq 1 $MAX_WAIT); do
    if curl -s http://localhost:$PORT/api/stats > /dev/null 2>&1; then
        echo "   ✅ Сервер запущен (попытка $i/$MAX_WAIT)"
        break
    fi
    if [ $i -eq $MAX_WAIT ]; then
        echo "   ❌ Сервер не запустился за $MAX_WAIT секунд"
        echo "   Лог ошибок:"
        tail -20 /tmp/rating_server.log
        kill $SERVER_PID 2>/dev/null
        exit 1
    fi
    sleep 1
    echo -n "."
done
echo ""
echo ""

# 5. Проверка работы API
echo "5️⃣  Проверка API..."
STATUS=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:$PORT/api/stats)
if [ "$STATUS" = "200" ]; then
    echo "   ✅ API работает (HTTP $STATUS)"
else
    echo "   ⚠️  API вернул код $STATUS"
fi
echo ""

# 6. Запуск Playwright тестов
echo "6️⃣  Запуск Playwright тестов..."
if [ -f "tests/test_playwright_e2e.spec.ts" ]; then
    if command -v npx &> /dev/null; then
        npx playwright test tests/test_playwright_e2e.spec.ts --reporter=list 2>&1
        TEST_RESULT=$?
        if [ $TEST_RESULT -eq 0 ]; then
            echo ""
            echo "   ✅ Все тесты прошли успешно!"
        else
            echo ""
            echo "   ⚠️  Некоторые тесты провалились (код: $TEST_RESULT)"
        fi
    else
        echo "   ⚠️  npx не найден, пропускаем Playwright тесты"
        echo "   💡 Установите: npm install -g playwright && npx playwright install"
    fi
else
    echo "   ⚠️  Файл tests/test_playwright_e2e.spec.ts не найден"
fi
echo ""

# 7. Итоги
echo "=========================================="
echo "📊 ИТОГИ"
echo "=========================================="
echo "✅ Сервер запущен: http://localhost:$PORT"
echo "✅ PID сервера: $SERVER_PID"
echo "📝 Лог сервера: /tmp/rating_server.log"
echo ""
echo "💡 Для остановки сервера:"
echo "   kill $SERVER_PID"
echo ""
echo "💡 Для просмотра логов:"
echo "   tail -f /tmp/rating_server.log"
echo ""

