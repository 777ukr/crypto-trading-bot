#!/bin/bash
# Ручные тесты API без Playwright

cd "$(dirname "$0")"

API_URL="http://localhost:8889"
echo "🧪 Ручное тестирование API..."
echo ""

# Проверка доступности сервера
echo "1️⃣  Проверка доступности сервера..."
if curl -s "$API_URL/api/stats" > /dev/null 2>&1; then
    echo "   ✅ Сервер доступен"
else
    echo "   ❌ Сервер недоступен"
    exit 1
fi
echo ""

# Тест 1: Главная страница
echo "2️⃣  Тест главной страницы..."
STATUS=$(curl -s -o /dev/null -w "%{http_code}" "$API_URL/")
if [ "$STATUS" = "200" ]; then
    echo "   ✅ Главная страница загружается (HTTP $STATUS)"
else
    echo "   ❌ Главная страница недоступна (HTTP $STATUS)"
fi
echo ""

# Тест 2: API статистики
echo "3️⃣  Тест API статистики..."
STATS_RESPONSE=$(curl -s "$API_URL/api/stats")
if echo "$STATS_RESPONSE" | python3 -m json.tool > /dev/null 2>&1; then
    echo "   ✅ API /api/stats возвращает валидный JSON"
    echo "$STATS_RESPONSE" | python3 -m json.tool | head -10
else
    echo "   ❌ API /api/stats возвращает невалидный JSON"
    echo "$STATS_RESPONSE"
fi
echo ""

# Тест 3: API стратегий
echo "4️⃣  Тест API стратегий..."
STRATEGIES_RESPONSE=$(curl -s "$API_URL/api/strategies")
if echo "$STRATEGIES_RESPONSE" | python3 -m json.tool > /dev/null 2>&1; then
    echo "   ✅ API /api/strategies возвращает валидный JSON"
    STRATEGY_COUNT=$(echo "$STRATEGIES_RESPONSE" | python3 -c "import sys, json; data=json.load(sys.stdin); print(len(data.get('strategies', [])))" 2>/dev/null || echo "0")
    echo "   📊 Найдено стратегий: $STRATEGY_COUNT"
else
    echo "   ❌ API /api/strategies возвращает невалидный JSON"
fi
echo ""

# Тест 4: API рейтинга
echo "5️⃣  Тест API рейтинга..."
RANKINGS_RESPONSE=$(curl -s "$API_URL/api/rankings?limit=5")
if echo "$RANKINGS_RESPONSE" | python3 -m json.tool > /dev/null 2>&1; then
    echo "   ✅ API /api/rankings возвращает валидный JSON"
    RANKING_COUNT=$(echo "$RANKINGS_RESPONSE" | python3 -c "import sys, json; data=json.load(sys.stdin); print(len(data.get('rankings', [])))" 2>/dev/null || echo "0")
    echo "   📊 Найдено записей в рейтинге: $RANKING_COUNT"
else
    echo "   ❌ API /api/rankings возвращает невалидный JSON"
fi
echo ""

# Тест 5: Проверка структуры ответа
echo "6️⃣  Проверка структуры ответа /api/stats..."
STATS_KEYS=$(echo "$STATS_RESPONSE" | python3 -c "import sys, json; data=json.load(sys.stdin); print(' '.join(data.keys()))" 2>/dev/null || echo "")
if [ -n "$STATS_KEYS" ]; then
    echo "   ✅ Ключи в ответе: $STATS_KEYS"
else
    echo "   ⚠️  Не удалось извлечь ключи"
fi
echo ""

echo "=========================================="
echo "✅ Ручное тестирование завершено"
echo "=========================================="
echo ""
echo "💡 Для полного тестирования с Playwright:"
echo "   1. Установите Node.js и npm"
echo "   2. npm install -g playwright"
echo "   3. npx playwright install"
echo "   4. npx playwright test tests/test_playwright_e2e.spec.ts"
echo ""

