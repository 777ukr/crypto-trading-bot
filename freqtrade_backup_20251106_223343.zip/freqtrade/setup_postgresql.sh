#!/bin/bash
# Настройка PostgreSQL для быстрой работы

echo "🗄️  Настройка PostgreSQL..."
echo ""

# Проверяем установлен ли PostgreSQL
if ! command -v psql &> /dev/null; then
    echo "📦 Установка PostgreSQL..."
    apt-get update -qq
    apt-get install -y postgresql postgresql-contrib
fi

# Проверяем статус PostgreSQL
if systemctl is-active --quiet postgresql; then
    echo "✅ PostgreSQL запущен"
else
    echo "🚀 Запуск PostgreSQL..."
    systemctl start postgresql
    systemctl enable postgresql
fi

# Создаем базу данных и пользователя
echo ""
echo "📊 Настройка базы данных..."

sudo -u postgres psql <<EOF
-- Создаем базу данных если не существует
SELECT 'CREATE DATABASE cryptotrader'
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'cryptotrader')\gexec

-- Создаем пользователя если не существует
DO \$\$
BEGIN
   IF NOT EXISTS (SELECT FROM pg_user WHERE usename = 'cryptotrader') THEN
      CREATE USER cryptotrader WITH PASSWORD 'cryptotrader123';
   END IF;
END
\$\$;

-- Выдаем права
GRANT ALL PRIVILEGES ON DATABASE cryptotrader TO cryptotrader;
ALTER DATABASE cryptotrader OWNER TO cryptotrader;
EOF

# Устанавливаем psycopg2
echo ""
echo "📦 Установка psycopg2-binary..."
pip3 install -q psycopg2-binary

# Настраиваем производительность
echo ""
echo "⚡ Настройка производительности PostgreSQL..."

sudo -u postgres psql -d cryptotrader <<EOF
-- Настройки для быстрой работы
ALTER SYSTEM SET shared_buffers = '256MB';
ALTER SYSTEM SET effective_cache_size = '1GB';
ALTER SYSTEM SET maintenance_work_mem = '128MB';
ALTER SYSTEM SET checkpoint_completion_target = 0.9;
ALTER SYSTEM SET wal_buffers = '16MB';
ALTER SYSTEM SET default_statistics_target = 100;
ALTER SYSTEM SET random_page_cost = 1.1;
ALTER SYSTEM SET effective_io_concurrency = 200;
ALTER SYSTEM SET work_mem = '16MB';
ALTER SYSTEM SET min_wal_size = '1GB';
ALTER SYSTEM SET max_wal_size = '4GB';
EOF

# Перезапускаем PostgreSQL
echo ""
echo "🔄 Перезапуск PostgreSQL..."
systemctl restart postgresql

echo ""
echo "✅ PostgreSQL настроен!"
echo ""
echo "📝 Подключение:"
echo "   DATABASE_URL=postgresql://cryptotrader:cryptotrader123@localhost:5432/cryptotrader"
echo ""
echo "🔧 Создание таблиц (если нужно):"
echo "   python3 strategy_rating_system_postgresql.py"


