#!/usr/bin/env python3
"""
Скрипт для автоматического тестирования стратегий в Freqtrade
и составления рейтинга на основе метрик
"""

import json
import subprocess
import sys
import os
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional
import pandas as pd

# Конфигурация
FREQTRADE_DIR = Path(__file__).parent
CONFIG_PATH = FREQTRADE_DIR.parent / "config" / "freqtrade_config.json"
STRATEGIES_DIR = FREQTRADE_DIR / "user_data" / "strategies"
RESULTS_DIR = FREQTRADE_DIR / "user_data" / "backtest_results"

# Параметры бэктеста
# Внимание: Gate.io ограничивает до 10000 точек (≈34 дня для 5m)
# Используем последние 30 дней
from datetime import datetime, timedelta
END_DATE = datetime.now().strftime("%Y%m%d")
START_DATE = (datetime.now() - timedelta(days=30)).strftime("%Y%m%d")
TIMERANGE = f"{START_DATE}-{END_DATE}"
TIMEFRAME = "5m"
EXCHANGE = "gateio"
PAIRS = ["BTC/USDT"]  # Начинаем с одной пары для теста


class StrategyRanker:
    """Класс для тестирования и ранжирования стратегий"""
    
    def __init__(self):
        self.results = []
        self.rankings = []
    
    def find_strategies(self) -> List[str]:
        """Находит все стратегии в папке strategies"""
        strategies = []
        for file in STRATEGIES_DIR.glob("*.py"):
            if file.name != "__init__.py" and not file.name.startswith("_"):
                strategy_name = file.stem
                strategies.append(strategy_name)
        return strategies
    
    def run_backtest(self, strategy_name: str, pair: str) -> Optional[Dict]:
        """Запускает бэктест для стратегии"""
        print(f"\n{'='*60}")
        print(f"Тестирование: {strategy_name} на {pair}")
        print(f"{'='*60}")
        
        cmd = [
            "freqtrade", "backtesting",
            "--config", str(CONFIG_PATH),
            "--strategy", strategy_name,
            "--timerange", TIMERANGE,
            "--timeframe", TIMEFRAME,
            "--pairs", pair,
            "--breakdown", "month",
            "--export", "trades",
            "--cache", "none"
        ]
        
        try:
            result = subprocess.run(
                cmd,
                cwd=str(FREQTRADE_DIR),
                capture_output=True,
                text=True,
                timeout=600  # 10 минут на стратегию (бэктест может быть долгим)
            )
            
            if result.returncode != 0:
                print(f"❌ Ошибка при бэктесте: {result.stderr}")
                return None
            
            # Парсим результаты из вывода
            output = result.stdout
            metrics = self.parse_backtest_output(output, strategy_name, pair)
            
            return metrics
            
        except subprocess.TimeoutExpired:
            print(f"⏱️  Таймаут при тестировании {strategy_name}")
            return None
        except Exception as e:
            print(f"❌ Ошибка: {e}")
            return None
    
    def parse_backtest_output(self, output: str, strategy_name: str, pair: str) -> Dict:
        """Парсит вывод freqtrade backtesting"""
        metrics = {
            "strategy": strategy_name,
            "pair": pair,
            "total_trades": 0,
            "winning_trades": 0,
            "losing_trades": 0,
            "total_profit": 0.0,
            "profit_pct": 0.0,
            "max_drawdown": 0.0,
            "profit_factor": 0.0,
            "win_rate": 0.0,
            "sharpe_ratio": 0.0,
            "avg_trade_duration": 0.0,
        }
        
        # Парсим ключевые метрики из вывода
        lines = output.split('\n')
        for line in lines:
            # Total trades
            if "Total trades" in line or "Total" in line and "trades" in line.lower():
                try:
                    parts = line.split()
                    for i, part in enumerate(parts):
                        if part.isdigit():
                            metrics["total_trades"] = int(part)
                            break
                except:
                    pass
            
            # Profit
            if "Profit" in line and "%" in line:
                try:
                    # Ищем процент прибыли
                    parts = line.split()
                    for part in parts:
                        if "%" in part:
                            metrics["profit_pct"] = float(part.replace("%", ""))
                            break
                except:
                    pass
            
            # Drawdown
            if "Drawdown" in line or "Max Drawdown" in line:
                try:
                    parts = line.split()
                    for part in parts:
                        if "%" in part:
                            metrics["max_drawdown"] = abs(float(part.replace("%", "").replace("-", "")))
                            break
                except:
                    pass
        
        # Пытаемся загрузить результаты из CSV
        trades_file = RESULTS_DIR / f"{strategy_name}_{pair.replace('/', '_')}_trades.csv"
        if trades_file.exists():
            try:
                df = pd.read_csv(trades_file)
                if not df.empty:
                    metrics["total_trades"] = len(df)
                    metrics["winning_trades"] = len(df[df["profit_abs"] > 0])
                    metrics["losing_trades"] = len(df[df["profit_abs"] <= 0])
                    metrics["total_profit"] = df["profit_abs"].sum()
                    metrics["win_rate"] = (metrics["winning_trades"] / metrics["total_trades"] * 100) if metrics["total_trades"] > 0 else 0
                    
                    # Profit factor
                    wins = df[df["profit_abs"] > 0]["profit_abs"].sum()
                    losses = abs(df[df["profit_abs"] < 0]["profit_abs"].sum())
                    metrics["profit_factor"] = wins / losses if losses > 0 else 0
                    
                    # Avg trade duration
                    if "close_date" in df.columns and "open_date" in df.columns:
                        df["duration"] = pd.to_datetime(df["close_date"]) - pd.to_datetime(df["open_date"])
                        metrics["avg_trade_duration"] = df["duration"].mean().total_seconds() / 60  # минуты
            except Exception as e:
                print(f"⚠️  Не удалось загрузить CSV: {e}")
        
        return metrics
    
    def calculate_rating(self, metrics: Dict) -> Dict:
        """Вычисляет рейтинг стратегии на основе метрик"""
        # Profitability Score (0-10)
        profit_score = min(metrics["profit_pct"] / 10.0, 10.0) if metrics["profit_pct"] > 0 else 0
        pf_score = min(metrics["profit_factor"] / 5.0 * 10.0, 10.0) if metrics["profit_factor"] > 0 else 0
        wr_score = metrics["win_rate"] / 10.0
        profitability_score = (profit_score * 0.4 + pf_score * 0.3 + wr_score * 0.3)
        
        # Stability Score (0-10) - на основе количества сделок
        stability_score = min(metrics["total_trades"] / 100.0 * 10.0, 10.0)
        
        # Risk Score (0-10) - обратный к drawdown
        risk_score = max(0, 10.0 - (metrics["max_drawdown"] / 10.0))
        
        # Fill Rate Score - упрощенно, берем win_rate как proxy
        fill_rate_score = min(metrics["win_rate"] / 10.0, 10.0)
        
        # Overall Rating
        overall_rating = (
            profitability_score * 0.35 +
            stability_score * 0.25 +
            risk_score * 0.25 +
            fill_rate_score * 0.15
        )
        
        # Stars (0-5)
        stars = min(5, int(overall_rating / 2.0))
        
        return {
            "profitability_score": round(profitability_score, 2),
            "stability_score": round(stability_score, 2),
            "risk_score": round(risk_score, 2),
            "fill_rate_score": round(fill_rate_score, 2),
            "overall_rating": round(overall_rating, 2),
            "stars": stars
        }
    
    def test_all_strategies(self):
        """Тестирует все стратегии"""
        strategies = self.find_strategies()
        print(f"\n🔍 Найдено стратегий: {len(strategies)}")
        for s in strategies:
            print(f"  - {s}")
        
        if not strategies:
            print("❌ Стратегии не найдены!")
            return
        
        # Тестируем каждую стратегию на каждой паре
        for strategy in strategies:
            for pair in PAIRS:
                metrics = self.run_backtest(strategy, pair)
                if metrics:
                    rating = self.calculate_rating(metrics)
                    result = {**metrics, **rating}
                    self.results.append(result)
        
        # Сохраняем результаты
        self.save_results()
        
        # Выводим рейтинг
        self.print_rankings()
    
    def save_results(self):
        """Сохраняет результаты в JSON"""
        RESULTS_DIR.mkdir(parents=True, exist_ok=True)
        results_file = RESULTS_DIR / f"strategy_rankings_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        with open(results_file, 'w') as f:
            json.dump(self.results, f, indent=2)
        
        print(f"\n💾 Результаты сохранены: {results_file}")
    
    def print_rankings(self):
        """Выводит рейтинг стратегий"""
        if not self.results:
            print("❌ Нет результатов для ранжирования")
            return
        
        # Сортируем по overall_rating
        sorted_results = sorted(self.results, key=lambda x: x.get("overall_rating", 0), reverse=True)
        
        print(f"\n{'='*80}")
        print("🏆 РЕЙТИНГ СТРАТЕГИЙ")
        print(f"{'='*80}")
        print(f"{'№':<4} {'Стратегия':<25} {'Пара':<12} {'Рейтинг':<8} {'⭐':<6} {'PNL%':<8} {'Сделок':<8}")
        print(f"{'-'*80}")
        
        for i, result in enumerate(sorted_results, 1):
            strategy = result.get("strategy", "N/A")
            pair = result.get("pair", "N/A")
            rating = result.get("overall_rating", 0.0)
            stars = "⭐" * result.get("stars", 0)
            pnl = result.get("profit_pct", 0.0)
            trades = result.get("total_trades", 0)
            
            print(f"{i:<4} {strategy:<25} {pair:<12} {rating:<8.2f} {stars:<6} {pnl:<8.2f} {trades:<8}")
        
        print(f"{'='*80}\n")


def main():
    """Главная функция"""
    print("🚀 Запуск автоматического тестирования стратегий Freqtrade")
    print(f"📁 Директория: {FREQTRADE_DIR}")
    print(f"⏰ Таймфрейм: {TIMEFRAME}")
    print(f"📅 Период: {TIMERANGE} (последние 30 дней)")
    print(f"💰 Пары: {', '.join(PAIRS)}")
    print(f"⚠️  Внимание: Gate.io ограничивает до 10000 точек (≈34 дня для 5m)")
    
    ranker = StrategyRanker()
    ranker.test_all_strategies()


if __name__ == "__main__":
    main()

