#!/usr/bin/env python3
"""
Profitability Forecaster - Calculate expected profit at target price
Shows "What if" scenarios for strategy performance
"""

from typing import Dict, Optional, Tuple, List
from dataclasses import dataclass
import math

@dataclass
class ForecastResult:
    """Forecast result"""
    target_price: float
    current_price: float
    entry_price: float
    expected_profit_pct: float
    expected_profit_abs: float
    position_size: float
    risk_reward_ratio: float
    stop_loss_price: float
    take_profit_price: float
    probability_win: float  # Estimated win probability
    scenario: str  # 'bullish', 'bearish', 'neutral'

class ProfitabilityForecaster:
    """Calculate expected profit/loss at target price"""
    
    def __init__(self, stop_loss_pct: float = 0.0012, take_profit_pct: float = 0.11):
        self.stop_loss_pct = stop_loss_pct
        self.take_profit_pct = take_profit_pct
    
    def forecast_long(self, current_price: float, target_price: float,
                     entry_price: float, position_size: float) -> ForecastResult:
        """
        Forecast profit for long position
        
        Args:
            current_price: Current market price
            target_price: Target price to reach
            entry_price: Entry price of the position
            position_size: Position size in quote currency
        """
        # Calculate price change
        price_change_pct = (target_price - entry_price) / entry_price
        
        # Expected profit
        expected_profit_pct = price_change_pct
        expected_profit_abs = position_size * expected_profit_pct
        
        # Stop-loss and take-profit prices
        stop_loss_price = entry_price * (1 - self.stop_loss_pct)
        take_profit_price = entry_price * (1 + self.take_profit_pct)
        
        # Risk/Reward ratio
        risk = abs(entry_price - stop_loss_price) / entry_price
        reward = abs(take_profit_price - entry_price) / entry_price
        risk_reward = reward / risk if risk > 0 else 0
        
        # Probability estimation (simplified)
        # If target is between entry and take-profit, higher probability
        if target_price <= take_profit_price:
            probability = 0.7  # 70% chance
        elif target_price > take_profit_price:
            probability = 0.3  # 30% chance (over extension)
        else:
            probability = 0.5  # 50% chance
        
        # Scenario
        if target_price > entry_price:
            scenario = "bullish"
        elif target_price < entry_price:
            scenario = "bearish"
        else:
            scenario = "neutral"
        
        return ForecastResult(
            target_price=target_price,
            current_price=current_price,
            entry_price=entry_price,
            expected_profit_pct=expected_profit_pct,
            expected_profit_abs=expected_profit_abs,
            position_size=position_size,
            risk_reward_ratio=risk_reward,
            stop_loss_price=stop_loss_price,
            take_profit_price=take_profit_price,
            probability_win=probability,
            scenario=scenario
        )
    
    def forecast_short(self, current_price: float, target_price: float,
                     entry_price: float, position_size: float) -> ForecastResult:
        """Forecast profit for short position"""
        # For short, profit when price goes down
        price_change_pct = (entry_price - target_price) / entry_price
        
        expected_profit_pct = price_change_pct
        expected_profit_abs = position_size * expected_profit_pct
        
        stop_loss_price = entry_price * (1 + self.stop_loss_pct)
        take_profit_price = entry_price * (1 - self.take_profit_pct)
        
        risk = abs(stop_loss_price - entry_price) / entry_price
        reward = abs(entry_price - take_profit_price) / entry_price
        risk_reward = reward / risk if risk > 0 else 0
        
        if target_price >= take_profit_price:
            probability = 0.7
        elif target_price < take_profit_price:
            probability = 0.3
        else:
            probability = 0.5
        
        if target_price < entry_price:
            scenario = "bearish"
        elif target_price > entry_price:
            scenario = "bullish"
        else:
            scenario = "neutral"
        
        return ForecastResult(
            target_price=target_price,
            current_price=current_price,
            entry_price=entry_price,
            expected_profit_pct=expected_profit_pct,
            expected_profit_abs=expected_profit_abs,
            position_size=position_size,
            risk_reward_ratio=risk_reward,
            stop_loss_price=stop_loss_price,
            take_profit_price=take_profit_price,
            probability_win=probability,
            scenario=scenario
        )
    
    def forecast_multiple_targets(self, current_price: float, entry_price: float,
                                 position_size: float, target_prices: List[float],
                                 side: str = "long") -> List[ForecastResult]:
        """Forecast for multiple target prices"""
        results = []
        for target in target_prices:
            if side == "long":
                result = self.forecast_long(current_price, target, entry_price, position_size)
            else:
                result = self.forecast_short(current_price, target, entry_price, position_size)
            results.append(result)
        return results

if __name__ == "__main__":
    # Test
    forecaster = ProfitabilityForecaster()
    
    # Long position forecast
    result = forecaster.forecast_long(
        current_price=50000,
        target_price=51000,
        entry_price=50000,
        position_size=1000
    )
    
    print(f"Expected Profit: {result.expected_profit_pct*100:.2f}%")
    print(f"Expected Profit: ${result.expected_profit_abs:.2f}")
    print(f"Risk/Reward: {result.risk_reward_ratio:.2f}")
    print(f"Win Probability: {result.probability_win*100:.0f}%")


