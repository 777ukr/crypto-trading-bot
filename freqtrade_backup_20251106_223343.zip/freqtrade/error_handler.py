#!/usr/bin/env python3
"""
Centralized Error Handling - Централизованная обработка ошибок
"""

import logging
import traceback
from typing import Optional, Dict, Any
from datetime import datetime
from pathlib import Path

# Настройка логирования
LOG_DIR = Path(__file__).parent / "logs"
LOG_DIR.mkdir(exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(LOG_DIR / 'system.log'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

class ErrorHandler:
    """Централизованная обработка ошибок"""
    
    @staticmethod
    def handle_error(error: Exception, context: str = "", 
                    return_dict: bool = False) -> Optional[Dict[str, Any]]:
        """
        Обработать ошибку с логированием
        
        Args:
            error: Исключение
            context: Контекст ошибки
            return_dict: Вернуть словарь вместо None
        
        Returns:
            Dict с информацией об ошибке или None
        """
        error_info = {
            "error": str(error),
            "type": type(error).__name__,
            "context": context,
            "timestamp": datetime.now().isoformat(),
            "traceback": traceback.format_exc()
        }
        
        logger.error(f"{context}: {error}", exc_info=True)
        
        if return_dict:
            return error_info
        return None
    
    @staticmethod
    def safe_execute(func, *args, default=None, context: str = "", **kwargs):
        """
        Безопасное выполнение функции с обработкой ошибок
        
        Args:
            func: Функция для выполнения
            *args: Аргументы функции
            default: Значение по умолчанию при ошибке
            context: Контекст выполнения
            **kwargs: Ключевые аргументы функции
        
        Returns:
            Результат функции или default
        """
        try:
            return func(*args, **kwargs)
        except Exception as e:
            ErrorHandler.handle_error(e, context)
            return default
    
    @staticmethod
    def validate_input(data: Any, validator: callable, error_message: str = ""):
        """
        Валидация входных данных
        
        Args:
            data: Данные для валидации
            validator: Функция валидации (возвращает bool)
            error_message: Сообщение об ошибке
        
        Raises:
            ValueError: Если валидация не прошла
        """
        if not validator(data):
            error = ValueError(error_message or "Validation failed")
            ErrorHandler.handle_error(error, "Input validation")
            raise error

if __name__ == "__main__":
    # Тест
    result = ErrorHandler.safe_execute(
        lambda x: x / 0,
        10,
        default=0,
        context="Division test"
    )
    print(f"Result: {result}")



