#!/usr/bin/env python3
"""
Data Validator - Валидация всех входных данных
"""

from typing import Any, Dict, List, Optional
from pydantic import BaseModel, validator, Field
from datetime import datetime

class BacktestRequestModel(BaseModel):
    """Валидация запроса на бэктест"""
    strategy_name: str = Field(..., min_length=1, max_length=100)
    pairs: List[str] = Field(..., min_items=1, max_items=10)
    timeframe: str = Field(default="5m", pattern="^(1m|3m|5m|15m|30m|1h|2h|4h|1d)$")
    leverage: int = Field(default=1, ge=1, le=125)
    exchange: str = Field(default="binance", pattern="^(binance|bybit|gateio|kucoin)$")
    trading_type: str = Field(default="spot", pattern="^(spot|futures)$")
    deposit: float = Field(default=1000, gt=0, le=1000000)
    
    @validator('strategy_name')
    def validate_strategy_name(cls, v):
        # Проверка на безопасные символы
        if not v.replace('_', '').replace('-', '').isalnum():
            raise ValueError('Strategy name contains invalid characters')
        return v
    
    @validator('pairs')
    def validate_pairs(cls, v):
        # Проверка формата пар
        for pair in v:
            if '/' not in pair:
                raise ValueError(f'Invalid pair format: {pair}')
        return v

class ChartDataRequestModel(BaseModel):
    """Валидация запроса данных графика"""
    strategy_name: str = Field(..., min_length=1, max_length=100)
    pair: str = Field(default="BTC/USDT", pattern="^[A-Z]+/[A-Z]+$")
    timeframe: str = Field(default="5m", pattern="^(30s|1m|5m|15m|1h|4h|1d)$")
    limit: int = Field(default=500, ge=1, le=10000)

class RankingFilterModel(BaseModel):
    """Валидация фильтров рейтинга"""
    min_trades: int = Field(default=0, ge=0)
    min_profit: float = Field(default=-100, ge=-100, le=1000)
    max_leverage: Optional[int] = Field(default=None, ge=1, le=125)
    sort_by: str = Field(default="ninja_score")
    order: str = Field(default="desc", pattern="^(asc|desc)$")
    limit: int = Field(default=100, ge=1, le=1000)
    page: int = Field(default=1, ge=1)

def validate_strategy_name(name: str) -> bool:
    """Валидация имени стратегии"""
    if not name or len(name) > 100:
        return False
    if not name.replace('_', '').replace('-', '').isalnum():
        return False
    return True

def validate_pair(pair: str) -> bool:
    """Валидация торговой пары"""
    if '/' not in pair:
        return False
    parts = pair.split('/')
    if len(parts) != 2:
        return False
    return all(part.isalpha() for part in parts)

def validate_timeframe(timeframe: str) -> bool:
    """Валидация таймфрейма"""
    valid_timeframes = ["30s", "1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h", "1d"]
    return timeframe in valid_timeframes

if __name__ == "__main__":
    # Тесты валидации
    print("✅ Data Validator готов")
    
    # Тест валидации
    try:
        request = BacktestRequestModel(
            strategy_name="TestStrategy",
            pairs=["BTC/USDT"],
            timeframe="5m"
        )
        print(f"✅ Valid request: {request.strategy_name}")
    except Exception as e:
        print(f"❌ Validation error: {e}")



