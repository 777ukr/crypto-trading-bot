#!/usr/bin/env python3
"""
Cleanup Old Backtest Results
Удаляет старые или неверные результаты бэктестов
"""

import os
import json
import zipfile
from pathlib import Path
from datetime import datetime, timedelta
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

FREQTRADE_DIR = Path(__file__).parent
RESULTS_DIR = FREQTRADE_DIR / "user_data" / "backtest_results"
DB_PATH = FREQTRADE_DIR / "user_data" / "backtest_results.sqlite"

def is_backtest_invalid(zip_file: Path) -> bool:
    """Check if backtest result is invalid (no trades, zero profit, etc.)"""
    try:
        with zipfile.ZipFile(zip_file, 'r') as z:
            json_files = [f for f in z.namelist() if f.endswith('.json')]
            
            for json_file in json_files:
                try:
                    content = z.read(json_file)
                    data = json.loads(content)
                    
                    # Check if it's a strategy result
                    if isinstance(data, dict) and 'strategy' in data:
                        for strategy_name, strategy_data in data['strategy'].items():
                            trades = strategy_data.get('trades', [])
                            total_profit_pct = strategy_data.get('total_profit_pct', 0)
                            
                            # Invalid if no trades or all trades have 0% profit
                            if len(trades) == 0:
                                logger.info(f"❌ {zip_file.name}: No trades found")
                                return True
                            
                            # Check if all trades have 0% profit (likely invalid)
                            if len(trades) > 0:
                                all_zero_profit = all(
                                    abs(float(t.get('profit_pct', 0))) < 0.01 
                                    for t in trades
                                )
                                if all_zero_profit and total_profit_pct == 0:
                                    logger.info(f"❌ {zip_file.name}: All trades have 0% profit")
                                    return True
                except Exception as e:
                    logger.warning(f"Error reading {json_file} in {zip_file.name}: {e}")
                    continue
    except Exception as e:
        logger.error(f"Error processing {zip_file.name}: {e}")
        return False
    
    return False

def cleanup_old_backtests(older_than_days: int = 30, remove_invalid: bool = True):
    """Clean up old and invalid backtest results"""
    if not RESULTS_DIR.exists():
        logger.warning(f"Results directory not found: {RESULTS_DIR}")
        return
    
    zip_files = list(RESULTS_DIR.glob("*.zip"))
    logger.info(f"Found {len(zip_files)} backtest result files")
    
    removed_count = 0
    removed_size = 0
    
    cutoff_date = datetime.now() - timedelta(days=older_than_days)
    
    for zip_file in zip_files:
        try:
            file_mtime = datetime.fromtimestamp(zip_file.stat().st_mtime)
            file_size = zip_file.stat().st_size
            
            should_remove = False
            reason = ""
            
            # Check if file is too old
            if file_mtime < cutoff_date:
                should_remove = True
                reason = f"Older than {older_than_days} days"
            
            # Check if invalid
            elif remove_invalid and is_backtest_invalid(zip_file):
                should_remove = True
                reason = "Invalid (no trades or all 0% profit)"
            
            if should_remove:
                logger.info(f"🗑️  Removing {zip_file.name} ({reason})")
                removed_size += file_size
                zip_file.unlink()
                removed_count += 1
        except Exception as e:
            logger.error(f"Error processing {zip_file.name}: {e}")
    
    logger.info(f"✅ Cleanup complete: Removed {removed_count} files ({removed_size / 1024 / 1024:.2f} MB)")

if __name__ == "__main__":
    import sys
    
    older_than = int(sys.argv[1]) if len(sys.argv) > 1 else 30
    remove_invalid = sys.argv[2].lower() == 'true' if len(sys.argv) > 2 else True
    
    logger.info(f"Starting cleanup: older_than={older_than} days, remove_invalid={remove_invalid}")
    cleanup_old_backtests(older_than_days=older_than, remove_invalid=remove_invalid)

