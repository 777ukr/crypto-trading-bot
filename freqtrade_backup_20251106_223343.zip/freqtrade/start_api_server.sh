#!/bin/bash
# Скрипт для запуска API сервера

cd /home/crypto/sites/cryptotrader.com/freqtrade

echo "🚀 Запуск API сервера..."
echo ""

# Проверяем, не запущен ли уже сервер
if curl -s http://localhost:8889/api/strategies > /dev/null 2>&1; then
    echo "✅ API сервер уже запущен на http://localhost:8889"
    echo ""
    echo "Проверка доступности..."
    curl -s http://localhost:8889/api/stats | python3 -m json.tool | head -10
    exit 0
fi

# Проверяем наличие необходимых файлов
if [ ! -f "rating_api_server.py" ]; then
    echo "❌ Файл rating_api_server.py не найден!"
    exit 1
fi

# Запускаем сервер в фоне
echo "Запуск сервера на порту 8889..."
python3 rating_api_server.py > api_server.log 2>&1 &
SERVER_PID=$!

echo "PID сервера: $SERVER_PID"
echo ""

# Ждем запуска
echo "Ожидание запуска сервера..."
for i in {1..10}; do
    sleep 1
    if curl -s http://localhost:8889/api/strategies > /dev/null 2>&1; then
        echo "✅ Сервер успешно запущен!"
        echo ""
        echo "🌐 API доступен на: http://localhost:8889"
        echo "📊 Swagger документация: http://localhost:8889/docs"
        echo ""
        echo "Проверка доступности..."
        curl -s http://localhost:8889/api/stats | python3 -m json.tool | head -10
        echo ""
        echo "Для остановки сервера: kill $SERVER_PID"
        exit 0
    fi
    echo -n "."
done

echo ""
echo "❌ Сервер не запустился за 10 секунд"
echo "Проверьте логи: tail -f api_server.log"
exit 1


