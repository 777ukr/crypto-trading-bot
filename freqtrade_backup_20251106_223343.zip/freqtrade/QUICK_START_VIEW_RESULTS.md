# 🚀 Быстрый старт: Просмотр результатов стратегий

## 📍 Где смотреть результаты

### ⭐ Главная страница: Backtesting
```
http://127.0.0.1:8081/backtesting
```

**Это НЕ Dashboard!** Dashboard показывает только live торговлю.

## 🔐 Вход в веб-интерфейс

1. Откройте: **http://127.0.0.1:8081**
2. Логин: `freqtrader`
3. Пароль: см. `config/freqtrade_config.json` (секция `api_server.password`)

## 📊 Что вы увидите в Backtesting

### После запуска бэктеста:
- ✅ Результаты последнего бэктеста
- ✅ Графики equity curve
- ✅ Таблицы со статистикой
- ✅ Распределение сделок
- ✅ История всех бэктестов

## 🎯 Быстрые команды

### 1. Запустить тест всех стратегий:
```bash
cd /home/crypto/sites/cryptotrader.com/freqtrade
source .venv/bin/activate
python3 integrate_with_webui.py
```

### 2. Открыть результаты:
```bash
# Автоматически откроет браузер
xdg-open http://127.0.0.1:8081/backtesting
```

### 3. Показать результаты в консоли:
```bash
freqtrade backtesting-show
```

## 📁 Файлы с результатами

### CSV (детальные сделки):
```
user_data/backtest_results/*_trades.csv
```

### JSON (метаданные для веб-интерфейса):
```
user_data/backtest_results/*.json
```

### Индекс всех результатов:
```
user_data/backtest_results/index.json
```

## 🔗 Прямые ссылки API

### Список всех бэктестов:
```
http://127.0.0.1:8081/api/v1/backtest/history
```

### Конкретный результат:
```
http://127.0.0.1:8081/api/v1/backtest/history/result?filename=backtest_results_YYYYMMDD_HHMMSS.json&strategy=StrategyName
```

## 📝 Примеры

### Запустить бэктест одной стратегии:
```bash
freqtrade backtesting \
  --config ../config/freqtrade_config.json \
  --strategy MShotStrategy \
  --timerange 20251005-20251104 \
  --timeframe 5m \
  --pairs BTC/USDT \
  --export trades
```

### Просмотреть результаты:
1. Откройте: http://127.0.0.1:8081/backtesting
2. Результаты появятся автоматически

## ⚠️ Troubleshooting

### Страница не открывается:
- Проверьте, что веб-сервер запущен
- Проверьте порт: `netstat -tuln | grep 8081`

### Нет результатов:
- Запустите бэктест через веб-интерфейс или CLI
- Проверьте файлы в `user_data/backtest_results/`

### Ошибка авторизации:
- Проверьте логин/пароль в конфиге
- Убедитесь, что `api_server.enabled: true`

## 📚 Дополнительная документация

- `WEB_UI_INTEGRATION.md` - полная интеграция
- `HOW_TO_VIEW_RESULTS.md` - подробная инструкция
- `VIEW_RESULTS.md` - все способы просмотра

