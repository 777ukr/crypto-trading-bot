# 🚀 Быстрая проверка системы

## ✅ Сервер запущен

**PID**: $(cat api_server.pid 2>/dev/null || echo "N/A")
**Порт**: 8889
**URL**: http://localhost:8889/

## 📊 Проверка endpoints

### Основные endpoints:
- ✅ `/` - Главная страница (UI)
- ✅ `/api/stats` - Статистика
- ✅ `/api/strategies` - Список стратегий
- ✅ `/api/rankings` - Рейтинг стратегий
- ✅ `/api/backtest/status` - Статус бэктестов
- ✅ `/api/backtest/progress` - Прогресс бэктестов

## 🧪 Тестирование

### 1. Откройте в браузере:
```
http://localhost:8889/
```

### 2. Проверьте:
- [ ] Страница загружается
- [ ] Таблица рейтинга отображается
- [ ] Статистика показывается
- [ ] Фильтры работают
- [ ] Клик на стратегию открывает модальное окно
- [ ] График отображается (если есть данные)
- [ ] PnL Dashboard показывается

### 3. Проверьте API:
```bash
# Статистика
curl http://localhost:8889/api/stats

# Список стратегий
curl http://localhost:8889/api/strategies

# Рейтинг
curl http://localhost:8889/api/rankings?limit=5
```

## 📝 Логи

Просмотр логов:
```bash
tail -f api_server.log
```

Остановка сервера:
```bash
kill $(cat api_server.pid)
```

## ✅ Статус

**Система запущена и готова к использованию!**

