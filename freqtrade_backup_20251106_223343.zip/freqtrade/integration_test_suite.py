#!/usr/bin/env python3
"""
Integration Test Suite - Интеграционные тесты всего пайплайна
"""

import requests
import time
import subprocess
from pathlib import Path
from typing import Dict, List

API_URL = "http://localhost:8889"
FREQTRADE_DIR = Path(__file__).parent

class IntegrationTestSuite:
    """Интеграционные тесты"""
    
    def test_full_pipeline(self) -> bool:
        """Тест полного пайплайна: стратегия → бэктест → рейтинг → UI"""
        print("🔄 Тест полного пайплайна...")
        
        # 1. Получить список стратегий
        try:
            response = requests.get(f"{API_URL}/api/strategies", timeout=5)
            if response.status_code != 200:
                print("  ❌ Не удалось получить список стратегий")
                return False
            
            strategies = response.json().get("strategies", [])
            if not strategies:
                print("  ⚠️  Нет стратегий для тестирования")
                return True
            
            strategy_name = strategies[0]["name"]
            print(f"  📊 Используем стратегию: {strategy_name}")
            
            # 2. Проверить рейтинг стратегии
            response = requests.get(f"{API_URL}/api/rankings", timeout=5)
            if response.status_code != 200:
                print("  ❌ Не удалось получить рейтинг")
                return False
            
            rankings = response.json().get("rankings", [])
            strategy_found = any(r.get("strategy_name") == strategy_name for r in rankings)
            print(f"  {'✅' if strategy_found else '⚠️ '} Стратегия в рейтинге: {strategy_found}")
            
            # 3. Проверить детали стратегии
            response = requests.get(f"{API_URL}/api/strategies/{strategy_name}/details", timeout=10)
            if response.status_code == 200:
                print("  ✅ Детали стратегии доступны")
            else:
                print(f"  ⚠️  Детали стратегии: {response.status_code}")
            
            # 4. Проверить данные графика
            response = requests.get(
                f"{API_URL}/api/strategies/{strategy_name}/chart-data",
                params={"pair": "BTC/USDT", "timeframe": "5m"},
                timeout=10
            )
            if response.status_code == 200:
                data = response.json()
                print(f"  ✅ Данные графика: has_data={data.get('has_data', False)}")
            else:
                print(f"  ⚠️  Данные графика: {response.status_code}")
            
            return True
            
        except Exception as e:
            print(f"  ❌ Ошибка: {e}")
            return False
    
    def test_backtest_workflow(self) -> bool:
        """Тест workflow бэктеста"""
        print("🔄 Тест workflow бэктеста...")
        
        try:
            # 1. Проверить статус бэктестов
            response = requests.get(f"{API_URL}/api/backtest/status", timeout=5)
            if response.status_code == 200:
                status = response.json()
                print(f"  ✅ Статус бэктестов: {status.get('status', 'unknown')}")
                return True
            else:
                print(f"  ⚠️  Статус бэктестов: {response.status_code}")
                return True  # Не критично
        except Exception as e:
            print(f"  ⚠️  Ошибка: {e}")
            return True  # Не критично
    
    def test_api_consistency(self) -> bool:
        """Тест консистентности API"""
        print("🔄 Тест консистентности API...")
        
        try:
            # Получаем стратегии и рейтинг
            strategies_res = requests.get(f"{API_URL}/api/strategies", timeout=5)
            rankings_res = requests.get(f"{API_URL}/api/rankings", timeout=5)
            
            if strategies_res.status_code != 200 or rankings_res.status_code != 200:
                return False
            
            strategies = strategies_res.json().get("strategies", [])
            rankings = rankings_res.json().get("rankings", [])
            
            # Проверяем, что стратегии из списка есть в рейтинге (или наоборот)
            strategy_names = {s["name"] for s in strategies}
            ranking_names = {r.get("strategy_name") for r in rankings if r.get("strategy_name")}
            
            # Должна быть хотя бы одна общая стратегия
            common = strategy_names & ranking_names
            print(f"  {'✅' if common else '⚠️ '} Общие стратегии: {len(common)}")
            
            return True
            
        except Exception as e:
            print(f"  ❌ Ошибка: {e}")
            return False
    
    def run_all_tests(self) -> bool:
        """Запустить все интеграционные тесты"""
        print("=" * 70)
        print("🧪 INTEGRATION TEST SUITE")
        print("=" * 70)
        print()
        
        tests = [
            ("Full Pipeline", self.test_full_pipeline),
            ("Backtest Workflow", self.test_backtest_workflow),
            ("API Consistency", self.test_api_consistency),
        ]
        
        results = []
        for test_name, test_func in tests:
            print(f"🔍 {test_name}...")
            try:
                result = test_func()
                results.append((test_name, result))
                print(f"  {'✅' if result else '❌'}\n")
            except Exception as e:
                print(f"  ❌ Error: {e}\n")
                results.append((test_name, False))
        
        # Итоги
        print("=" * 70)
        passed = sum(1 for _, result in results if result)
        total = len(results)
        print(f"✅ Успешно: {passed}/{total}")
        print("=" * 70)
        
        return passed == total

if __name__ == "__main__":
    suite = IntegrationTestSuite()
    success = suite.run_all_tests()
    exit(0 if success else 1)



