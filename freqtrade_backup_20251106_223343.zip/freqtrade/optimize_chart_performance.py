#!/usr/bin/env python3
"""
Chart Performance Optimization Script
Оптимизирует производительность графиков и исправляет проблемы отображения
"""

import json
import logging
from pathlib import Path
from typing import Dict, List, Any, Optional
import zipfile
from datetime import datetime

logger = logging.getLogger(__name__)

def calculate_profit_pct(trade: Dict[str, Any]) -> float:
    """Calculate profit percentage from trade data if not present"""
    if 'profit_pct' in trade and trade['profit_pct']:
        return float(trade['profit_pct'])
    
    # Calculate from open_rate and close_rate
    open_rate = trade.get('open_rate', 0)
    close_rate = trade.get('close_rate', 0)
    
    if open_rate and close_rate and open_rate > 0:
        # For long positions
        if trade.get('is_short', False):
            # Short position: profit when price goes down
            profit_pct = ((open_rate - close_rate) / open_rate) * 100
        else:
            # Long position: profit when price goes up
            profit_pct = ((close_rate - open_rate) / open_rate) * 100
        return profit_pct
    
    return 0.0

def optimize_ohlcv_data(ohlcv_data: List[Dict], max_points: int = 1000) -> List[Dict]:
    """Optimize OHLCV data by downsampling if too many points"""
    if len(ohlcv_data) <= max_points:
        return ohlcv_data
    
    # Downsample: keep every Nth point
    step = len(ohlcv_data) // max_points
    return ohlcv_data[::step]

def optimize_trade_points(entry_points: List[Dict], exit_points: List[Dict], 
                         max_points: int = 500) -> tuple:
    """Optimize trade points by limiting and clustering nearby points"""
    # Sort by timestamp
    entry_points = sorted(entry_points, key=lambda x: x.get('x', 0))
    exit_points = sorted(exit_points, key=lambda x: x.get('x', 0))
    
    # Limit total points
    if len(entry_points) > max_points:
        # Keep first and last, and sample evenly
        step = len(entry_points) // max_points
        entry_points = entry_points[::step]
    
    if len(exit_points) > max_points:
        step = len(exit_points) // max_points
        exit_points = exit_points[::step]
    
    return entry_points, exit_points

def fix_trade_profit_data(trades_data: List[Dict]) -> List[Dict]:
    """Fix profit_pct in trade data if missing or zero"""
    fixed_trades = []
    for trade in trades_data:
        # Calculate profit_pct if missing
        if 'profit_pct' not in trade or trade.get('profit_pct') == 0:
            trade['profit_pct'] = calculate_profit_pct(trade)
        fixed_trades.append(trade)
    return fixed_trades

if __name__ == "__main__":
    print("✅ Chart optimization utilities loaded")
