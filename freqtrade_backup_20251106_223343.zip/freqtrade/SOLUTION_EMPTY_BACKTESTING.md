# ✅ Решение проблемы пустой страницы Backtesting

## 🔍 Диагностика

**Проблема:** Страница http://127.0.0.1:8081/backtesting пустая, хотя результаты есть.

**Причина:** 
- API возвращает 503 (Service Unavailable)
- Веб-сервер не загружает результаты после создания файлов
- Нужен перезапуск веб-сервера

## ✅ Решение

### Шаг 1: Перезапустить веб-сервер

```bash
# 1. Остановите текущий freqtrade (Ctrl+C или kill)

# 2. Перезапустите
cd /home/crypto/sites/cryptotrader.com/freqtrade
source .venv/bin/activate
freqtrade trade --config ../config/freqtrade_config.json --strategy TestStrategy

# 3. Подождите 15-20 секунд для полной инициализации
```

### Шаг 2: Открыть Backtesting

```
http://127.0.0.1:8081/backtesting
```

**⚠️ ВАЖНО:** Обновите страницу (F5 или Ctrl+Shift+R) после перезапуска!

### Шаг 3: Если все еще пусто

1. **Проверьте консоль браузера (F12):**
   - Откройте Developer Tools (F12)
   - Перейдите на вкладку Console
   - Проверьте ошибки

2. **Проверьте Network (F12 → Network):**
   - Обновите страницу
   - Найдите запрос к `/api/v1/backtest/history`
   - Проверьте статус ответа

3. **Используйте CLI:**
   ```bash
   freqtrade backtesting-show
   ```

## 📊 Текущие результаты

### ✅ Успешно протестировано:
- **26 бэктестов** выполнено
- **5 стратегий** протестировано
- **MShotStrategy:** 9 бэктестов (10 сделок, PNL: -6.07%)

### 📁 Файлы:
- Все файлы сохранены в `user_data/backtest_results/`
- Каталог создан: `user_data/backtest_results/catalog.json`
- HTML страница: `user_data/quick_access_results.html`

## 🎯 Быстрый доступ к результатам

### Вариант 1: Через веб-интерфейс (после перезапуска)

1. Перезапустите freqtrade
2. Откройте: http://127.0.0.1:8081/backtesting
3. Обновите страницу (F5)

### Вариант 2: Через CLI (всегда работает)

```bash
cd /home/crypto/sites/cryptotrader.com/freqtrade
source .venv/bin/activate

# Все результаты
freqtrade backtesting-show

# Конкретная стратегия
freqtrade backtesting-show --backtest-filename=backtest-result-2025-11-04_15-51-46.zip
```

### Вариант 3: Через HTML страницу

```bash
xdg-open user_data/quick_access_results.html
```

### Вариант 4: Через каталог JSON

```bash
cat user_data/backtest_results/catalog.json | python3 -m json.tool
```

## 🔧 Автоматическое исправление

Запустите скрипт диагностики:

```bash
python3 check_and_display_results.py
python3 fix_web_ui_display.py
```

## 📋 Чеклист

- [ ] Freqtrade веб-сервер запущен
- [ ] Порт 8081 доступен
- [ ] Файлы результатов созданы (26 ZIP файлов)
- [ ] Перезапущен веб-сервер после создания файлов
- [ ] Страница обновлена (F5)
- [ ] Вход выполнен (логин: freqtrader)

## 💡 Почему страница пустая?

1. **Веб-сервер не перезапускался** после создания файлов
   - Решение: Перезапустить freqtrade

2. **Браузер кэширует старую версию**
   - Решение: Ctrl+Shift+R (жесткое обновление)

3. **API возвращает 503**
   - Решение: Перезапустить веб-сервер, подождать 15-20 секунд

4. **Файлы созданы, но API их не видит**
   - Решение: Проверить права доступа, перезапустить сервер

## 🚀 Полное решение одним скриптом

```bash
#!/bin/bash
# complete_solution.sh

cd /home/crypto/sites/cryptotrader.com/freqtrade
source .venv/bin/activate

# 1. Запустить тесты
echo "🧪 Запуск тестов всех стратегий..."
python3 run_full_backtest_suite.py

# 2. Проверить файлы
echo "🔍 Проверка файлов..."
python3 fix_web_ui_display.py

# 3. Показать результаты
echo "📊 Результаты через CLI:"
freqtrade backtesting-show

echo ""
echo "✅ Готово!"
echo "🌐 Откройте: http://127.0.0.1:8081/backtesting"
echo "💡 Если пусто - перезапустите freqtrade и обновите страницу"
```

