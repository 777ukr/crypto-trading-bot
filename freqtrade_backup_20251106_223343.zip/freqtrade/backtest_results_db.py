#!/usr/bin/env python3
"""
Optimized database for storing and quickly reading backtest results
Uses SQLite for simplicity and PostgreSQL for production
"""

import json
import sqlite3
import zipfile
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Any
import logging

logger = logging.getLogger(__name__)

# Try PostgreSQL first, fallback to SQLite
try:
    import psycopg2
    from psycopg2.extras import RealDictCursor
    POSTGRES_AVAILABLE = True
except ImportError:
    POSTGRES_AVAILABLE = False

class BacktestResultsDB:
    """Optimized database for backtest results"""
    
    def __init__(self, db_path: Optional[str] = None, use_postgres: bool = True):
        self.use_postgres = use_postgres and POSTGRES_AVAILABLE
        self.db_path = db_path or str(Path(__file__).parent / "backtest_results.db")
        self.conn = None
        self._init_db()
    
    def _get_connection(self):
        """Get database connection"""
        if self.use_postgres:
            try:
                import os
                db_url = os.getenv('DATABASE_URL', 'postgresql://cryptotrader:cryptotrader@localhost/cryptotrader')
                conn = psycopg2.connect(db_url)
                return conn
            except Exception as e:
                logger.warning(f"PostgreSQL недоступен, используем SQLite: {e}")
                self.use_postgres = False
        
        # SQLite fallback
        conn = sqlite3.connect(self.db_path, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        return conn
    
    def _init_db(self):
        """Initialize database tables"""
        self.conn = self._get_connection()
        cursor = self.conn.cursor()
        
        if self.use_postgres:
            # PostgreSQL schema
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS backtest_results (
                    id SERIAL PRIMARY KEY,
                    strategy_name VARCHAR(255) NOT NULL,
                    pair VARCHAR(50) NOT NULL,
                    timeframe VARCHAR(10) NOT NULL,
                    exchange VARCHAR(50),
                    leverage INTEGER DEFAULT 1,
                    trading_type VARCHAR(20) DEFAULT 'spot',
                    deposit DECIMAL(15, 2),
                    backtest_date TIMESTAMP NOT NULL,
                    total_trades INTEGER DEFAULT 0,
                    winning_trades INTEGER DEFAULT 0,
                    losing_trades INTEGER DEFAULT 0,
                    total_profit_pct DECIMAL(10, 4) DEFAULT 0,
                    total_profit_abs DECIMAL(15, 8) DEFAULT 0,
                    win_rate DECIMAL(5, 2) DEFAULT 0,
                    max_drawdown DECIMAL(10, 4) DEFAULT 0,
                    sharpe_ratio DECIMAL(10, 4) DEFAULT 0,
                    profit_factor DECIMAL(10, 4) DEFAULT 0,
                    sortino_ratio DECIMAL(10, 4) DEFAULT 0,
                    calmar_ratio DECIMAL(10, 4) DEFAULT 0,
                    expectancy DECIMAL(10, 4) DEFAULT 0,
                    cagr DECIMAL(10, 4) DEFAULT 0,
                    avg_profit_pct DECIMAL(10, 4) DEFAULT 0,
                    results_json JSONB,
                    trades_json JSONB,
                    ohlcv_json JSONB,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Create indexes for fast queries
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_strategy_name ON backtest_results(strategy_name)
            """)
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_pair ON backtest_results(pair)
            """)
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_backtest_date ON backtest_results(backtest_date DESC)
            """)
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_strategy_pair_tf ON backtest_results(strategy_name, pair, timeframe)
            """)
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_total_profit ON backtest_results(total_profit_pct DESC)
            """)
        else:
            # SQLite schema
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS backtest_results (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    strategy_name TEXT NOT NULL,
                    pair TEXT NOT NULL,
                    timeframe TEXT NOT NULL,
                    exchange TEXT,
                    leverage INTEGER DEFAULT 1,
                    trading_type TEXT DEFAULT 'spot',
                    deposit REAL,
                    backtest_date TIMESTAMP NOT NULL,
                    total_trades INTEGER DEFAULT 0,
                    winning_trades INTEGER DEFAULT 0,
                    losing_trades INTEGER DEFAULT 0,
                    total_profit_pct REAL DEFAULT 0,
                    total_profit_abs REAL DEFAULT 0,
                    win_rate REAL DEFAULT 0,
                    max_drawdown REAL DEFAULT 0,
                    sharpe_ratio REAL DEFAULT 0,
                    profit_factor REAL DEFAULT 0,
                    sortino_ratio REAL DEFAULT 0,
                    calmar_ratio REAL DEFAULT 0,
                    expectancy REAL DEFAULT 0,
                    cagr REAL DEFAULT 0,
                    avg_profit_pct REAL DEFAULT 0,
                    results_json TEXT,
                    trades_json TEXT,
                    ohlcv_json TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Create indexes
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_strategy_name ON backtest_results(strategy_name)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_pair ON backtest_results(pair)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_backtest_date ON backtest_results(backtest_date DESC)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_strategy_pair_tf ON backtest_results(strategy_name, pair, timeframe)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_total_profit ON backtest_results(total_profit_pct DESC)")
        
        self.conn.commit()
        logger.info("База данных результатов бэктестов инициализирована")
    
    def save_backtest_result(self, strategy_name: str, pair: str, timeframe: str,
                            results_data: Dict[str, Any], zip_file_path: Optional[str] = None):
        """Save backtest result to database"""
        try:
            cursor = self.conn.cursor()
            
            # Extract metrics from results
            strategy_result = results_data.get('strategy', {}).get(strategy_name, {})
            if not strategy_result:
                # Try to find strategy in results
                for key, value in results_data.get('strategy', {}).items():
                    if strategy_name.lower() in key.lower():
                        strategy_result = value
                        break
            
            # Extract trades
            trades = strategy_result.get('trades', [])
            total_trades = len(trades)
            winning_trades = sum(1 for t in trades if t.get('profit_abs', 0) > 0)
            losing_trades = total_trades - winning_trades
            
            # Calculate metrics
            total_profit_pct = strategy_result.get('profit_total_pct', 0) or strategy_result.get('profit_total', 0) or 0
            total_profit_abs = strategy_result.get('profit_total_abs', 0) or 0
            win_rate = (winning_trades / total_trades * 100) if total_trades > 0 else 0
            max_drawdown = abs(strategy_result.get('max_drawdown', 0) or strategy_result.get('max_drawdown_abs', 0) or 0)
            
            # Extract other metrics
            sharpe_ratio = strategy_result.get('sharpe_ratio', 0) or 0
            profit_factor = strategy_result.get('profit_factor', 0) or 0
            sortino_ratio = strategy_result.get('sortino_ratio', 0) or 0
            calmar_ratio = strategy_result.get('calmar_ratio', 0) or 0
            expectancy = strategy_result.get('expectancy', 0) or 0
            cagr = strategy_result.get('cagr', 0) or 0
            avg_profit_pct = (total_profit_pct / total_trades) if total_trades > 0 else 0
            
            # Extract metadata
            exchange = results_data.get('exchange', 'unknown')
            leverage = results_data.get('leverage', 1)
            trading_type = results_data.get('trading_type', 'spot')
            deposit = results_data.get('deposit', 0)
            
            # Parse backtest date
            backtest_date = datetime.now()
            if zip_file_path:
                try:
                    # Try to extract date from filename
                    from pathlib import Path
                    filename = Path(zip_file_path).stem
                    # Format: backtest-result-2025-11-05 21-23-41
                    if 'backtest-result-' in filename:
                        date_str = filename.replace('backtest-result-', '').replace(' ', '-').replace('_', '-')
                        backtest_date = datetime.strptime(date_str, '%Y-%m-%d-%H-%M-%S')
                except:
                    pass
            
            # Prepare JSON data
            results_json = json.dumps(results_data) if self.use_postgres else json.dumps(results_data)
            trades_json = json.dumps(trades[:1000]) if self.use_postgres else json.dumps(trades[:1000])  # Limit trades
            ohlcv_json = json.dumps(strategy_result.get('ohlcv', [])[:500]) if self.use_postgres else json.dumps(strategy_result.get('ohlcv', [])[:500])  # Limit OHLCV
            
            if self.use_postgres:
                cursor.execute("""
                    INSERT INTO backtest_results (
                        strategy_name, pair, timeframe, exchange, leverage, trading_type, deposit,
                        backtest_date, total_trades, winning_trades, losing_trades,
                        total_profit_pct, total_profit_abs, win_rate, max_drawdown,
                        sharpe_ratio, profit_factor, sortino_ratio, calmar_ratio,
                        expectancy, cagr, avg_profit_pct,
                        results_json, trades_json, ohlcv_json
                    ) VALUES (
                        %s, %s, %s, %s, %s, %s, %s,
                        %s, %s, %s, %s,
                        %s, %s, %s, %s,
                        %s, %s, %s, %s,
                        %s, %s, %s,
                        %s, %s, %s
                    )
                    ON CONFLICT DO NOTHING
                """, (
                    strategy_name, pair, timeframe, exchange, leverage, trading_type, deposit,
                    backtest_date, total_trades, winning_trades, losing_trades,
                    total_profit_pct, total_profit_abs, win_rate, max_drawdown,
                    sharpe_ratio, profit_factor, sortino_ratio, calmar_ratio,
                    expectancy, cagr, avg_profit_pct,
                    results_json, trades_json, ohlcv_json
                ))
            else:
                cursor.execute("""
                    INSERT OR IGNORE INTO backtest_results (
                        strategy_name, pair, timeframe, exchange, leverage, trading_type, deposit,
                        backtest_date, total_trades, winning_trades, losing_trades,
                        total_profit_pct, total_profit_abs, win_rate, max_drawdown,
                        sharpe_ratio, profit_factor, sortino_ratio, calmar_ratio,
                        expectancy, cagr, avg_profit_pct,
                        results_json, trades_json, ohlcv_json
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    strategy_name, pair, timeframe, exchange, leverage, trading_type, deposit,
                    backtest_date, total_trades, winning_trades, losing_trades,
                    total_profit_pct, total_profit_abs, win_rate, max_drawdown,
                    sharpe_ratio, profit_factor, sortino_ratio, calmar_ratio,
                    expectancy, cagr, avg_profit_pct,
                    results_json, trades_json, ohlcv_json
                ))
            
            self.conn.commit()
            logger.info(f"Результат бэктеста сохранен: {strategy_name} {pair} {timeframe}")
            return True
        except Exception as e:
            logger.error(f"Ошибка сохранения результата бэктеста: {e}", exc_info=True)
            self.conn.rollback()
            return False
    
    def get_backtest_results(self, strategy_name: Optional[str] = None,
                            pair: Optional[str] = None, timeframe: Optional[str] = None,
                            limit: int = 100, order_by: str = 'backtest_date DESC'):
        """Get backtest results with filters"""
        try:
            cursor = self.conn.cursor()
            
            query = "SELECT * FROM backtest_results WHERE 1=1"
            params = []
            
            if strategy_name:
                query += " AND strategy_name = %s" if self.use_postgres else " AND strategy_name = ?"
                params.append(strategy_name)
            
            if pair:
                query += " AND pair = %s" if self.use_postgres else " AND pair = ?"
                params.append(pair)
            
            if timeframe:
                query += " AND timeframe = %s" if self.use_postgres else " AND timeframe = ?"
                params.append(timeframe)
            
            query += f" ORDER BY {order_by}"
            query += f" LIMIT {limit}"
            
            if self.use_postgres:
                cursor.execute(query, params)
                results = cursor.fetchall()
                return [dict(row) for row in results]
            else:
                cursor.execute(query, params)
                rows = cursor.fetchall()
                return [dict(row) for row in rows]
        except Exception as e:
            logger.error(f"Ошибка получения результатов: {e}", exc_info=True)
            return []
    
    def get_latest_backtest(self, strategy_name: str, pair: str, timeframe: str):
        """Get latest backtest result for strategy/pair/timeframe"""
        results = self.get_backtest_results(
            strategy_name=strategy_name,
            pair=pair,
            timeframe=timeframe,
            limit=1
        )
        return results[0] if results else None
    
    def get_strategy_stats(self, strategy_name: str):
        """Get aggregated statistics for a strategy"""
        try:
            cursor = self.conn.cursor()
            
            if self.use_postgres:
                cursor.execute("""
                    SELECT 
                        COUNT(*) as total_backtests,
                        AVG(total_profit_pct) as avg_profit_pct,
                        AVG(win_rate) as avg_win_rate,
                        AVG(max_drawdown) as avg_max_drawdown,
                        AVG(sharpe_ratio) as avg_sharpe_ratio,
                        AVG(profit_factor) as avg_profit_factor,
                        MAX(total_profit_pct) as best_profit_pct,
                        MIN(total_profit_pct) as worst_profit_pct,
                        MAX(backtest_date) as latest_backtest
                    FROM backtest_results
                    WHERE strategy_name = %s
                """, (strategy_name,))
            else:
                cursor.execute("""
                    SELECT 
                        COUNT(*) as total_backtests,
                        AVG(total_profit_pct) as avg_profit_pct,
                        AVG(win_rate) as avg_win_rate,
                        AVG(max_drawdown) as avg_max_drawdown,
                        AVG(sharpe_ratio) as avg_sharpe_ratio,
                        AVG(profit_factor) as avg_profit_factor,
                        MAX(total_profit_pct) as best_profit_pct,
                        MIN(total_profit_pct) as worst_profit_pct,
                        MAX(backtest_date) as latest_backtest
                    FROM backtest_results
                    WHERE strategy_name = ?
                """, (strategy_name,))
            
            row = cursor.fetchone()
            if row:
                return dict(row)
            return None
        except Exception as e:
            logger.error(f"Ошибка получения статистики: {e}", exc_info=True)
            return None
    
    def import_from_zip(self, zip_file_path: str):
        """Import backtest result from ZIP file"""
        try:
            with zipfile.ZipFile(zip_file_path, 'r') as zip_ref:
                # Find JSON file
                json_files = [f for f in zip_ref.namelist() if f.endswith('.json')]
                if not json_files:
                    logger.warning(f"JSON файл не найден в {zip_file_path}")
                    return False
                
                # Read JSON
                json_content = zip_ref.read(json_files[0])
                results_data = json.loads(json_content)
                
                # Extract strategy name from filename or data
                strategy_name = None
                pair = "BTC/USDT"
                timeframe = "5m"
                
                # Try to extract from filename
                from pathlib import Path
                filename = Path(zip_file_path).stem
                if '_' in filename:
                    parts = filename.split('_')
                    strategy_name = parts[0] if parts else None
                
                # Try to extract from JSON
                if 'strategy' in results_data:
                    strategies = list(results_data['strategy'].keys())
                    if strategies:
                        strategy_name = strategies[0]
                
                if not strategy_name:
                    logger.warning(f"Не удалось определить стратегию из {zip_file_path}")
                    return False
                
                # Extract pair and timeframe from results
                if 'pair' in results_data:
                    pair = results_data['pair']
                if 'timeframe' in results_data:
                    timeframe = results_data['timeframe']
                
                # Save to database
                return self.save_backtest_result(
                    strategy_name=strategy_name,
                    pair=pair,
                    timeframe=timeframe,
                    results_data=results_data,
                    zip_file_path=zip_file_path
                )
        except Exception as e:
            logger.error(f"Ошибка импорта из ZIP: {e}", exc_info=True)
            return False
    
    def import_all_zip_files(self, results_dir: str):
        """Import all ZIP files from results directory"""
        results_path = Path(results_dir)
        zip_files = list(results_path.glob("*.zip"))
        
        imported = 0
        for zip_file in zip_files:
            if self.import_from_zip(str(zip_file)):
                imported += 1
                logger.info(f"Импортирован: {zip_file.name}")
        
        logger.info(f"Импортировано {imported} из {len(zip_files)} файлов")
        return imported
    
    def close(self):
        """Close database connection"""
        if self.conn:
            self.conn.close()

# Singleton instance
_db_instance = None

def get_db() -> BacktestResultsDB:
    """Get database instance"""
    global _db_instance
    if _db_instance is None:
        _db_instance = BacktestResultsDB()
    return _db_instance

if __name__ == "__main__":
    # Test and import existing results
    import sys
    from pathlib import Path
    
    freqtrade_dir = Path(__file__).parent
    results_dir = freqtrade_dir / "user_data" / "backtest_results"
    
    db = BacktestResultsDB()
    print(f"Импорт результатов из {results_dir}...")
    imported = db.import_all_zip_files(str(results_dir))
    print(f"✅ Импортировано {imported} результатов")
    db.close()

