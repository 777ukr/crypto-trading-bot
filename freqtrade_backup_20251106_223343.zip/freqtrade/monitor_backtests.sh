#!/bin/bash
# Мониторинг прогресса бэктестов

API_URL="http://localhost:8889"

echo "📊 Мониторинг бэктестов"
echo "===================="
echo ""

while true; do
    # Статус прогресса
    PROGRESS=$(curl -s "$API_URL/api/backtest/progress")
    ACTIVE=$(echo "$PROGRESS" | python3 -c "import sys, json; print(json.load(sys.stdin).get('active_processes', 0))" 2>/dev/null || echo "0")
    
    # Статистика
    STATS=$(curl -s "$API_URL/api/stats")
    TOTAL_STRATEGIES=$(echo "$STATS" | python3 -c "import sys, json; print(json.load(sys.stdin).get('total_strategies', 0))" 2>/dev/null || echo "0")
    TOTAL_BACKTESTS=$(echo "$STATS" | python3 -c "import sys, json; print(json.load(sys.stdin).get('total_backtests', 0))" 2>/dev/null || echo "0")
    
    # Количество результатов
    RESULT_COUNT=$(ls -1 /home/crypto/sites/cryptotrader.com/freqtrade/user_data/backtest_results/*.zip 2>/dev/null | wc -l)
    
    clear
    echo "📊 Мониторинг бэктестов - $(date '+%H:%M:%S')"
    echo "===================="
    echo ""
    echo "🔄 Активных процессов: $ACTIVE"
    echo "📈 Всего стратегий: $TOTAL_STRATEGIES"
    echo "📊 Всего бэктестов: $TOTAL_BACKTESTS"
    echo "📁 Файлов результатов: $RESULT_COUNT"
    echo ""
    
    if [ "$ACTIVE" -eq 0 ]; then
        echo "✅ Все бэктесты завершены!"
        echo ""
        echo "📊 Рейтинг стратегий:"
        curl -s "$API_URL/api/rankings?limit=5" | python3 -c "
import sys, json
data = json.load(sys.stdin)
for i, r in enumerate(data.get('rankings', [])[:5], 1):
    name = r.get('strategy_name', 'N/A')
    score = r.get('ninja_score', 0)
    profit = r.get('median_total_profit_pct', 0)
    trades = r.get('median_total_trades', 0)
    print(f\"  {i}. {name}: Score={score:.1f}, Profit={profit:.2f}%, Trades={trades}\")
" 2>/dev/null
        break
    fi
    
    echo "⏳ Ожидание завершения..."
    sleep 10
done

