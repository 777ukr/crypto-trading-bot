#!/bin/bash
# Быстрые бэктесты за 3 дня для простых стратегий

API_URL="http://localhost:8889/api/backtest/run"
TIMERANGE="20251103-20251106"  # Последние 3 дня

echo "🚀 Запуск быстрых бэктестов (3 дня) для простых стратегий..."
echo ""

STRATEGIES=(
    "SimpleEMAStrategy"
    "SimpleRSIStrategy"
    "MShotStrategy"
)

for strategy in "${STRATEGIES[@]}"; do
    echo "📊 Запуск: $strategy"
    
    JSON_DATA=$(cat <<EOF
{
    "strategy_name": "$strategy",
    "pairs": ["BTC/USDT"],
    "timeframe": "5m",
    "timerange": "$TIMERANGE"
}
EOF
)
    
    RESPONSE=$(curl -s -X POST "$API_URL" \
        -H "Content-Type: application/json" \
        -d "$JSON_DATA")
    
    if echo "$RESPONSE" | grep -q "started"; then
        echo "  ✅ Запущен"
    else
        echo "  ❌ Ошибка: $RESPONSE"
    fi
    
    sleep 2
done

echo ""
echo "✅ Все бэктесты запущены!"
echo "⏱️  Ожидаемое время: 2-5 минут на стратегию"
echo "📊 Проверьте результаты через: http://localhost:8889"

