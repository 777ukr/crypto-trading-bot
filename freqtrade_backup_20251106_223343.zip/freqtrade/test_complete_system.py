#!/usr/bin/env python3
"""
Комплексное тестирование системы рейтинга стратегий
Проверка всех API endpoints, функциональности и интеграции
"""

import requests
import json
import time
import sys
from pathlib import Path
from typing import Dict, Any, List, Optional
from datetime import datetime

API_URL = "http://localhost:8889"
TIMEOUT = 10

class Colors:
    GREEN = '\033[92m'
    RED = '\033[91m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    RESET = '\033[0m'
    BOLD = '\033[1m'

def print_success(msg: str):
    print(f"{Colors.GREEN}✅ {msg}{Colors.RESET}")

def print_error(msg: str):
    print(f"{Colors.RED}❌ {msg}{Colors.RESET}")

def print_warning(msg: str):
    print(f"{Colors.YELLOW}⚠️  {msg}{Colors.RESET}")

def print_info(msg: str):
    print(f"{Colors.BLUE}ℹ️  {msg}{Colors.RESET}")

def test_endpoint(name: str, method: str, url: str, expected_status: int = 200, **kwargs) -> Dict[str, Any]:
    """Тестировать endpoint с проверкой"""
    try:
        if method.upper() == "GET":
            response = requests.get(url, timeout=TIMEOUT, **kwargs)
        elif method.upper() == "POST":
            response = requests.post(url, timeout=TIMEOUT, **kwargs)
        elif method.upper() == "DELETE":
            response = requests.delete(url, timeout=TIMEOUT, **kwargs)
        else:
            return {"success": False, "error": f"Unknown method: {method}"}
        
        try:
            data = response.json()
        except:
            data = {"raw": response.text[:500]}
        
        success = response.status_code == expected_status
        
        return {
            "name": name,
            "success": success,
            "status_code": response.status_code,
            "expected_status": expected_status,
            "data": data,
            "response_time_ms": response.elapsed.total_seconds() * 1000
        }
    except requests.exceptions.ConnectionError:
        return {
            "name": name,
            "success": False,
            "error": "Server not running",
            "status_code": 0
        }
    except Exception as e:
        return {
            "name": name,
            "success": False,
            "error": str(e),
            "status_code": 0
        }

class StrategyRatingSystemTester:
    """Комплексный тестер системы рейтинга"""
    
    def __init__(self):
        self.results = []
        self.api_url = API_URL
        
    def test_server_availability(self) -> bool:
        """Проверка доступности сервера"""
        print(f"\n{Colors.BOLD}🔍 Проверка доступности сервера...{Colors.RESET}")
        
        try:
            response = requests.get(f"{self.api_url}/", timeout=5)
            if response.status_code == 200:
                print_success("Сервер доступен")
                return True
            else:
                print_error(f"Сервер вернул статус {response.status_code}")
                return False
        except Exception as e:
            print_error(f"Сервер недоступен: {e}")
            return False
    
    def test_api_endpoints(self) -> int:
        """Тестирование всех API endpoints"""
        print(f"\n{Colors.BOLD}📡 Тестирование API Endpoints...{Colors.RESET}")
        
        endpoints = [
            ("GET /", "GET", f"{self.api_url}/", 200),
            ("GET /api/strategies", "GET", f"{self.api_url}/api/strategies", 200),
            ("GET /api/stats", "GET", f"{self.api_url}/api/stats", 200),
            ("GET /api/rankings", "GET", f"{self.api_url}/api/rankings?limit=10", 200),
            ("GET /api/rankings/main", "GET", f"{self.api_url}/api/rankings/main?limit=10", 200),
            ("GET /api/rankings/latest", "GET", f"{self.api_url}/api/rankings/latest?limit=10", 200),
            ("GET /api/rankings/failed", "GET", f"{self.api_url}/api/rankings/failed?limit=10", 200),
            ("GET /api/rankings/private", "GET", f"{self.api_url}/api/rankings/private?limit=10", 200),
            ("GET /api/rankings/dca", "GET", f"{self.api_url}/api/rankings/dca?limit=10", 200),
            ("GET /api/rankings/multiclass", "GET", f"{self.api_url}/api/rankings/multiclass?limit=10", 200),
            ("GET /api/backtest/status", "GET", f"{self.api_url}/api/backtest/status", 200),
            ("GET /api/backtest/progress", "GET", f"{self.api_url}/api/backtest/progress", 200),
        ]
        
        passed = 0
        for name, method, url, expected_status in endpoints:
            result = test_endpoint(name, method, url, expected_status)
            self.results.append(result)
            
            if result["success"]:
                print_success(f"{name}: {result['status_code']} ({result['response_time_ms']:.0f}ms)")
                passed += 1
            else:
                print_error(f"{name}: {result.get('status_code', 'N/A')} - {result.get('error', 'Unknown error')}")
        
        return passed
    
    def test_strategy_details(self) -> int:
        """Тестирование деталей стратегий"""
        print(f"\n{Colors.BOLD}📊 Тестирование деталей стратегий...{Colors.RESET}")
        
        # Получаем список стратегий
        try:
            res = requests.get(f"{self.api_url}/api/strategies", timeout=TIMEOUT)
            if res.status_code != 200:
                print_warning("Не удалось получить список стратегий")
                return 0
            
            strategies = res.json().get("strategies", [])
            if not strategies:
                print_warning("Нет стратегий для тестирования")
                return 0
            
            passed = 0
            for strategy in strategies[:3]:  # Тестируем первые 3
                strategy_name = strategy["name"]
                result = test_endpoint(
                    f"GET /api/strategies/{strategy_name}/details",
                    "GET",
                    f"{self.api_url}/api/strategies/{strategy_name}/details",
                    200
                )
                self.results.append(result)
                
                if result["success"]:
                    data = result.get("data", {})
                    indicators_count = len(data.get("indicators", []))
                    breakdown_count = len(data.get("monthly_breakdown", []))
                    print_success(f"{strategy_name}: OK (индикаторов: {indicators_count}, месяцев: {breakdown_count})")
                    passed += 1
                else:
                    print_error(f"{strategy_name}: {result.get('error', 'Failed')}")
            
            return passed
        except Exception as e:
            print_error(f"Ошибка при тестировании деталей: {e}")
            return 0
    
    def test_filters(self) -> int:
        """Тестирование фильтров"""
        print(f"\n{Colors.BOLD}🔍 Тестирование фильтров...{Colors.RESET}")
        
        filter_tests = [
            ("hide_negative", f"{self.api_url}/api/rankings?hide_negative=true&limit=10"),
            ("hide_private", f"{self.api_url}/api/rankings?hide_private=true&limit=10"),
            ("show_dca", f"{self.api_url}/api/rankings?show_dca=true&limit=10"),
            ("show_multiclass", f"{self.api_url}/api/rankings?show_multiclass=true&limit=10"),
            ("min_trades", f"{self.api_url}/api/rankings?min_trades=10&limit=10"),
            ("min_profit", f"{self.api_url}/api/rankings?min_profit=0&limit=10"),
            ("max_leverage", f"{self.api_url}/api/rankings?max_leverage=1&limit=10"),
            ("exchange", f"{self.api_url}/api/rankings?exchange=gateio&limit=10"),
            ("stake", f"{self.api_url}/api/rankings?stake=USDT&limit=10"),
        ]
        
        passed = 0
        for name, url in filter_tests:
            result = test_endpoint(f"Filter: {name}", "GET", url, 200)
            self.results.append(result)
            
            if result["success"]:
                print_success(f"Filter {name}: OK")
                passed += 1
            else:
                print_error(f"Filter {name}: Failed")
        
        return passed
    
    def test_stats_data_structure(self) -> bool:
        """Проверка структуры данных статистики"""
        print(f"\n{Colors.BOLD}📈 Проверка структуры статистики...{Colors.RESET}")
        
        try:
            res = requests.get(f"{self.api_url}/api/stats", timeout=TIMEOUT)
            if res.status_code != 200:
                print_error("Не удалось получить статистику")
                return False
            
            data = res.json()
            required_fields = [
                "total_strategies",
                "total_backtests",
                "failed_testing_pct",
                "lookahead_pct",
                "stalled_pct",
                "private_pct",
                "dca_pct",
                "multiclass_pct"
            ]
            
            missing = [f for f in required_fields if f not in data]
            if missing:
                print_error(f"Отсутствуют поля: {', '.join(missing)}")
                return False
            
            print_success("Все поля статистики присутствуют")
            print_info(f"  Total Strategies: {data.get('total_strategies', 0)}")
            print_info(f"  Total Backtests: {data.get('total_backtests', 0)}")
            return True
        except Exception as e:
            print_error(f"Ошибка: {e}")
            return False
    
    def test_rankings_data_structure(self) -> bool:
        """Проверка структуры данных рейтинга"""
        print(f"\n{Colors.BOLD}🏆 Проверка структуры рейтинга...{Colors.RESET}")
        
        try:
            res = requests.get(f"{self.api_url}/api/rankings?limit=5", timeout=TIMEOUT)
            if res.status_code != 200:
                print_error("Не удалось получить рейтинг")
                return False
            
            data = res.json()
            if not isinstance(data.get("rankings"), list):
                print_error("Рейтинг не является списком")
                return False
            
            rankings = data.get("rankings", [])
            if rankings:
                first = rankings[0]
                required_fields = [
                    "strategy_name",
                    "ninja_score",
                    "median_total_profit_pct",
                    "median_win_rate",
                    "median_total_trades"
                ]
                
                missing = [f for f in required_fields if f not in first]
                if missing:
                    print_error(f"Отсутствуют поля: {', '.join(missing)}")
                    return False
                
                print_success(f"Структура данных корректна ({len(rankings)} записей)")
                return True
            else:
                print_warning("Рейтинг пуст (это нормально если нет бэктестов)")
                return True
        except Exception as e:
            print_error(f"Ошибка: {e}")
            return False
    
    def test_ui_accessibility(self) -> bool:
        """Проверка доступности UI"""
        print(f"\n{Colors.BOLD}🌐 Проверка UI...{Colors.RESET}")
        
        try:
            res = requests.get(f"{self.api_url}/", timeout=TIMEOUT)
            if res.status_code != 200:
                print_error(f"UI недоступен: {res.status_code}")
                return False
            
            content = res.text
            checks = [
                ("Strategy Rating System", "Заголовок"),
                ("rankings-table", "Таблица рейтинга"),
                ("theme-toggle", "Переключатель темы"),
                ("tab-btn", "Вкладки"),
                ("api/stats", "API вызовы"),
            ]
            
            passed = 0
            for check, name in checks:
                if check in content:
                    print_success(f"{name}: найден")
                    passed += 1
                else:
                    print_error(f"{name}: не найден")
            
            return passed == len(checks)
        except Exception as e:
            print_error(f"Ошибка: {e}")
            return False
    
    def test_performance(self) -> Dict[str, float]:
        """Тестирование производительности"""
        print(f"\n{Colors.BOLD}⚡ Тестирование производительности...{Colors.RESET}")
        
        performance_tests = {
            "/api/stats": [],
            "/api/strategies": [],
            "/api/rankings?limit=10": [],
            "/api/rankings/main?limit=10": [],
        }
        
        for endpoint in performance_tests.keys():
            times = []
            for _ in range(3):  # 3 запроса для усреднения
                try:
                    start = time.time()
                    res = requests.get(f"{self.api_url}{endpoint}", timeout=TIMEOUT)
                    elapsed = (time.time() - start) * 1000
                    if res.status_code == 200:
                        times.append(elapsed)
                except:
                    pass
            if times:
                avg_time = sum(times) / len(times)
                performance_tests[endpoint] = avg_time
                print_info(f"{endpoint}: {avg_time:.0f}ms")
        
        return performance_tests
    
    def run_all_tests(self) -> Dict[str, Any]:
        """Запустить все тесты"""
        print(f"{Colors.BOLD}{'='*70}{Colors.RESET}")
        print(f"{Colors.BOLD}🧪 КОМПЛЕКСНОЕ ТЕСТИРОВАНИЕ СИСТЕМЫ РЕЙТИНГА{Colors.RESET}")
        print(f"{Colors.BOLD}{'='*70}{Colors.RESET}")
        
        start_time = time.time()
        
        # 1. Проверка сервера
        if not self.test_server_availability():
            print_error("Сервер недоступен. Запустите: python3 rating_api_server.py")
            return {"success": False, "error": "Server not available"}
        
        # 2. Тестирование API
        api_passed = self.test_api_endpoints()
        api_total = 12
        
        # 3. Детали стратегий
        details_passed = self.test_strategy_details()
        
        # 4. Фильтры
        filters_passed = self.test_filters()
        filters_total = 9
        
        # 5. Структура данных
        stats_ok = self.test_stats_data_structure()
        rankings_ok = self.test_rankings_data_structure()
        
        # 6. UI
        ui_ok = self.test_ui_accessibility()
        
        # 7. Производительность
        performance = self.test_performance()
        
        # Итоги
        elapsed = time.time() - start_time
        
        print(f"\n{Colors.BOLD}{'='*70}{Colors.RESET}")
        print(f"{Colors.BOLD}📊 ИТОГОВЫЕ РЕЗУЛЬТАТЫ{Colors.RESET}")
        print(f"{Colors.BOLD}{'='*70}{Colors.RESET}")
        
        total_tests = api_passed + details_passed + filters_passed + (1 if stats_ok else 0) + (1 if rankings_ok else 0) + (1 if ui_ok else 0)
        total_possible = api_total + details_passed + filters_total + 5
        
        print(f"\n✅ API Endpoints: {api_passed}/{api_total}")
        print(f"✅ Детали стратегий: {details_passed}")
        print(f"✅ Фильтры: {filters_passed}/{filters_total}")
        print(f"{'✅' if stats_ok else '❌'} Структура статистики: {'OK' if stats_ok else 'FAIL'}")
        print(f"{'✅' if rankings_ok else '❌'} Структура рейтинга: {'OK' if rankings_ok else 'FAIL'}")
        print(f"{'✅' if ui_ok else '❌'} UI доступность: {'OK' if ui_ok else 'FAIL'}")
        
        print(f"\n⚡ Производительность:")
        for endpoint, time_ms in performance.items():
            status = "✅" if time_ms < 500 else "⚠️"
            print(f"  {status} {endpoint}: {time_ms:.0f}ms")
        
        print(f"\n⏱️  Время выполнения: {elapsed:.2f}с")
        
        success_rate = (total_tests / total_possible * 100) if total_possible > 0 else 0
        print(f"\n📈 Успешность: {success_rate:.1f}% ({total_tests}/{total_possible})")
        
        if success_rate >= 90:
            print_success("🎉 ВСЕ ТЕСТЫ ПРОШЛИ УСПЕШНО!")
        elif success_rate >= 70:
            print_warning("⚠️  Большинство тестов прошли, но есть проблемы")
        else:
            print_error("❌ Много тестов не прошли")
        
        return {
            "success": success_rate >= 90,
            "success_rate": success_rate,
            "total_tests": total_tests,
            "total_possible": total_possible,
            "api_passed": api_passed,
            "details_passed": details_passed,
            "filters_passed": filters_passed,
            "stats_ok": stats_ok,
            "rankings_ok": rankings_ok,
            "ui_ok": ui_ok,
            "performance": performance,
            "elapsed_time": elapsed
        }

if __name__ == "__main__":
    tester = StrategyRatingSystemTester()
    results = tester.run_all_tests()
    
    sys.exit(0 if results.get("success", False) else 1)

