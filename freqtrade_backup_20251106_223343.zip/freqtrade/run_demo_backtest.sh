#!/bin/bash
# Скрипт для запуска демо-бэктеста

cd /home/crypto/sites/cryptotrader.com/freqtrade

echo "🚀 Запуск демо-бэктеста для получения данных графика..."
echo ""

# Получаем первую доступную стратегию
STRATEGY=$(curl -s http://localhost:8889/api/strategies | python3 -c "import sys, json; data=json.load(sys.stdin); print(data['strategies'][0]['name'] if data.get('strategies') else 'AdvancedIndicatorStrategy')" 2>/dev/null || echo "AdvancedIndicatorStrategy")

echo "📊 Используем стратегию: $STRATEGY"
echo "📈 Пара: BTC/USDT"
echo "⏱️  Timeframe: 5m"
echo ""

# Проверяем наличие данных
DATA_FILE="user_data/data/binance/BTC_USDT-5m.json"
if [ ! -f "$DATA_FILE" ]; then
    echo "⚠️  Данные не найдены, попробуем скачать..."
    echo "   (Это может занять несколько минут)"
    echo ""
    
    # Пробуем скачать данные через Freqtrade
    if command -v freqtrade &> /dev/null; then
        freqtrade download-data \
            --exchange binance \
            --pairs BTC/USDT \
            --timeframes 5m \
            --days 7 \
            --config ../config/freqtrade_config.json 2>&1 | tail -5
    fi
fi

# Запускаем бэктест
echo ""
echo "🔄 Запуск бэктеста..."
RESPONSE=$(curl -s -X POST http://localhost:8889/api/backtest/run \
    -H "Content-Type: application/json" \
    -d "{
        \"strategy_name\": \"$STRATEGY\",
        \"pairs\": [\"BTC/USDT\"],
        \"timeframe\": \"5m\"
    }")

echo "$RESPONSE" | python3 -m json.tool 2>/dev/null || echo "$RESPONSE"

echo ""
echo "✅ Бэктест запущен в фоне!"
echo ""
echo "⏳ Ожидайте завершения (обычно 1-5 минут)..."
echo ""
echo "📊 Проверка статуса:"
echo "   curl http://localhost:8889/api/backtest/status"
echo ""
echo "📈 После завершения откройте стратегию в UI для просмотра графика"


