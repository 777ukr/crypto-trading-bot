# 🔧 Решение проблемы черного экрана в FreqUI Backtesting

## ❌ Проблема
Страница `http://127.0.0.1:8081/backtesting` показывает черный экран - базовый HTML загружается, но JavaScript не работает.

## ✅ Решение 1: Использовать кастомную страницу (РЕКОМЕНДУЕТСЯ)

### Откройте кастомную страницу:
```bash
cd /home/crypto/sites/cryptotrader.com/freqtrade
xdg-open user_data/web/backtest_results.html
```

Или напрямую в браузере:
```
file:///home/crypto/sites/cryptotrader.com/freqtrade/user_data/web/backtest_results.html
```

**Эта страница показывает:**
- ✅ Все 26 бэктестов
- ✅ Результаты по стратегиям
- ✅ Статистику (PNL, Win Rate, Profit Factor)
- ✅ Прямые ссылки на API
- ✅ Автообновление каждые 30 секунд

## ✅ Решение 2: Исправить FreqUI

### Проверка консоли браузера

1. **Откройте DevTools** (F12)
2. **Перейдите на вкладку Console**
3. **Проверьте ошибки:**
   - Если есть ошибки 404 (файлы не найдены) - проблема с путями
   - Если есть CORS ошибки - проблема с настройками API
   - Если есть JavaScript ошибки - проблема с версией FreqUI

### Возможные причины:

1. **FreqUI не установлен правильно:**
   ```bash
   cd /home/crypto/sites/cryptotrader.com/freqtrade
   source .venv/bin/activate
   freqtrade install-ui --erase
   freqtrade install-ui
   ```

2. **Веб-сервер не запущен:**
   ```bash
   # Проверьте, что freqtrade запущен
   ps aux | grep freqtrade
   
   # Если нет - запустите:
   cd /home/crypto/sites/cryptotrader.com/freqtrade
   source .venv/bin/activate
   freqtrade trade --config ../config/freqtrade_config.json --strategy TestStrategy
   ```

3. **Проблема с путями к статическим файлам:**
   - Проверьте, что файлы находятся в `.venv/lib/python3.11/site-packages/freqtrade/rpc/api_server/ui/installed/`
   - Проверьте права доступа к файлам

4. **Проблема с версией FreqUI:**
   - Текущая версия: 2.1.0
   - Возможно, нужна более новая версия

## ✅ Решение 3: Использовать CLI (всегда работает)

```bash
# Показать все результаты
freqtrade backtesting-show

# Показать конкретный результат
freqtrade backtesting-show --backtest-filename=backtest-result-YYYYMMDD_HHMMSS.zip

# Показать рейтинг
freqtrade backtesting-show --show-pair-list
```

## 📊 Альтернатива: Прямой доступ к API

### Список всех бэктестов:
```bash
curl -u freqtrader:PASSWORD \
  http://127.0.0.1:8081/api/v1/backtest/history
```

### Конкретный результат:
```bash
curl -u freqtrader:PASSWORD \
  "http://127.0.0.1:8081/api/v1/backtest/history/result?filename=backtest-result-YYYYMMDD_HHMMSS.zip&strategy=StrategyName"
```

## 🎯 Рекомендация

**Используйте кастомную страницу** (`user_data/web/backtest_results.html`) - она:
- ✅ Работает независимо от FreqUI
- ✅ Показывает все результаты
- ✅ Автоматически обновляется
- ✅ Имеет красивый интерфейс
- ✅ Не требует веб-сервера (можно открыть как файл)

## 📝 Обновление кастомной страницы

После запуска новых бэктестов:
```bash
cd /home/crypto/sites/cryptotrader.com/freqtrade
python3 create_custom_backtest_page.py
```



