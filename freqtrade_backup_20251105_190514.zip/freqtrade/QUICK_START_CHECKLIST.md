# ✅ Быстрый чеклист для старта

## 📊 Текущее состояние системы

✅ **Готово:**
- 7 стратегий найдено
- 27 бэктестов выполнено
- rankings.json существует
- FastAPI установлен и работает
- API сервер работает на http://localhost:8889
- Базовый UI доступен

⚠️ **Требует внимания:**
- ACTIVE_STRATEGIES еще используется в 3 файлах (нужно автообнаружение)
- Массовое тестирование частично реализовано
- Вкладки и фильтры не реализованы
- Темная/светлая тема не реализована

## 🎯 Первый шаг (самый важный)

### Задача: Автообнаружение стратегий

**Проблема**: В 3 файлах еще жестко заданы списки стратегий:
- `strategy_rating_system_standalone.py`
- `rating_web_interface_standalone.py`
- `strategy_test_runner.py`

**Решение**: Скажите Claude в Cursor:
```
Реализуй автообнаружение стратегий из .cursorrules.
Замени все ACTIVE_STRATEGIES = [...] на функцию get_all_strategies() 
которая автоматически находит все стратегии из user_data/strategies/.
```

**Ожидаемый результат**:
- Все стратегии автоматически обнаруживаются
- Не нужно вручную добавлять новые стратегии в списки
- Система работает с любым количеством стратегий

## 🚀 Что делать дальше (по порядку)

### 1. Автообнаружение (1 час)
```bash
# Скажите Claude:
"Реализуй автообнаружение стратегий из .cursorrules Step 1"
```

### 2. Массовое тестирование (30 минут)
```bash
# Проверьте что работает:
curl -X POST http://localhost:8889/api/backtest/run \
  -H "Content-Type: application/json" \
  -d '{"strategy_name": "all", "pairs": ["BTC/USDT"], "timeframe": "5m", "leverage": 1}'
```

### 3. Вкладки (2-3 часа)
```bash
# Скажите Claude:
"Реализуй вкладки Latest, Failed, Private, DCA, Multiclass из .cursorrules Step 2"
```

### 4. Темная/светлая тема (1-2 часа)
```bash
# Скажите Claude:
"Добавь темную/светлую тему из .cursorrules Step 7"
```

### 5. Фильтры (2-3 часа)
```bash
# Скажите Claude:
"Реализуй фильтры Exchange, Stake, Hide Negative из .cursorrules Step 3"
```

## 📝 Готовые команды для Claude

### Для автообнаружения:
```
Реализуй автообнаружение стратегий из .cursorrules.
Нужно:
1. Создать функцию get_all_strategies() в каждом файле
2. Заменить ACTIVE_STRATEGIES = [...] на ACTIVE_STRATEGIES = get_all_strategies()
3. Обновить все места где используется ACTIVE_STRATEGIES
```

### Для вкладок:
```
Реализуй вкладки из .cursorrules Step 2.
Добавь API endpoints /api/rankings/{tab} для Latest, Failed, Private, DCA, Multiclass.
Добавь UI вкладки в rating_ui.html.
```

### Для темы:
```
Добавь темную/светлую тему из .cursorrules Step 7.
Сохраняй предпочтение в localStorage.
Добавь переключатель темы в header.
```

## ✅ Проверка готовности

Перед началом работы убедитесь:

```bash
cd /home/crypto/sites/cryptotrader.com/freqtrade

# 1. Сервер работает
curl http://localhost:8889/api/stats

# 2. Стратегии найдены
ls user_data/strategies/*.py | wc -l  # Должно быть > 0

# 3. Бэктесты есть
ls user_data/backtest_results/*.zip 2>/dev/null | wc -l  # Должно быть > 0

# 4. Рейтинги есть
test -f user_data/ratings/rankings.json && echo "✅" || echo "⚠️  Запустите: python3 strategy_rating_system_standalone.py"
```

## 🎬 Быстрый старт

### Вариант 1: Начать с автообнаружения
1. Откройте Cursor в папке `freqtrade/`
2. Скажите: "Реализуй автообнаружение стратегий из .cursorrules"
3. Проверьте что все стратегии обнаруживаются
4. Перезапустите сервер: `python3 rating_api_server.py`

### Вариант 2: Начать с UI
1. Откройте `user_data/web/rating_ui.html`
2. Скажите: "Добавь темную/светлую тему из .cursorrules"
3. Проверьте в браузере: http://localhost:8889

## 📚 Документация

- `.cursorrules` - Полные инструкции для LLM
- `START_HERE.md` - Детальный план реализации
- `QUICK_START_CHECKLIST.md` - Этот файл (быстрый старт)

## ⚠️ Важные замечания

1. **Всегда автообнаружение** - Не используйте жестко заданные списки
2. **Тестируйте** - После каждого изменения проверяйте работу
3. **Коммитьте** - Сохраняйте рабочие изменения
4. **Ошибки** - Всегда graceful fallbacks (PostgreSQL → JSON)

## 🎯 Готово к старту?

- [x] `.cursorrules` создан
- [x] `START_HERE.md` создан
- [x] Python 3.11+ установлен
- [x] FastAPI установлен
- [x] Стратегии найдены (7 шт)
- [x] Бэктесты есть (27 шт)
- [x] Рейтинги есть
- [ ] Автообнаружение реализовано (первый шаг!)

**Начните с автообнаружения - это самый важный первый шаг!**

