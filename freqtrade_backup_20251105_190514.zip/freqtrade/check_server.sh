#!/bin/bash
# Проверка сервера

echo "🔍 Проверка сервера..."
echo ""

# 1. Проверка процесса
echo "1. Процесс сервера:"
ps aux | grep "[r]ating_api_server" || echo "   ❌ Сервер не запущен"
echo ""

# 2. Проверка порта
echo "2. Порт 8889:"
lsof -i:8889 || netstat -tuln | grep 8889 || echo "   ❌ Порт не слушается"
echo ""

# 3. Проверка HTTP
echo "3. HTTP ответ:"
curl -s -o /dev/null -w "   Статус: %{http_code}\n" http://localhost:8889/ || echo "   ❌ Не отвечает"
echo ""

# 4. Проверка API
echo "4. API endpoints:"
curl -s http://localhost:8889/api/stats | python3 -m json.tool 2>/dev/null | head -5 || echo "   ❌ API не работает"
echo ""

# 5. Логи
echo "5. Последние логи:"
tail -5 api_server.log 2>/dev/null || echo "   Лог не найден"
echo ""

echo "✅ Проверка завершена"

