# 🚀 Полная система рейтинга стратегий - Руководство

## 🎯 Что создано

### 1. ✅ Полноценный веб-интерфейс
- **URL:** `http://localhost:8889`
- Современный UI/UX с темной темой
- Фильтры и сортировки
- Запуск бэктестов из интерфейса
- Управление стратегиями

### 2. ✅ FastAPI Backend
- REST API для всех операций
- Интеграция с PostgreSQL
- Фоновые задачи для бэктестов
- Автоматическое сохранение результатов

### 3. ✅ PostgreSQL Integration
- Все данные в базе данных
- Не зависит от JSON файлов
- Поддержка всех leverage (1x, 2x, 5x, 10x и т.д.)
- История и статистика

### 4. ✅ Добавленные стратегии
- `MShotStrategy` - работает ✅
- `E0V1E_20231004_085308` - добавлена ✅
- `ElliotV5_SMA` - добавлена ✅

## 🚀 Быстрый старт

### 1. Установить зависимости:

```bash
cd /home/crypto/sites/cryptotrader.com/freqtrade
source .venv/bin/activate
pip install -r requirements_rating.txt
```

### 2. Настроить PostgreSQL:

```bash
export DATABASE_URL="postgresql://postgres:postgres@localhost:5432/cryptotrader"
psql "$DATABASE_URL" -f ../database/strategy_rating_schema.sql
```

### 3. Загрузить данные в PostgreSQL:

```bash
python3 strategy_rating_system_postgresql.py
```

### 4. Запустить API сервер:

```bash
./start_rating_server.sh
```

Или вручную:
```bash
python3 rating_api_server.py
```

### 5. Открыть веб-интерфейс:

```
http://localhost:8889
```

## 📊 Возможности интерфейса

### Фильтры:
- ✅ Минимум сделок
- ✅ Минимум прибыли (%)
- ✅ Максимальное плечо (1x, 2x, 5x, 10x, или все)
- ✅ Исключить stalled стратегии
- ✅ Исключить стратегии с bias

### Сортировка:
- ✅ По Ninja Score
- ✅ По Profit %
- ✅ По Win Rate
- ✅ По Profit Factor
- ✅ По Sharpe Ratio
- ✅ По любому полю (клик по заголовку)

### Управление:
- ✅ Запуск бэктестов из интерфейса
- ✅ Выбор стратегии
- ✅ Выбор монет (BTC, ETH, SOL и т.д.)
- ✅ Выбор timeframe
- ✅ Выбор leverage

## 🔧 API Endpoints

### Получить рейтинг:
```
GET /api/rankings?min_trades=10&min_profit=0&max_leverage=10&sort_by=ninja_score&order=desc
```

### Запустить бэктест:
```
POST /api/backtest/run
{
  "strategy_name": "MShotStrategy",
  "pairs": ["BTC/USDT", "ETH/USDT", "SOL/USDT"],
  "timeframe": "5m",
  "leverage": 1
}
```

### Получить статистику:
```
GET /api/stats
```

### Получить список стратегий:
```
GET /api/strategies
```

### Удалить стратегию:
```
DELETE /api/strategies/{strategy_name}
```

## 📈 Рейтинг поддерживает

- ✅ **Все leverage** (1x, 2x, 5x, 10x и т.д.)
- ✅ **Все монеты** (BTC, ETH, SOL и любые другие)
- ✅ **Все стратегии** (не только без bias)
- ✅ **Фильтрация** по любым параметрам
- ✅ **Сортировка** по любому полю

## 🎯 Что дальше

### Планируется:
1. Парсер истории с Gate.io
2. Расчет доходности с комиссиями
3. Автоматическое обновление рейтингов
4. Уведомления о новых результатах
5. Экспорт данных в CSV/Excel

## 💡 Использование

### Полный цикл работы:

1. **Запустить API сервер:**
   ```bash
   ./start_rating_server.sh
   ```

2. **Открыть интерфейс:**
   ```
   http://localhost:8889
   ```

3. **Запустить бэктест:**
   - Нажать "Запустить бэктест"
   - Выбрать стратегию
   - Выбрать монеты
   - Выбрать leverage
   - Нажать "Запустить"

4. **Просмотреть результаты:**
   - Результаты автоматически появятся в рейтинге
   - Можно фильтровать и сортировать
   - Сравнивать стратегии

## ✅ Готово к использованию!

Система полностью функциональна и готова к работе. Все данные сохраняются в PostgreSQL, можно работать через браузер без терминала.



