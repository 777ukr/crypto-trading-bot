#!/usr/bin/env python3
"""
Health Check - Проверка здоровья системы
"""

import requests
import sys
from pathlib import Path

API_URL = "http://localhost:8889"
FREQTRADE_DIR = Path(__file__).parent

def check_api_health():
    """Проверка здоровья API"""
    try:
        response = requests.get(f"{API_URL}/api/strategies", timeout=5)
        return response.status_code == 200
    except:
        return False

def check_database_health():
    """Проверка здоровья базы данных"""
    try:
        import psycopg2
        from psycopg2.pool import ThreadedConnectionPool
        import os
        
        database_url = os.getenv("DATABASE_URL", "postgresql://postgres:postgres@localhost:5432/cryptotrader")
        pool = ThreadedConnectionPool(1, 1, database_url)
        conn = pool.getconn()
        conn.close()
        pool.putconn(conn)
        return True
    except:
        return False  # Не критично, есть JSON fallback

def check_file_system():
    """Проверка файловой системы"""
    required_dirs = [
        "user_data/strategies",
        "user_data/backtest_results",
        "user_data/ratings",
        "user_data/web",
    ]
    
    for dir_path in required_dirs:
        if not (FREQTRADE_DIR / dir_path).exists():
            return False
    return True

def main():
    """Главная функция проверки здоровья"""
    print("🏥 Health Check")
    print("=" * 50)
    
    checks = [
        ("API Server", check_api_health),
        ("File System", check_file_system),
        ("Database", check_database_health),
    ]
    
    all_ok = True
    for name, check_func in checks:
        result = check_func()
        status = "✅" if result else "❌"
        print(f"{status} {name}: {'OK' if result else 'FAILED'}")
        if not result and name != "Database":  # DB не критично
            all_ok = False
    
    print("=" * 50)
    if all_ok:
        print("✅ System is healthy")
        sys.exit(0)
    else:
        print("❌ System has issues")
        sys.exit(1)

if __name__ == "__main__":
    main()

