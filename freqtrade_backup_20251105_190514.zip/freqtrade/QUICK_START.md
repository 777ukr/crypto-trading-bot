# 🚀 Быстрый старт

## 📍 Правильные пути

Все скрипты находятся в директории `freqtrade/`:

```bash
cd /home/crypto/sites/cryptotrader.com/freqtrade
```

## 📋 Последовательность запуска

### 1. Установить зависимости (если нужно):

```bash
source .venv/bin/activate
pip install psycopg2-binary requests
```

### 2. Настроить PostgreSQL (опционально):

```bash
# Если PostgreSQL не запущен, используйте standalone версию
export DATABASE_URL="postgresql://postgres:postgres@localhost:5432/cryptotrader"
```

### 3. Парсинг монет:

```bash
python3 gateio_coin_parser.py
```

### 4. Скачивание данных (используйте Freqtrade CLI):

```bash
# Рекомендуется использовать встроенный Freqtrade downloader
freqtrade download-data --exchange gateio --pairs BTC/USDT ETH/USDT SOL/USDT --timeframes 5m --days 30
```

### 5. Запуск бэктестов:

```bash
python3 strategy_test_runner.py --all
```

### 6. Обновление рейтинга:

```bash
# Если PostgreSQL доступен:
python3 strategy_rating_system_postgresql.py

# Или standalone версия (без PostgreSQL):
python3 strategy_rating_system_standalone.py
```

### 7. Запуск веб-интерфейса:

```bash
./start_rating_server.sh
```

Откройте в браузере: `http://localhost:8889`

## ⚠️ Решение проблем

### PostgreSQL не доступен:
- Используйте `strategy_rating_system_standalone.py` вместо PostgreSQL версии
- Веб-интерфейс будет работать, но покажет пустые данные

### Ошибки скачивания данных:
- Используйте Freqtrade CLI: `freqtrade download-data`
- Или установите правильное время на сервере

### Ошибки модулей:
```bash
pip install -r requirements_rating.txt
```

