#!/usr/bin/env python3
"""
API для расчета доходности с учетом всех факторов
Интеграция с системой рейтинга стратегий
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Dict, Optional
from advanced_profitability_calculator import (
    ProfitabilityCalculator, Exchange, TradingType, 
    compare_exchanges, calculate_optimal_strategy, AVAILABLE_LEVERAGES
)

router = APIRouter()

class ProfitabilityRequest(BaseModel):
    """Запрос на расчет доходности"""
    trades: List[Dict]  # Список сделок из бэктеста
    exchange: str = "binance"
    trading_type: str = "spot"
    leverage: int = 1
    deposit: float = 1000
    is_referrer: bool = False

class ComparisonRequest(BaseModel):
    """Запрос на сравнение бирж"""
    trades: List[Dict]
    deposit: float = 1000
    leverage: int = 1
    trading_type: str = "spot"

@router.post("/api/profitability/calculate")
async def calculate_profitability(request: ProfitabilityRequest):
    """Рассчитать доходность с учетом всех факторов"""
    try:
        exchange = Exchange(request.exchange.lower())
        trading_type = TradingType(request.trading_type.lower())
        
        calc = ProfitabilityCalculator(
            exchange=exchange,
            trading_type=trading_type,
            leverage=request.leverage,
            deposit=request.deposit
        )
        
        result = calc.calculate_profitability(
            request.trades,
            is_referrer=request.is_referrer
        )
        
        # Добавляем информацию о конфигурации
        result["config"] = {
            "exchange": request.exchange,
            "trading_type": request.trading_type,
            "leverage": request.leverage,
            "deposit": request.deposit,
            "slippage_bps": calc.slippage_bps,
            "spread_bps": calc.config.spread_bps,
            "rebate": calc.config.rebate_spot if trading_type == TradingType.SPOT else calc.config.rebate_futures,
            "referral_rebate": calc.config.referral_rebate
        }
        
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/api/profitability/compare")
async def compare_profitability(request: ComparisonRequest):
    """Сравнить доходность на разных биржах"""
    try:
        trading_type = TradingType(request.trading_type.lower())
        results = compare_exchanges(
            request.trades,
            deposit=request.deposit,
            leverage=request.leverage,
            trading_type=trading_type
        )
        return results
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/api/profitability/optimal")
async def find_optimal_strategy(request: ComparisonRequest):
    """Найти оптимальную комбинацию параметров"""
    try:
        result = calculate_optimal_strategy(request.trades, request.deposit)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/api/profitability/leverages")
async def get_available_leverages():
    """Получить список доступных плеч"""
    return {"leverages": AVAILABLE_LEVERAGES}

@router.get("/api/profitability/deposits")
async def get_deposit_slippage():
    """Получить таблицу проскальзываний по депозитам"""
    from advanced_profitability_calculator import SLIPPAGE_BY_DEPOSIT
    return {
        "deposits": list(SLIPPAGE_BY_DEPOSIT.keys()),
        "slippage": SLIPPAGE_BY_DEPOSIT
    }


