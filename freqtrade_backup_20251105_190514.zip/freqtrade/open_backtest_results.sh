#!/bin/bash
# Скрипт для открытия кастомной страницы с результатами бэктестов

cd "$(dirname "$0")"

# Создаем/обновляем страницу
echo "🔄 Обновление страницы результатов..."
source .venv/bin/activate 2>/dev/null
python3 create_custom_backtest_page.py 2>/dev/null || echo "⚠️  Используем существующую страницу"

# Открываем в браузере
HTML_FILE="user_data/web/backtest_results.html"

if [ -f "$HTML_FILE" ]; then
    echo "✅ Открываю страницу результатов..."
    xdg-open "$HTML_FILE" 2>/dev/null || \
    gnome-open "$HTML_FILE" 2>/dev/null || \
    open "$HTML_FILE" 2>/dev/null || \
    echo "📋 Откройте вручную: file://$(pwd)/$HTML_FILE"
else
    echo "❌ Файл не найден: $HTML_FILE"
    echo "💡 Создайте страницу: python3 create_custom_backtest_page.py"
fi

echo ""
echo "🌐 Альтернативные способы просмотра:"
echo "   - CLI: freqtrade backtesting-show"
echo "   - FreqUI: http://127.0.0.1:8081/backtesting"
echo "   - API: http://127.0.0.1:8081/api/v1/backtest/history"



