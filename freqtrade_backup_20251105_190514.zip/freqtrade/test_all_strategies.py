#!/usr/bin/env python3
"""
Полное тестирование всех стратегий с экспортом результатов
и генерацией визуального отчета
"""

import json
import subprocess
import sys
import os
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional
import pandas as pd

# Конфигурация
FREQTRADE_DIR = Path(__file__).parent
CONFIG_PATH = FREQTRADE_DIR.parent / "config" / "freqtrade_config.json"
STRATEGIES_DIR = FREQTRADE_DIR / "user_data" / "strategies"
RESULTS_DIR = FREQTRADE_DIR / "user_data" / "backtest_results"
REPORT_DIR = FREQTRADE_DIR / "user_data" / "strategy_reports"

# Параметры
END_DATE = datetime.now().strftime("%Y%m%d")
START_DATE = (datetime.now() - timedelta(days=30)).strftime("%Y%m%d")
TIMERANGE = f"{START_DATE}-{END_DATE}"
TIMEFRAME = "5m"
PAIRS = ["BTC/USDT", "ETH/USDT", "SOL/USDT"]


class StrategyTester:
    """Полное тестирование стратегий с экспортом"""
    
    def __init__(self):
        self.results = []
        self.rankings = []
    
    def find_strategies(self) -> List[str]:
        """Находит все стратегии"""
        strategies = []
        for file in STRATEGIES_DIR.glob("*.py"):
            if file.name != "__init__.py" and not file.name.startswith("_"):
                strategy_name = file.stem
                # Пропускаем TestStrategy (базовая)
                if strategy_name != "TestStrategy":
                    strategies.append(strategy_name)
        return strategies
    
    def run_backtest_with_export(self, strategy_name: str, pair: str) -> Optional[Dict]:
        """Запускает бэктест с экспортом результатов"""
        print(f"\n{'='*70}")
        print(f"🧪 Тестирование: {strategy_name} на {pair}")
        print(f"{'='*70}")
        
        # Создаем директорию для результатов
        RESULTS_DIR.mkdir(parents=True, exist_ok=True)
        
        # Имя файла для экспорта
        export_filename = f"{strategy_name}_{pair.replace('/', '_')}_trades"
        
        cmd = [
            "freqtrade", "backtesting",
            "--config", str(CONFIG_PATH),
            "--strategy", strategy_name,
            "--timerange", TIMERANGE,
            "--timeframe", TIMEFRAME,
            "--pairs", pair,
            "--export", "trades",
            "--export-filename", export_filename,
            "--breakdown", "month",
            "--cache", "none"
        ]
        
        try:
            result = subprocess.run(
                cmd,
                cwd=str(FREQTRADE_DIR),
                capture_output=True,
                text=True,
                timeout=600
            )
            
            if result.returncode != 0:
                print(f"❌ Ошибка: {result.stderr[:500]}")
                return None
            
            # Парсим результаты
            metrics = self.parse_backtest_output(result.stdout, strategy_name, pair, export_filename)
            return metrics
            
        except subprocess.TimeoutExpired:
            print(f"⏱️  Таймаут при тестировании {strategy_name}")
            return None
        except Exception as e:
            print(f"❌ Ошибка: {e}")
            return None
    
    def parse_backtest_output(self, output: str, strategy_name: str, pair: str, export_filename: str) -> Dict:
        """Парсит вывод freqtrade backtesting"""
        metrics = {
            "strategy": strategy_name,
            "pair": pair,
            "total_trades": 0,
            "winning_trades": 0,
            "losing_trades": 0,
            "total_profit": 0.0,
            "profit_pct": 0.0,
            "max_drawdown": 0.0,
            "profit_factor": 0.0,
            "win_rate": 0.0,
            "sharpe_ratio": 0.0,
            "avg_trade_duration": 0.0,
            "export_file": None,
        }
        
        # Пытаемся загрузить CSV с результатами
        csv_file = RESULTS_DIR / f"{export_filename}_trades.csv"
        if csv_file.exists():
            try:
                df = pd.read_csv(csv_file)
                if not df.empty:
                    metrics["total_trades"] = len(df)
                    metrics["winning_trades"] = len(df[df["profit_abs"] > 0])
                    metrics["losing_trades"] = len(df[df["profit_abs"] <= 0])
                    metrics["total_profit"] = df["profit_abs"].sum()
                    
                    # Profit %
                    if "profit_ratio" in df.columns:
                        metrics["profit_pct"] = df["profit_ratio"].sum() * 100
                    elif "profit_pct" in df.columns:
                        metrics["profit_pct"] = df["profit_pct"].sum()
                    
                    # Win rate
                    metrics["win_rate"] = (metrics["winning_trades"] / metrics["total_trades"] * 100) if metrics["total_trades"] > 0 else 0
                    
                    # Profit factor
                    wins = df[df["profit_abs"] > 0]["profit_abs"].sum()
                    losses = abs(df[df["profit_abs"] < 0]["profit_abs"].sum())
                    metrics["profit_factor"] = wins / losses if losses > 0 else 0
                    
                    # Max drawdown из equity
                    if "cumulative_profit" in df.columns:
                        cumulative = df["cumulative_profit"]
                        running_max = cumulative.expanding().max()
                        drawdown = (cumulative - running_max) / running_max.abs()
                        metrics["max_drawdown"] = abs(drawdown.min() * 100) if not drawdown.empty else 0.0
                    
                    # Avg trade duration
                    if "close_date" in df.columns and "open_date" in df.columns:
                        df["duration"] = pd.to_datetime(df["close_date"]) - pd.to_datetime(df["open_date"])
                        metrics["avg_trade_duration"] = df["duration"].mean().total_seconds() / 60  # минуты
                    
                    metrics["export_file"] = str(csv_file)
            except Exception as e:
                print(f"⚠️  Не удалось загрузить CSV: {e}")
        
        # Парсим из вывода если CSV не доступен
        lines = output.split('\n')
        for line in lines:
            if "Total trades" in line or "Total" in line and "trades" in line.lower():
                try:
                    parts = line.split()
                    for i, part in enumerate(parts):
                        if part.isdigit():
                            metrics["total_trades"] = int(part)
                            break
                except:
                    pass
            
            if "Profit" in line and "%" in line:
                try:
                    parts = line.split()
                    for part in parts:
                        if "%" in part:
                            metrics["profit_pct"] = float(part.replace("%", "").replace("-", ""))
                            break
                except:
                    pass
        
        return metrics
    
    def calculate_rating(self, metrics: Dict) -> Dict:
        """Вычисляет рейтинг стратегии"""
        # Profitability Score (0-10)
        profit_score = min(abs(metrics["profit_pct"]) / 10.0, 10.0) if metrics["profit_pct"] > 0 else 0
        pf_score = min(metrics["profit_factor"] / 5.0 * 10.0, 10.0) if metrics["profit_factor"] > 0 else 0
        wr_score = metrics["win_rate"] / 10.0
        profitability_score = (profit_score * 0.4 + pf_score * 0.3 + wr_score * 0.3)
        
        # Stability Score (0-10)
        stability_score = min(metrics["total_trades"] / 100.0 * 10.0, 10.0)
        
        # Risk Score (0-10)
        risk_score = max(0, 10.0 - (metrics["max_drawdown"] / 10.0))
        
        # Fill Rate Score
        fill_rate_score = min(metrics["win_rate"] / 10.0, 10.0)
        
        # Overall Rating
        overall_rating = (
            profitability_score * 0.35 +
            stability_score * 0.25 +
            risk_score * 0.25 +
            fill_rate_score * 0.15
        )
        
        # Stars (0-5)
        stars = min(5, int(overall_rating / 2.0))
        
        return {
            "profitability_score": round(profitability_score, 2),
            "stability_score": round(stability_score, 2),
            "risk_score": round(risk_score, 2),
            "fill_rate_score": round(fill_rate_score, 2),
            "overall_rating": round(overall_rating, 2),
            "stars": stars
        }
    
    def test_all_strategies(self):
        """Тестирует все стратегии на всех парах"""
        strategies = self.find_strategies()
        print(f"\n🔍 Найдено стратегий: {len(strategies)}")
        for s in strategies:
            print(f"  - {s}")
        
        if not strategies:
            print("❌ Стратегии не найдены!")
            return
        
        # Тестируем каждую стратегию на каждой паре
        for strategy in strategies:
            for pair in PAIRS:
                metrics = self.run_backtest_with_export(strategy, pair)
                if metrics:
                    rating = self.calculate_rating(metrics)
                    result = {**metrics, **rating}
                    self.results.append(result)
        
        # Сохраняем результаты
        self.save_results()
        
        # Генерируем отчет
        self.generate_html_report()
        
        # Выводим рейтинг
        self.print_rankings()
    
    def save_results(self):
        """Сохраняет результаты в JSON"""
        RESULTS_DIR.mkdir(parents=True, exist_ok=True)
        results_file = RESULTS_DIR / f"strategy_rankings_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        with open(results_file, 'w') as f:
            json.dump(self.results, f, indent=2)
        
        print(f"\n💾 Результаты сохранены: {results_file}")
    
    def generate_html_report(self):
        """Генерирует HTML отчет с рейтингом"""
        REPORT_DIR.mkdir(parents=True, exist_ok=True)
        
        if not self.results:
            return
        
        # Сортируем по рейтингу
        sorted_results = sorted(self.results, key=lambda x: x.get("overall_rating", 0), reverse=True)
        
        html = f"""
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Рейтинг стратегий Freqtrade</title>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            margin: 0;
            padding: 20px;
            background: #f5f5f5;
        }}
        .container {{
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        h1 {{
            color: #333;
            border-bottom: 3px solid #4CAF50;
            padding-bottom: 10px;
        }}
        .stats-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 30px 0;
        }}
        .stat-card {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 8px;
        }}
        .stat-card h3 {{
            margin: 0 0 10px 0;
            font-size: 14px;
            opacity: 0.9;
        }}
        .stat-card .value {{
            font-size: 32px;
            font-weight: bold;
        }}
        table {{
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }}
        th {{
            background: #4CAF50;
            color: white;
            padding: 12px;
            text-align: left;
            font-weight: 600;
        }}
        td {{
            padding: 12px;
            border-bottom: 1px solid #ddd;
        }}
        tr:hover {{
            background: #f9f9f9;
        }}
        .rating {{
            font-size: 18px;
            font-weight: bold;
            color: #4CAF50;
        }}
        .stars {{
            color: #FFD700;
            font-size: 20px;
        }}
        .positive {{
            color: #4CAF50;
        }}
        .negative {{
            color: #f44336;
        }}
        .pair-badge {{
            display: inline-block;
            padding: 4px 8px;
            background: #e3f2fd;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 600;
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🏆 Рейтинг стратегий Freqtrade</h1>
        <p><strong>Период:</strong> {TIMERANGE} ({TIMEFRAME})</p>
        <p><strong>Дата генерации:</strong> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
        
        <div class="stats-grid">
            <div class="stat-card">
                <h3>Всего стратегий</h3>
                <div class="value">{len(set(r['strategy'] for r in sorted_results))}</div>
            </div>
            <div class="stat-card">
                <h3>Всего тестов</h3>
                <div class="value">{len(sorted_results)}</div>
            </div>
            <div class="stat-card">
                <h3>Лучший рейтинг</h3>
                <div class="value">{sorted_results[0]['overall_rating']:.2f}</div>
            </div>
            <div class="stat-card">
                <h3>Средний рейтинг</h3>
                <div class="value">{sum(r['overall_rating'] for r in sorted_results) / len(sorted_results):.2f}</div>
            </div>
        </div>
        
        <table>
            <thead>
                <tr>
                    <th>№</th>
                    <th>Стратегия</th>
                    <th>Пара</th>
                    <th>⭐ Рейтинг</th>
                    <th>PNL %</th>
                    <th>Сделок</th>
                    <th>Win Rate</th>
                    <th>Profit Factor</th>
                    <th>Drawdown</th>
                    <th>Sharpe</th>
                </tr>
            </thead>
            <tbody>
"""
        
        for i, result in enumerate(sorted_results, 1):
            strategy = result.get("strategy", "N/A")
            pair = result.get("pair", "N/A")
            rating = result.get("overall_rating", 0.0)
            stars = "⭐" * result.get("stars", 0)
            pnl = result.get("profit_pct", 0.0)
            trades = result.get("total_trades", 0)
            win_rate = result.get("win_rate", 0.0)
            pf = result.get("profit_factor", 0.0)
            dd = result.get("max_drawdown", 0.0)
            
            pnl_class = "positive" if pnl >= 0 else "negative"
            
            html += f"""
                <tr>
                    <td><strong>{i}</strong></td>
                    <td><strong>{strategy}</strong></td>
                    <td><span class="pair-badge">{pair}</span></td>
                    <td>
                        <span class="rating">{rating:.2f}</span>
                        <span class="stars">{stars}</span>
                    </td>
                    <td class="{pnl_class}"><strong>{pnl:+.2f}%</strong></td>
                    <td>{trades}</td>
                    <td>{win_rate:.1f}%</td>
                    <td>{pf:.2f}</td>
                    <td class="negative">{dd:.2f}%</td>
                    <td>{result.get('sharpe_ratio', 0.0):.2f}</td>
                </tr>
"""
        
        html += """
            </tbody>
        </table>
        
        <div style="margin-top: 40px; padding: 20px; background: #f9f9f9; border-radius: 8px;">
            <h2>📊 Как просмотреть результаты в Freqtrade Web UI</h2>
            <ol>
                <li>Откройте <a href="http://127.0.0.1:8081" target="_blank">http://127.0.0.1:8081</a></li>
                <li>Войдите (логин: freqtrader, пароль: см. config/freqtrade_config.json)</li>
                <li>Перейдите в раздел <strong>"Backtesting"</strong> в меню</li>
                <li>Выберите стратегию и пару для просмотра результатов</li>
                <li>Или используйте команду: <code>freqtrade backtesting-show</code></li>
            </ol>
            
            <h3>📁 Файлы с результатами:</h3>
            <ul>
"""
        
        for result in sorted_results:
            if result.get("export_file"):
                html += f'<li><code>{result["export_file"]}</code></li>'
        
        html += """
            </ul>
        </div>
    </div>
</body>
</html>
"""
        
        report_file = REPORT_DIR / f"strategy_ranking_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write(html)
        
        print(f"\n📊 HTML отчет создан: {report_file}")
        print(f"🌐 Откройте в браузере: file://{report_file}")
    
    def print_rankings(self):
        """Выводит рейтинг в консоль"""
        if not self.results:
            print("❌ Нет результатов для ранжирования")
            return
        
        sorted_results = sorted(self.results, key=lambda x: x.get("overall_rating", 0), reverse=True)
        
        print(f"\n{'='*100}")
        print("🏆 РЕЙТИНГ СТРАТЕГИЙ")
        print(f"{'='*100}")
        print(f"{'№':<4} {'Стратегия':<25} {'Пара':<12} {'Рейтинг':<8} {'⭐':<6} {'PNL%':<10} {'Сделок':<8} {'Win%':<8} {'PF':<8}")
        print(f"{'-'*100}")
        
        for i, result in enumerate(sorted_results, 1):
            strategy = result.get("strategy", "N/A")
            pair = result.get("pair", "N/A")
            rating = result.get("overall_rating", 0.0)
            stars = "⭐" * result.get("stars", 0)
            pnl = result.get("profit_pct", 0.0)
            trades = result.get("total_trades", 0)
            wr = result.get("win_rate", 0.0)
            pf = result.get("profit_factor", 0.0)
            
            print(f"{i:<4} {strategy:<25} {pair:<12} {rating:<8.2f} {stars:<6} {pnl:+10.2f} {trades:<8} {wr:<8.1f} {pf:<8.2f}")
        
        print(f"{'='*100}\n")


def main():
    """Главная функция"""
    print("🚀 Полное тестирование всех стратегий Freqtrade")
    print(f"📁 Директория: {FREQTRADE_DIR}")
    print(f"⏰ Таймфрейм: {TIMEFRAME}")
    print(f"📅 Период: {TIMERANGE} (последние 30 дней)")
    print(f"💰 Пары: {', '.join(PAIRS)}")
    print(f"⚠️  Внимание: Gate.io ограничивает до 10000 точек (≈34 дня для 5m)")
    
    tester = StrategyTester()
    tester.test_all_strategies()


if __name__ == "__main__":
    main()

