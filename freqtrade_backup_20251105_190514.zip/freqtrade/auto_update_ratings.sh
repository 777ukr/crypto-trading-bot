#!/bin/bash
# Автоматическое обновление рейтинга после бэктестов

cd "$(dirname "$0")"
source .venv/bin/activate

echo "🔄 Автоматическое обновление рейтинга..."

# Проверяем есть ли новые результаты
RESULTS_DIR="user_data/backtest_results"
ZIP_COUNT=$(find "$RESULTS_DIR" -name "*.zip" -type f | wc -l)

if [ "$ZIP_COUNT" -eq 0 ]; then
    echo "⚠️  Нет результатов бэктестов"
    exit 0
fi

echo "📊 Найдено $ZIP_COUNT бэктестов"

# Обновляем рейтинг
python3 strategy_rating_system_standalone.py

echo "✅ Рейтинг обновлен"

