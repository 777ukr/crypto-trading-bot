#!/usr/bin/env python3
"""
FastAPI Server for Strategy Rating System
Full-featured web interface for managing strategies, running backtests, and viewing rankings
"""

import os
import json
import subprocess
import asyncio
from pathlib import Path
from datetime import datetime, timedelta
from typing import List, Dict, Optional
import psycopg2
from psycopg2.extras import RealDictCursor, execute_values
from psycopg2.pool import ThreadedConnectionPool

from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

# Импортируем расширенный калькулятор доходности
try:
    from advanced_profitability_calculator import (
        ProfitabilityCalculator, Exchange, TradingType,
        compare_exchanges, calculate_optimal_strategy
    )
    PROFITABILITY_AVAILABLE = True
except ImportError:
    PROFITABILITY_AVAILABLE = False
    print("⚠️  Advanced profitability calculator not available")

# Configuration
FREQTRADE_DIR = Path(__file__).parent
CONFIG_PATH = FREQTRADE_DIR.parent / "config" / "freqtrade_config.json"
STRATEGIES_DIR = FREQTRADE_DIR / "user_data" / "strategies"
RESULTS_DIR = FREQTRADE_DIR / "user_data" / "backtest_results"
WEB_DIR = FREQTRADE_DIR / "user_data" / "web"

# Пытаемся получить DATABASE_URL из .env или используем дефолт
ENV_FILE = FREQTRADE_DIR.parent / ".env"
if ENV_FILE.exists():
    with open(ENV_FILE, 'r') as f:
        for line in f:
            if line.startswith('DATABASE_URL='):
                DATABASE_URL = line.split('=', 1)[1].strip().strip('"').strip("'")
                break
        else:
            DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://postgres:postgres@localhost:5432/cryptotrader")
else:
    DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://postgres:postgres@localhost:5432/cryptotrader")

app = FastAPI(title="Strategy Rating System", version="1.0.0")

# Добавляем роутер для расширенной доходности
if PROFITABILITY_AVAILABLE:
    try:
        from enhanced_profitability_api import router as profitability_router
        app.include_router(profitability_router)
    except Exception as e:
        print(f"⚠️  Не удалось загрузить profitability router: {e}")

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Static files
app.mount("/static", StaticFiles(directory=str(WEB_DIR)), name="static")

# Database pool
db_pool = None

def get_db_connection():
    """Get database connection"""
    global db_pool
    try:
        if db_pool is None:
            try:
                db_pool = ThreadedConnectionPool(1, 10, DATABASE_URL)
            except Exception as e:
                # Если не удалось создать пул, возвращаем None
                print(f"⚠️  PostgreSQL не доступен: {e}")
                return None
        try:
            return db_pool.getconn()
        except Exception as e:
            print(f"⚠️  Ошибка получения соединения: {e}")
            return None
    except Exception as e:
        print(f"⚠️  PostgreSQL не доступен: {e}")
        return None

def return_db_connection(conn):
    """Return connection to pool"""
    if db_pool:
        db_pool.putconn(conn)

# Pydantic models
class BacktestRequest(BaseModel):
    """Валидация запроса на бэктест с улучшенной проверкой"""
    strategy_name: str = Field(..., min_length=1, max_length=100, description="Название стратегии")
    pairs: List[str] = Field(default=["BTC/USDT"], min_items=1, max_items=10, description="Список торговых пар")
    timerange: Optional[str] = Field(None, description="Временной диапазон (YYYYMMDD-YYYYMMDD)")
    timeframe: str = Field(default="5m", pattern="^(1m|3m|5m|15m|30m|1h|2h|4h|1d)$", description="Таймфрейм")
    leverage: int = Field(default=1, ge=1, le=125, description="Плечо")
    exchange: str = Field(default="binance", pattern="^(binance|bybit|gateio|kucoin)$", description="Биржа")
    trading_type: str = Field(default="spot", pattern="^(spot|futures)$", description="Тип торговли")
    deposit: float = Field(default=1000, gt=0, le=1000000, description="Депозит для расчета проскальзываний")
    
    @validator('strategy_name')
    def validate_strategy_name(cls, v):
        """Валидация имени стратегии"""
        if not v.replace('_', '').replace('-', '').isalnum():
            raise ValueError('Strategy name contains invalid characters')
        return v
    
    @validator('pairs')
    def validate_pairs(cls, v):
        """Валидация формата пар"""
        for pair in v:
            if '/' not in pair or len(pair.split('/')) != 2:
                raise ValueError(f'Invalid pair format: {pair}')
        return v
    
    class Config:
        schema_extra = {
            "example": {
                "strategy_name": "ElliotV5_SMA",
                "pairs": ["BTC/USDT"],
                "timeframe": "5m",
                "leverage": 1,
                "exchange": "binance",
                "trading_type": "spot",
                "deposit": 1000
            }
        }

class StrategyFilter(BaseModel):
    min_trades: int = 0
    min_profit: float = -100
    max_leverage: Optional[int] = None
    exclude_stalled: bool = True
    exclude_bias: bool = True
    pairs: Optional[List[str]] = None

# API Routes

@app.get("/")
async def root():
    """Main page"""
    html_file = WEB_DIR / "rating_ui.html"
    if html_file.exists():
        try:
            content = html_file.read_text(encoding='utf-8')
            return HTMLResponse(content=content)
        except Exception as e:
            print(f"❌ Ошибка чтения HTML: {e}")
            return HTMLResponse(
                content=f"<h1>Strategy Rating System</h1><p>Ошибка загрузки интерфейса: {e}</p>",
                status_code=500
            )
    return HTMLResponse(
        content="<h1>Strategy Rating System API</h1><p>HTML файл не найден. Проверьте user_data/web/rating_ui.html</p>",
        status_code=404
    )

@app.get("/api/strategies")
async def get_strategies():
    """Get list of all strategies"""
    strategies = []
    for file in STRATEGIES_DIR.glob("*.py"):
        if file.name != "__init__.py" and not file.name.startswith("_"):
            # Проверяем есть ли бэктесты для стратегии
            strategy_name = file.stem
            has_backtests = any(
                f"backtest-result" in f.name and strategy_name.lower() in f.name.lower()
                for f in RESULTS_DIR.glob("*.zip")
            )
            
            strategies.append({
                "name": strategy_name,
                "file": file.name,
                "size": file.stat().st_size,
                "modified": datetime.fromtimestamp(file.stat().st_mtime).isoformat(),
                "has_backtests": has_backtests
            })
    return {"strategies": sorted(strategies, key=lambda x: x["name"])}

@app.get("/api/rankings")
async def get_rankings(
    min_trades: int = 0,
    min_profit: float = -100,
    max_leverage: Optional[str] = None,
    exclude_stalled: bool = True,
    exclude_bias: bool = True,
    sort_by: str = "ninja_score",
    order: str = "desc",
    limit: int = 100,
    exchange: Optional[str] = None,
    stake: Optional[str] = None,
    hide_negative: bool = False,
    show_dca: bool = False,
    show_multiclass: bool = False,
    timeframe: Optional[str] = None
):
    """Get strategy rankings (main/default tab)"""
    return await get_rankings_with_tab(
        tab=None,
        min_trades=min_trades,
        min_profit=min_profit,
        max_leverage=max_leverage,
        exclude_stalled=exclude_stalled,
        exclude_bias=exclude_bias,
        sort_by=sort_by,
        order=order,
        limit=limit,
        exchange=exchange,
        stake=stake,
        hide_negative=hide_negative,
        show_dca=show_dca,
        show_multiclass=show_multiclass,
        timeframe=timeframe
    )

@app.get("/api/rankings/{tab}")
async def get_rankings_with_tab(
    tab: str,
    min_trades: int = 0,
    min_profit: float = -100,
    max_leverage: Optional[str] = None,
    exclude_stalled: bool = True,
    exclude_bias: bool = True,
    sort_by: str = "ninja_score",
    order: str = "desc",
    limit: int = 100,
    exchange: Optional[str] = None,
    stake: Optional[str] = None,
    hide_negative: bool = False,
    show_dca: bool = False,
    show_multiclass: bool = False,
    timeframe: Optional[str] = None
):
    """Get strategy rankings with filters and tabs support
    
    Tabs: main (default), latest, failed, private, dca, multiclass
    """
    conn = get_db_connection()
    if conn is None:
        # Fallback: используем standalone JSON версию
        try:
            import sys
            sys.path.insert(0, str(FREQTRADE_DIR))
            from strategy_rating_system_standalone import StrategyRatingSystemStandalone
            from rating_web_interface_standalone import get_rankings_from_json
            
            rankings = get_rankings_from_json(limit=1000)  # Получаем больше для фильтрации
            
            # Обработка вкладок
            if tab == "latest":
                # Сортируем по дате обновления (последние бэктесты)
                rankings.sort(key=lambda x: x.get("updated_at", ""), reverse=True)
            elif tab == "failed":
                # Стратегии с ошибками или stalled
                rankings = [r for r in rankings if r.get("is_stalled", False) or r.get("total_backtests", 0) == 0]
            elif tab == "private":
                # Стратегии без URL (пока просто все, нужно добавить поле private)
                rankings = rankings  # TODO: добавить детекцию private стратегий
            elif tab == "dca":
                # DCA стратегии (пока просто все, нужно добавить детекцию DCA)
                rankings = rankings  # TODO: добавить детекцию DCA
            elif tab == "multiclass":
                # Multiclass стратегии (пока просто все, нужно добавить детекцию)
                rankings = rankings  # TODO: добавить детекцию multiclass
            # else: main/default - без дополнительной фильтрации
            
            # Применяем фильтры
            filtered = []
            for r in rankings:
                # Exchange filter
                if exchange and r.get("exchange", "").lower() != exchange.lower():
                    continue
                
                # Stake filter
                if stake and r.get("stake_currency", "").upper() != stake.upper():
                    continue
                
                # Timeframe filter
                if timeframe and r.get("timeframe", "").lower() != timeframe.lower():
                    continue
                
                # Hide negative
                if hide_negative and r.get("median_total_profit_pct", 0) < 0:
                    continue
                
                # Show DCA
                if tab != "dca" and not show_dca:
                    # Если не на вкладке DCA и show_dca выключен, пропускаем DCA стратегии
                    # TODO: добавить проверку флага DCA
                    pass
                
                # Show Multiclass
                if tab != "multiclass" and not show_multiclass:
                    # TODO: добавить проверку флага multiclass
                    pass
                
                # Стандартные фильтры
                if r.get("median_total_trades", 0) < min_trades:
                    continue
                if r.get("median_total_profit_pct", -100) < min_profit:
                    continue
                if max_leverage and max_leverage.strip():
                    try:
                        if r.get("leverage", 1) > int(max_leverage):
                            continue
                    except:
                        pass
                if tab != "failed":  # На вкладке failed не исключаем stalled
                    if exclude_stalled and r.get("is_stalled", False):
                        continue
                if exclude_bias and r.get("has_lookahead_bias", False):
                    continue
                filtered.append(r)
            
            # Сортировка
            reverse = order.lower() == "desc"
            try:
                filtered.sort(key=lambda x: x.get(sort_by, 0), reverse=reverse)
            except:
                pass
            
            return JSONResponse(
                status_code=200,
                content={
                    "rankings": filtered[:limit],
                    "total": len(filtered),
                    "filtered": len(filtered),
                    "source": "json",
                    "tab": tab if tab else "main"
                }
            )
        except Exception as e:
            print(f"⚠️  Ошибка при чтении JSON рейтинга: {e}")
            return JSONResponse(
                status_code=200,
                content={"rankings": [], "total": 0, "error": "Нет данных. Запустите бэктесты."}
            )
    try:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            where_clauses = ["is_active = TRUE"]
            params = []
            
            if min_trades > 0:
                where_clauses.append(f"median_total_trades >= %s")
                params.append(min_trades)
            
            if min_profit > -100:
                where_clauses.append(f"median_total_profit_pct >= %s")
                params.append(min_profit)
            
            if max_leverage and max_leverage.strip():
                try:
                    max_lev = int(max_leverage)
                    where_clauses.append(f"leverage <= %s")
                    params.append(max_lev)
                except ValueError:
                    pass  # Игнорируем невалидное значение
            
            if exclude_stalled:
                where_clauses.append("is_stalled = FALSE")
            
            if exclude_bias:
                where_clauses.append("has_lookahead_bias = FALSE")
            
            # Timeframe filter
            if timeframe and timeframe.strip():
                where_clauses.append("timeframe = %s")
                params.append(timeframe.strip())
            
            # Не фильтруем по leverage - показываем все (1x, 2x, 5x, 10x и т.д.)
            
            order_by = "DESC" if order.lower() == "desc" else "ASC"
            
            sql = f"""
                SELECT 
                    strategy_name, exchange, stake_currency,
                    total_backtests, median_total_trades, median_win_rate,
                    median_total_profit_pct, median_profit_factor,
                    median_max_drawdown, median_sharpe_ratio,
                    median_sortino_ratio, median_calmar_ratio,
                    backtest_win_percentage, ninja_score,
                    leverage, is_stalled, has_lookahead_bias,
                    updated_at
                FROM strategy_ratings
                WHERE {' AND '.join(where_clauses)}
                ORDER BY {sort_by} {order_by}
                LIMIT %s
            """
            params.append(limit)
            
            cur.execute(sql, params)
            results = cur.fetchall()
            
            rankings_list = []
            for r in results:
                row_dict = dict(r)
                # Конвертируем все значения в JSON-совместимые типы
                for key, value in row_dict.items():
                    if hasattr(value, 'isoformat'):  # datetime
                        row_dict[key] = value.isoformat()
                    elif value is None:
                        row_dict[key] = 0 if key in ['median_total_trades', 'total_backtests'] else None
                rankings_list.append(row_dict)
            
            return JSONResponse(
                status_code=200,
                content={
                    "rankings": rankings_list,
                    "total": len(rankings_list)
                }
            )
    except Exception as e:
        print(f"❌ Ошибка при получении рейтинга: {e}")
        import traceback
        traceback.print_exc()
        return JSONResponse(
            status_code=500,
            content={"rankings": [], "total": 0, "error": str(e)}
        )
    finally:
        if conn:
            return_db_connection(conn)

@app.post("/api/backtest/run")
async def run_backtest(request: BacktestRequest, background_tasks: BackgroundTasks):
    """Run backtest for strategy"""
    # Generate timerange if not provided
    if not request.timerange:
        # Используем правильный диапазон (прошлое, не будущее)
        end_date = (datetime.now() - timedelta(days=1)).strftime("%Y%m%d")  # Вчера
        start_date = (datetime.now() - timedelta(days=31)).strftime("%Y%m%d")  # 31 день назад
        timerange = f"{start_date}-{end_date}"
    else:
        timerange = request.timerange
    
    # Support for batch testing - if strategy_name is "all", test all strategies
    if request.strategy_name.lower() == "all":
        # Get all strategies automatically
        all_strategies = []
        for file in STRATEGIES_DIR.glob("*.py"):
            if file.name != "__init__.py" and not file.name.startswith("_"):
                all_strategies.append(file.stem)
        
        # Launch backtests for all strategies
        print(f"🚀 [{datetime.now().strftime('%H:%M:%S')}] Запрос на массовое тестирование:")
        print(f"   Количество стратегий: {len(all_strategies)}")
        print(f"   Пары: {request.pairs}")
        print(f"   Timeframe: {request.timeframe}, Timerange: {timerange}")
        
        for strategy in sorted(all_strategies):
            background_tasks.add_task(
                execute_backtest,
                strategy,
                request.pairs,
                timerange,
                request.timeframe,
                request.leverage,
                request.exchange,
                request.trading_type,
                request.deposit
            )
        
        return JSONResponse(
            status_code=200,
            content={
                "status": "started",
                "strategy": "all",
                "strategies_count": len(all_strategies),
                "strategies": sorted(all_strategies),
                "pairs": request.pairs,
                "timerange": timerange,
                "message": f"Backtests started for {len(all_strategies)} strategies in background"
            }
        )
    
    # Validate strategy exists
    strategy_file = STRATEGIES_DIR / f"{request.strategy_name}.py"
    if not strategy_file.exists():
        raise HTTPException(status_code=404, detail=f"Strategy {request.strategy_name} not found")
    
    # Логируем запуск
    print(f"🚀 [{datetime.now().strftime('%H:%M:%S')}] Запрос на запуск бэктеста:")
    print(f"   Стратегия: {request.strategy_name}")
    print(f"   Пары: {request.pairs}")
    print(f"   Timeframe: {request.timeframe}, Timerange: {timerange}")
    
    # Add to background tasks
    background_tasks.add_task(
        execute_backtest,
        request.strategy_name,
        request.pairs,
        timerange,
        request.timeframe,
        request.leverage,
        request.exchange,
        request.trading_type,
        request.deposit
    )
    
    return JSONResponse(
        status_code=200,
        content={
            "status": "started",
            "strategy": request.strategy_name,
            "pairs": request.pairs,
            "timerange": timerange,
            "message": "Backtest started in background"
        }
    )

async def execute_backtest(strategy_name: str, pairs: List[str], timerange: str, timeframe: str, leverage: int, exchange: str = "binance", trading_type: str = "spot", deposit: float = 1000):
    """
    Execute backtest with improved error handling and logging
    
    Args:
        strategy_name: Name of the strategy
        pairs: List of trading pairs
        timerange: Time range for backtest
        timeframe: Timeframe for candles
        leverage: Leverage to use
        exchange: Exchange name
        trading_type: Spot or futures
        deposit: Deposit amount for slippage calculation
    """
    logger.info(f"🔄 Запуск бэктеста для {strategy_name}...")
    """Execute backtest in background and update rankings automatically"""
    import sys
    import time
    import asyncio
    
    # Небольшая задержка чтобы убедиться что ответ отправлен
    await asyncio.sleep(1)
    
    sys.path.insert(0, str(FREQTRADE_DIR))
    
    # Записываем время начала
    start_time = datetime.now()
    log_file = FREQTRADE_DIR / f"backtest_{strategy_name}_{int(time.time())}.log"
    
    print(f"🔄 [{start_time.strftime('%H:%M:%S')}] === НАЧАЛО БЭКТЕСТА ===")
    print(f"   Стратегия: {strategy_name}")
    print(f"   Пары: {', '.join(pairs)}")
    print(f"   Timeframe: {timeframe}")
    print(f"   Timerange: {timerange}")
    print(f"   Лог файл: {log_file.name}")
    
    # Проверяем наличие данных и скачиваем если нужно
    # Пробуем сначала Binance (лучшие данные), потом Gate.io
    print(f"   Проверка данных...")
    
    # Приоритет бирж: Binance > Gate.io > KuCoin
    exchanges_to_try = ["binance", "gateio", "kucoin"]
    data_dir = None
    missing_pairs = []
    
    for exchange in exchanges_to_try:
        data_dir = FREQTRADE_DIR / "user_data" / "data" / exchange
        all_exist = True
        
        for pair in pairs:
            file_pair = pair.replace("/", "_")
            data_file = data_dir / f"{file_pair}-{timeframe}.json"
            if not data_file.exists():
                all_exist = False
                missing_pairs.append(pair)
        
        if all_exist and missing_pairs == []:
            print(f"   ✅ Данные найдены на {exchange}")
            break
        missing_pairs = []
    
    # Если данных нет, скачиваем с лучшей доступной биржи
    if missing_pairs or data_dir is None or not all_exist:
        print(f"   📥 Скачивание данных...")
        
        # Сначала пробуем Binance (лучшие данные)
        try:
            from multi_exchange_data_parser import download_and_save
            for pair in set(missing_pairs if missing_pairs else pairs):
                print(f"   📥 Скачивание {pair} с Binance...")
                exchange_used, file_path = download_and_save(pair, timeframe, days=30, exchange="binance")
                if file_path:
                    print(f"   ✅ {pair} скачан с {exchange_used}")
                    data_dir = FREQTRADE_DIR / "user_data" / "data" / exchange_used
        except Exception as e:
            print(f"   ⚠️  Прямое скачивание не удалось: {e}, используем Freqtrade...")
        
        # Fallback: используем Freqtrade downloader
        if missing_pairs:
            download_cmd = [
                "freqtrade", "download-data",
                "--exchange", "binance",  # Сначала пробуем Binance
                "--pairs", ",".join(set(missing_pairs if missing_pairs else pairs)),
                "--timeframes", timeframe,
                "--config", str(CONFIG_PATH),
                "--days", "30"
            ]
            download_result = subprocess.run(
                download_cmd,
                cwd=str(FREQTRADE_DIR),
                capture_output=True,
                text=True,
                timeout=300
            )
            if download_result.returncode == 0:
                print(f"   ✅ Данные скачаны с Binance")
                data_dir = FREQTRADE_DIR / "user_data" / "data" / "binance"
            else:
                # Fallback на Gate.io
                print(f"   ⚠️  Binance недоступен, пробуем Gate.io...")
                download_cmd[2] = "gateio"
                download_result = subprocess.run(
                    download_cmd,
                    cwd=str(FREQTRADE_DIR),
                    capture_output=True,
                    text=True,
                    timeout=300
                )
                if download_result.returncode == 0:
                    print(f"   ✅ Данные скачаны с Gate.io")
                    data_dir = FREQTRADE_DIR / "user_data" / "data" / "gateio"
                else:
                    print(f"   ⚠️  Ошибка скачивания данных: {download_result.stderr[:200]}")
    
    # Обновляем data_dir для использования в команде бэктеста
    if data_dir is None:
        data_dir = FREQTRADE_DIR / "user_data" / "data" / "binance"  # По умолчанию Binance
    
    # Используем --pairs напрямую, не через whitelist
    # Freqtrade будет использовать пары из --pairs даже если их нет в whitelist
    cmd = [
        "freqtrade", "backtesting",
        "--config", str(CONFIG_PATH),
        "--strategy", strategy_name,
        "--timerange", timerange,
        "--timeframe", timeframe,
        "--pairs", ",".join(pairs),
        "--export", "trades",
        "--breakdown", "month",
        "--cache", "none"
    ]
    
    # Добавляем переменную окружения для обхода проверки whitelist
    import os
    env = os.environ.copy()
    env['FREQTRADE_IGNORE_WHITELIST'] = '1'  # Временное решение
    
    try:
        print(f"🔄 [{start_time.strftime('%H:%M:%S')}] Запуск бэктеста для {strategy_name}...")
        print(f"   Пары: {', '.join(pairs)}")
        print(f"   Timeframe: {timeframe}, Timerange: {timerange}")
        print(f"   Команда: {' '.join(cmd)}")
        
        # Записываем команду в лог
        with open(log_file, 'w', encoding='utf-8') as f:
            f.write(f"Команда: {' '.join(cmd)}\n")
            f.write(f"Начало: {start_time.isoformat()}\n")
            f.write(f"Рабочая директория: {FREQTRADE_DIR}\n")
            f.write(f"Конфиг: {CONFIG_PATH}\n\n")
        
        # Запускаем бэктест
        print(f"   Выполнение команды...")
        
        result = subprocess.run(
            cmd,
            cwd=str(FREQTRADE_DIR),
            capture_output=True,
            text=True,
            timeout=600,  # 10 минут максимум
            env=env
        )
        
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()
        
        # Сохраняем вывод в лог
        with open(log_file, 'a', encoding='utf-8') as f:
            f.write(f"\nЗавершение: {end_time.isoformat()}\n")
            f.write(f"Длительность: {duration:.1f} секунд\n")
            f.write(f"Код возврата: {result.returncode}\n\n")
            f.write("STDOUT:\n")
            f.write(result.stdout)
            f.write("\n\nSTDERR:\n")
            f.write(result.stderr)
        
        if result.returncode == 0:
            print(f"✅ [{end_time.strftime('%H:%M:%S')}] Бэктест завершен для {strategy_name} за {duration:.1f}с")
            print(f"   Обновление рейтинга...")
            
            # Небольшая задержка для сохранения файлов
            time.sleep(2)
            
            # Пытаемся обновить PostgreSQL, если доступен
            try:
                from strategy_rating_system_postgresql import StrategyRatingSystemPostgreSQL
                rating_system = StrategyRatingSystemPostgreSQL()
                rating_system.process_and_save_to_db()
                print(f"✅ Рейтинг обновлен в PostgreSQL")
            except Exception as e:
                print(f"⚠️  PostgreSQL недоступен, используем standalone версию: {e}")
                # Используем standalone версию
                try:
                    from strategy_rating_system_standalone import StrategyRatingSystemStandalone
                    standalone = StrategyRatingSystemStandalone()
                    standalone.process_and_save()
                    print(f"✅ Рейтинг сохранен в JSON")
                except Exception as e2:
                    print(f"❌ Ошибка при сохранении рейтинга: {e2}")
                    import traceback
                    traceback.print_exc()
        else:
            print(f"❌ [{end_time.strftime('%H:%M:%S')}] Ошибка бэктеста для {strategy_name}")
            print(f"   Код: {result.returncode}")
            print(f"   Ошибка: {result.stderr[:500]}")
            print(f"   Лог: {log_file}")
        
    except subprocess.TimeoutExpired:
        print(f"⏱️  Бэктест для {strategy_name} превысил лимит времени (10 минут)")
    except Exception as e:
        print(f"❌ Error running backtest: {e}")
        import traceback
        traceback.print_exc()

@app.get("/api/backtest/history")
async def get_backtest_history(strategy_name: Optional[str] = None, limit: int = 50):
    """Get backtest history"""
    conn = get_db_connection()
    try:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            if strategy_name:
                cur.execute("""
                    SELECT * FROM backtest_results
                    WHERE strategy_name = %s
                    ORDER BY created_at DESC
                    LIMIT %s
                """, (strategy_name, limit))
            else:
                cur.execute("""
                    SELECT * FROM backtest_results
                    ORDER BY created_at DESC
                    LIMIT %s
                """, (limit,))
            
            results = cur.fetchall()
            return {"history": [dict(r) for r in results]}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        return_db_connection(conn)

@app.delete("/api/strategies/{strategy_name}")
async def delete_strategy(strategy_name: str):
    """Delete strategy and its backtests"""
    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            # Mark strategy as inactive
            cur.execute("""
                UPDATE strategy_ratings
                SET is_active = FALSE
                WHERE strategy_name = %s
            """, (strategy_name,))
            
            conn.commit()
            
            return {"status": "deleted", "strategy": strategy_name}
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        return_db_connection(conn)

@app.get("/api/backtest/status")
async def get_backtest_status():
    """Получить статус последних бэктестов"""
    try:
        zip_files = sorted(RESULTS_DIR.glob("*.zip"), key=lambda x: x.stat().st_mtime, reverse=True)
        statuses = []
        for zip_file in zip_files[:10]:
            mtime = datetime.fromtimestamp(zip_file.stat().st_mtime)
            statuses.append({
                "file": zip_file.name,
                "modified": mtime.isoformat(),
                "size": zip_file.stat().st_size,
                "age_seconds": (datetime.now() - mtime).total_seconds()
            })
        return JSONResponse(content={
            "recent_backtests": statuses,
            "total": len(zip_files)
        })
    except Exception as e:
        return JSONResponse(content={"error": str(e), "recent_backtests": [], "total": 0})

@app.get("/api/backtest/progress")
async def get_backtest_progress():
    """Получить прогресс текущих бэктестов"""
    try:
        import subprocess
        
        # Проверяем активные процессы
        processes = []
        try:
            result = subprocess.run(
                ["ps", "aux"],
                capture_output=True,
                text=True,
                timeout=2
            )
            for line in result.stdout.split('\n'):
                if 'freqtrade' in line and 'backtest' in line.lower():
                    parts = line.split()
                    if len(parts) > 1:
                        processes.append({
                            "pid": parts[1],
                            "command": ' '.join(parts[10:])[:100]
                        })
        except:
            pass
        
        # Проверяем последние логи
        log_files = sorted(FREQTRADE_DIR.glob("backtest_*.log"), key=lambda x: x.stat().st_mtime, reverse=True)
        recent_logs = []
        for log_file in log_files[:3]:
            mtime = datetime.fromtimestamp(log_file.stat().st_mtime)
            try:
                with open(log_file, 'r') as f:
                    content = f.read()
                    lines = content.split('\n')
                    recent_logs.append({
                        "file": log_file.name,
                        "modified": mtime.isoformat(),
                        "age_seconds": (datetime.now() - mtime).total_seconds(),
                        "last_lines": lines[-5:] if len(lines) > 5 else lines
                    })
            except:
                pass
        
        return JSONResponse(content={
            "active_processes": len(processes),
            "processes": processes,
            "recent_logs": recent_logs,
            "status": "running" if processes else "idle"
        })
    except Exception as e:
        return JSONResponse(content={"error": str(e), "status": "error"})

@app.get("/api/strategies/{strategy_name}/chart-data")
async def get_strategy_chart_data(strategy_name: str, pair: str = "BTC/USDT", 
                                  timeframe: str = "5m", limit: int = 500):
    """Get OHLCV data and trade points for chart visualization"""
    try:
        import zipfile
        import json
        import time
        from pathlib import Path
        from datetime import datetime
        
        # Find latest backtest for this strategy (more flexible search)
        zip_files = sorted(RESULTS_DIR.glob("*.zip"), 
                          key=lambda x: x.stat().st_mtime, reverse=True)
        
        # Filter by strategy name (case-insensitive, partial match)
        matching_zips = [z for z in zip_files if strategy_name.lower() in z.stem.lower()]
        
        if not matching_zips:
            # Return empty data instead of error
            return JSONResponse(content={
                "strategy_name": strategy_name,
                "pair": pair,
                "timeframe": timeframe,
                "ohlcv": [],
                "entry_points": [],
                "exit_points": [],
                "stop_loss_lines": [],
                "take_profit_lines": [],
                "total_trades": 0,
                "has_data": False,
                "message": "No backtest data found. Run backtest first."
            })
        
        # Extract OHLCV and trades from backtest
        ohlcv_data = []
        entry_points = []
        exit_points = []
        stop_loss_lines = []
        take_profit_lines = []
        
        with zipfile.ZipFile(matching_zips[0], 'r') as zip_ref:
            # Find all JSON files
            json_files = [f for f in zip_ref.namelist() if f.endswith('.json')]
            
            trades_data = []
            
            for json_file in json_files:
                try:
                    content = zip_ref.read(json_file)
                    data = json.loads(content)
                    
                    # Check if it's trades data (list of trades)
                    if isinstance(data, list) and len(data) > 0:
                        if isinstance(data[0], dict) and 'open_date' in data[0]:
                            trades_data = data
                            break
                    
                    # Check if it's strategy result (dict with strategy key)
                    if isinstance(data, dict):
                        if 'strategy' in data:
                            # Try to extract trades from strategy data
                            for strategy_name_key, strategy_info in data.get('strategy', {}).items():
                                if 'trades' in strategy_info and isinstance(strategy_info['trades'], list):
                                    trades_data = strategy_info['trades']
                                    break
                                # Also check for trade list directly in strategy_info
                                if isinstance(strategy_info, dict) and 'trades' in strategy_info:
                                    if isinstance(strategy_info['trades'], list):
                                        trades_data = strategy_info['trades']
                                        break
                        elif 'trades' in data and isinstance(data['trades'], list):
                            trades_data = data['trades']
                            break
                except Exception as e:
                    print(f"⚠️  Ошибка чтения {json_file}: {e}")
                    continue
            
            # Extract trade points
            if trades_data:
                for trade in trades_data[:limit]:
                    try:
                        # Entry point
                        if 'open_date' in trade and trade.get('open_date'):
                            open_date = trade['open_date']
                            # Convert to timestamp if needed
                            if isinstance(open_date, str):
                                try:
                                    # Try ISO format
                                    dt = datetime.fromisoformat(open_date.replace('Z', '+00:00'))
                                    open_timestamp = dt.timestamp()
                                except:
                                    try:
                                        # Try different format
                                        dt = datetime.strptime(open_date, '%Y-%m-%d %H:%M:%S')
                                        open_timestamp = dt.timestamp()
                                    except:
                                        open_timestamp = time.time()
                            else:
                                open_timestamp = float(open_date)
                            
                            entry_points.append({
                                'x': open_timestamp,
                                'y': float(trade.get('open_rate', 0)),
                                'trade_id': str(trade.get('trade_id', '')),
                                'profit_pct': float(trade.get('profit_pct', 0))
                            })
                            
                            # Stop-loss line
                            if 'stoploss' in trade and trade.get('stoploss'):
                                stop_price = float(trade.get('stoploss', 0))
                                close_date = trade.get('close_date', open_date)
                                if isinstance(close_date, str):
                                    try:
                                        dt = datetime.fromisoformat(close_date.replace('Z', '+00:00'))
                                        close_timestamp = dt.timestamp()
                                    except:
                                        try:
                                            dt = datetime.strptime(close_date, '%Y-%m-%d %H:%M:%S')
                                            close_timestamp = dt.timestamp()
                                        except:
                                            close_timestamp = open_timestamp + 3600
                                else:
                                    close_timestamp = float(close_date) if close_date else open_timestamp + 3600
                                
                                stop_loss_lines.append({
                                    'x': [open_timestamp, close_timestamp],
                                    'y': [stop_price, stop_price],
                                    'trade_id': str(trade.get('trade_id', ''))
                                })
                        
                        # Exit point
                        if 'close_date' in trade and trade.get('close_date'):
                            close_date = trade['close_date']
                            if isinstance(close_date, str):
                                try:
                                    dt = datetime.fromisoformat(close_date.replace('Z', '+00:00'))
                                    close_timestamp = dt.timestamp()
                                except:
                                    try:
                                        dt = datetime.strptime(close_date, '%Y-%m-%d %H:%M:%S')
                                        close_timestamp = dt.timestamp()
                                    except:
                                        continue
                            else:
                                close_timestamp = float(close_date)
                            
                            exit_points.append({
                                'x': close_timestamp,
                                'y': float(trade.get('close_rate', 0)),
                                'trade_id': str(trade.get('trade_id', '')),
                                'profit_pct': float(trade.get('profit_pct', 0)),
                                'profit_abs': float(trade.get('profit_abs', 0))
                            })
                    except Exception as e:
                        print(f"⚠️  Ошибка обработки сделки: {e}")
                        continue
        
        # Try to get OHLCV data from data directory
        data_dir = FREQTRADE_DIR / "user_data" / "data"
        file_pair = pair.replace("/", "_")
        data_file = None
        
        # Try different exchanges and timeframes
        for exchange in ["binance", "gateio", "kaiko", "coinapi", "kucoin"]:
            # Try exact timeframe first
            potential_file = data_dir / exchange / f"{file_pair}-{timeframe}.json"
            if potential_file.exists():
                data_file = potential_file
                break
            
            # Try 5m as fallback
            if timeframe != "5m":
                potential_file = data_dir / exchange / f"{file_pair}-5m.json"
                if potential_file.exists():
                    data_file = potential_file
                    break
        
        if data_file:
            try:
                with open(data_file, 'r') as f:
                    ohlcv_raw = json.load(f)
                    # Convert to chart format
                    for candle in ohlcv_raw[-limit:]:
                        try:
                            if isinstance(candle, list) and len(candle) >= 6:
                                ohlcv_data.append({
                                    'timestamp': float(candle[0]),
                                    'open': float(candle[1]),
                                    'high': float(candle[2]),
                                    'low': float(candle[3]),
                                    'close': float(candle[4]),
                                    'volume': float(candle[5])
                                })
                            elif isinstance(candle, dict):
                                ohlcv_data.append({
                                    'timestamp': float(candle.get('timestamp', candle.get('date', 0))),
                                    'open': float(candle.get('open', 0)),
                                    'high': float(candle.get('high', 0)),
                                    'low': float(candle.get('low', 0)),
                                    'close': float(candle.get('close', 0)),
                                    'volume': float(candle.get('volume', 0))
                                })
                        except Exception as e:
                            print(f"⚠️  Ошибка обработки свечи: {e}")
                            continue
            except Exception as e:
                print(f"⚠️  Ошибка чтения OHLCV файла: {e}")
        
        return JSONResponse(content={
            "strategy_name": strategy_name,
            "pair": pair,
            "timeframe": timeframe,
            "ohlcv": ohlcv_data,
            "entry_points": entry_points,
            "exit_points": exit_points,
            "stop_loss_lines": stop_loss_lines,
            "take_profit_lines": take_profit_lines,
            "total_trades": len(entry_points),
            "has_data": len(ohlcv_data) > 0 or len(entry_points) > 0
        })
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ Ошибка при получении данных графика: {e}")
        import traceback
        traceback.print_exc()
        return JSONResponse(
            status_code=200,
            content={
                "strategy_name": strategy_name,
                "pair": pair,
                "timeframe": timeframe,
                "ohlcv": [],
                "entry_points": [],
                "exit_points": [],
                "stop_loss_lines": [],
                "take_profit_lines": [],
                "total_trades": 0,
                "error": str(e),
                "has_data": False
            }
        )

@app.get("/api/strategies/{strategy_name}/details")
async def get_strategy_details(strategy_name: str):
    """Get detailed information about a specific strategy including monthly breakdown"""
    try:
        import sys
        sys.path.insert(0, str(FREQTRADE_DIR))
        from strategy_rating_system_standalone import StrategyRatingSystemStandalone
        from rating_web_interface_standalone import get_rankings_from_json
        import zipfile
        import json
        from pathlib import Path
        
        # Get strategy info from rankings
        rankings = get_rankings_from_json(limit=1000)
        strategy_info = next((r for r in rankings if r.get("strategy_name") == strategy_name), None)
        
        if not strategy_info:
            raise HTTPException(status_code=404, detail=f"Strategy {strategy_name} not found")
        
        # Get monthly breakdown from backtest results
        monthly_breakdown = []
        zip_files = sorted(RESULTS_DIR.glob(f"{strategy_name}_*.zip"), key=lambda x: x.stat().st_mtime, reverse=True)
        
        for zip_file in zip_files[:10]:  # Последние 10 бэктестов
            try:
                with zipfile.ZipFile(zip_file, 'r') as zip_ref:
                    # Ищем JSON файл в ZIP
                    json_files = [f for f in zip_ref.namelist() if f.endswith('.json') and 'strategy' in f.lower()]
                    if json_files:
                        json_content = zip_ref.read(json_files[0])
                        data = json.loads(json_content)
                        
                        # Извлекаем breakdown по месяцам
                        if 'strategy' in data and strategy_name in data['strategy']:
                            strategy_data = data['strategy'][strategy_name]
                            
                            # Проверяем разные варианты структуры breakdown
                            breakdown = None
                            if 'periodic_breakdown' in strategy_data:
                                # Freqtrade использует periodic_breakdown с ключом 'month'
                                periodic = strategy_data.get('periodic_breakdown', {})
                                if isinstance(periodic, dict) and 'month' in periodic:
                                    breakdown = periodic['month']
                            elif 'breakdown' in strategy_data:
                                breakdown = strategy_data['breakdown']
                            elif 'monthly_breakdown' in strategy_data:
                                breakdown = strategy_data['monthly_breakdown']
                            elif 'results' in strategy_data and 'breakdown' in strategy_data['results']:
                                breakdown = strategy_data['results']['breakdown']
                            
                            if breakdown:
                                # breakdown может быть dict или list
                                if isinstance(breakdown, dict):
                                    for month, month_data in breakdown.items():
                                        if isinstance(month_data, dict):
                                            monthly_breakdown.append({
                                                'month': month,
                                                'trades': month_data.get('trades', month_data.get('buys', 0)),
                                                'profit_pct': month_data.get('profit_pct', month_data.get('profit', 0)),
                                                'win_rate': month_data.get('win_rate', month_data.get('winp', 0)),
                                                'drawdown': month_data.get('drawdown', month_data.get('ddp', 0)),
                                                'sharpe': month_data.get('sharpe', month_data.get('sharpe_ratio', 0)),
                                                'cum_profit_pct': month_data.get('cum_profit_pct', 0),
                                                'backtest_file': zip_file.name
                                            })
                                elif isinstance(breakdown, list):
                                    # Freqtrade format: list of dicts with date keys
                                    for month_data in breakdown:
                                        if isinstance(month_data, dict):
                                            # Extract date from keys like 'date', 'period', 'month', or use index
                                            month_key = month_data.get('date', month_data.get('period', month_data.get('month', 'N/A')))
                                            # Format to YYYYMM if needed
                                            if isinstance(month_key, str) and len(month_key) >= 7:
                                                month_key = month_key[:7].replace('-', '')  # YYYY-MM -> YYYYMM
                                            
                                            monthly_breakdown.append({
                                                'month': month_key,
                                                'trades': month_data.get('trades', month_data.get('buys', month_data.get('trade_count', 0))),
                                                'profit_pct': month_data.get('profit_pct', month_data.get('profit', month_data.get('profit_total_pct', 0))),
                                                'win_rate': month_data.get('win_rate', month_data.get('winp', month_data.get('winrate', 0)) * 100 if month_data.get('winrate') else 0),
                                                'drawdown': abs(month_data.get('drawdown', month_data.get('ddp', month_data.get('max_drawdown', 0)))),
                                                'sharpe': month_data.get('sharpe', month_data.get('sharpe_ratio', month_data.get('sharpe', 0))),
                                                'cum_profit_pct': month_data.get('cum_profit_pct', month_data.get('profit_pct', 0)),
                                                'backtest_file': zip_file.name
                                            })
                            
                            # Если breakdown нет, пытаемся извлечь из trades
                            if not breakdown and 'trades' in strategy_data:
                                # Группируем трейды по месяцам
                                trades = strategy_data.get('trades', [])
                                if trades:
                                    from collections import defaultdict
                                    monthly_trades = defaultdict(list)
                                    for trade in trades:
                                        if 'close_date' in trade:
                                            from datetime import datetime
                                            try:
                                                close_date = datetime.fromisoformat(trade['close_date'].replace('Z', '+00:00'))
                                                month_key = close_date.strftime('%Y%m')
                                                monthly_trades[month_key].append(trade)
                                            except:
                                                pass
                                    
                                    # Вычисляем метрики по месяцам
                                    for month, month_trades in monthly_trades.items():
                                        if month_trades:
                                            wins = sum(1 for t in month_trades if t.get('profit_abs', 0) > 0)
                                            total_profit = sum(t.get('profit_abs', 0) for t in month_trades)
                                            total_profit_pct = sum(t.get('profit_pct', 0) for t in month_trades)
                                            
                                            monthly_breakdown.append({
                                                'month': month,
                                                'trades': len(month_trades),
                                                'profit_pct': total_profit_pct / len(month_trades) if month_trades else 0,
                                                'win_rate': (wins / len(month_trades) * 100) if month_trades else 0,
                                                'drawdown': 0,  # Нужно вычислить отдельно
                                                'sharpe': 0,  # Нужно вычислить отдельно
                                                'cum_profit_pct': total_profit_pct,
                                                'backtest_file': zip_file.name
                                            })
            except Exception as e:
                continue
        
        # Calculate strategy hash
        strategy_file = STRATEGIES_DIR / f"{strategy_name}.py"
        strategy_hash = None
        if strategy_file.exists():
            import hashlib
            with open(strategy_file, 'rb') as f:
                strategy_hash = hashlib.sha256(f.read()).hexdigest()
        
        # Extract indicators from strategy file
        indicators = []
        if strategy_file.exists():
            try:
                with open(strategy_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                    # Простой поиск индикаторов (можно улучшить)
                    import re
                    indicator_patterns = [
                        r"ta\.(\w+)\(",
                        r"qtpylib\.(\w+)\(",
                        r"ftt\.(\w+)\(",
                        r"dataframe\['(\w+)'\]",
                    ]
                    for pattern in indicator_patterns:
                        matches = re.findall(pattern, content)
                        indicators.extend(matches)
            except:
                pass
        
        return JSONResponse(content={
            "strategy_name": strategy_name,
            "strategy_info": strategy_info,
            "monthly_breakdown": sorted(monthly_breakdown, key=lambda x: x['month'], reverse=True),
            "hash": strategy_hash,
            "indicators": list(set(indicators))[:50],  # Уникальные индикаторы, максимум 50
            "timeframe": strategy_info.get("timeframe", "5m"),
            "stoploss": strategy_info.get("stoploss", -0.99)
        })
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ Ошибка при получении деталей стратегии: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/stats")
async def get_stats():
    """Get overall statistics (like strat.ninja stats page)"""
    conn = get_db_connection()
    if conn is None:
        # Fallback: используем standalone JSON версию
        try:
            import sys
            sys.path.insert(0, str(FREQTRADE_DIR))
            from strategy_rating_system_standalone import StrategyRatingSystemStandalone
            from rating_web_interface_standalone import get_rankings_from_json
            from strategy_rating_system_standalone import get_all_strategies
            
            rankings = get_rankings_from_json(limit=10000)
            all_strategies = get_all_strategies()
            
            # Подсчитываем статистику как на strat.ninja
            total_strategies = len(all_strategies)
            total_backtests = sum(r.get("total_backtests", 0) for r in rankings)
            
            # Подсчитываем проценты
            failed_count = len([r for r in rankings if r.get("is_stalled", False) or r.get("total_backtests", 0) == 0])
            lookahead_count = len([r for r in rankings if r.get("has_lookahead_bias", False)])
            stalled_count = len([r for r in rankings if r.get("is_stalled", False)])
            private_count = len([r for r in rankings if not r.get("strategy_url") or r.get("strategy_url") == ""])
            dca_count = len([r for r in rankings if r.get("is_dca", False)])
            multiclass_count = len([r for r in rankings if r.get("is_multiclass", False)])
            
            # Топ стратегия
            top_strategy = None
            if rankings:
                sorted_rankings = sorted(rankings, key=lambda x: x.get("ninja_score", 0), reverse=True)
                top = sorted_rankings[0]
                top_strategy = {
                    "strategy_name": top.get("strategy_name", ""),
                    "ninja_score": top.get("ninja_score", 0),
                    "median_total_profit_pct": top.get("median_total_profit_pct", 0)
                }
            
            # Последние бэктесты
            zip_files = sorted(RESULTS_DIR.glob("*.zip"), key=lambda x: x.stat().st_mtime, reverse=True)
            latest_backtests = [f.stem.replace('_', ' ') for f in zip_files[:10]]
            
            return JSONResponse(
                status_code=200,
                content={
                    "total_strategies": total_strategies,
                    "total_backtests": total_backtests,
                    "top_strategy": top_strategy,
                    "failed_testing_pct": round((failed_count / total_strategies * 100) if total_strategies > 0 else 0, 1),
                    "failed_count": failed_count,
                    "lookahead_pct": round((lookahead_count / total_strategies * 100) if total_strategies > 0 else 0, 1),
                    "lookahead_count": lookahead_count,
                    "stalled_pct": round((stalled_count / total_strategies * 100) if total_strategies > 0 else 0, 1),
                    "stalled_count": stalled_count,
                    "private_pct": round((private_count / total_strategies * 100) if total_strategies > 0 else 0, 1),
                    "private_count": private_count,
                    "dca_pct": round((dca_count / total_strategies * 100) if total_strategies > 0 else 0, 1),
                    "dca_count": dca_count,
                    "multiclass_pct": round((multiclass_count / total_strategies * 100) if total_strategies > 0 else 0, 1),
                    "multiclass_count": multiclass_count,
                    "latest_backtests": latest_backtests,
                    "source": "json"
                }
            )
        except Exception as e:
            print(f"⚠️  Ошибка при чтении статистики: {e}")
            return JSONResponse(
                status_code=200,
                content={
                    "total_strategies": 0,
                    "total_backtests": 0,
                    "top_strategy": None,
                    "error": "Нет данных. Запустите бэктесты."
                }
            )
    try:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            # Total strategies
            cur.execute("SELECT COUNT(*) as total FROM strategy_ratings WHERE is_active = TRUE")
            result = cur.fetchone()
            total_strategies = result["total"] if result else 0
            
            # Total backtests
            cur.execute("SELECT COUNT(*) as total FROM backtest_results")
            result = cur.fetchone()
            total_backtests = result["total"] if result else 0
            
            # Top strategy
            cur.execute("""
                SELECT strategy_name, ninja_score, median_total_profit_pct
                FROM strategy_ratings
                WHERE is_active = TRUE
                ORDER BY ninja_score DESC
                LIMIT 1
            """)
            top_result = cur.fetchone()
            top_strategy = None
            if top_result and cur.rowcount > 0:
                top_strategy = dict(top_result)
                # Конвертируем значения
                for key, value in top_strategy.items():
                    if hasattr(value, 'isoformat'):
                        top_strategy[key] = value.isoformat()
            
            return JSONResponse(
                status_code=200,
                content={
                    "total_strategies": int(total_strategies),
                    "total_backtests": int(total_backtests),
                    "top_strategy": top_strategy
                }
            )
    except Exception as e:
        print(f"❌ Ошибка при получении статистики: {e}")
        import traceback
        traceback.print_exc()
        return JSONResponse(
            status_code=200,
            content={
                "total_strategies": 0,
                "total_backtests": 0,
                "top_strategy": None,
                "error": str(e)
            }
        )
    finally:
        if conn:
            return_db_connection(conn)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8889)

