#!/usr/bin/env python3
"""
Интеграция результатов тестирования стратегий с Freqtrade Web UI
Создает результаты в формате, который Freqtrade может отобразить
"""

import json
import subprocess
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional
import pandas as pd

FREQTRADE_DIR = Path(__file__).parent
CONFIG_PATH = FREQTRADE_DIR.parent / "config" / "freqtrade_config.json"
STRATEGIES_DIR = FREQTRADE_DIR / "user_data" / "strategies"
RESULTS_DIR = FREQTRADE_DIR / "user_data" / "backtest_results"

END_DATE = datetime.now().strftime("%Y%m%d")
START_DATE = (datetime.now() - timedelta(days=30)).strftime("%Y%m%d")
TIMERANGE = f"{START_DATE}-{END_DATE}"
TIMEFRAME = "5m"
PAIR = "BTC/USDT"


def run_backtest_with_metadata(strategy_name: str) -> Optional[Dict]:
    """Запускает бэктест и создает метаданные для Freqtrade Web UI"""
    print(f"\n{'='*60}")
    print(f"🧪 {strategy_name} на {PAIR}")
    print(f"{'='*60}")
    
    # Создаем имя файла в формате Freqtrade
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    export_filename = f"backtest_results_{timestamp}"
    
    cmd = [
        "freqtrade", "backtesting",
        "--config", str(CONFIG_PATH),
        "--strategy", strategy_name,
        "--timerange", TIMERANGE,
        "--timeframe", TIMEFRAME,
        "--pairs", PAIR,
        "--export", "trades",
        "--export-filename", export_filename,
        "--breakdown", "month",
        "--cache", "none"
    ]
    
    try:
        result = subprocess.run(
            cmd,
            cwd=str(FREQTRADE_DIR),
            capture_output=True,
            text=True,
            timeout=300
        )
        
        if result.returncode != 0:
            print(f"❌ Ошибка")
            return None
        
        # Freqtrade автоматически создает JSON файл с метаданными
        # Формат: backtest_results_YYYYMMDD_HHMMSS.json
        json_file = RESULTS_DIR / f"{export_filename}.json"
        
        if json_file.exists():
            print(f"✅ Результаты сохранены: {json_file.name}")
            return {
                "strategy": strategy_name,
                "filename": json_file.name,
                "timestamp": timestamp,
                "pair": PAIR,
                "timerange": TIMERANGE,
                "timeframe": TIMEFRAME
            }
        else:
            print(f"⚠️  JSON файл не найден, но бэктест выполнен")
            return {
                "strategy": strategy_name,
                "filename": None,
                "timestamp": timestamp,
                "pair": PAIR,
                "timerange": TIMERANGE,
                "timeframe": TIMEFRAME
            }
            
    except Exception as e:
        print(f"❌ Ошибка: {e}")
        return None


def create_results_index(results: List[Dict]):
    """Создает индексный файл со ссылками на результаты"""
    index_file = RESULTS_DIR / "index.json"
    
    index_data = {
        "generated_at": datetime.now().isoformat(),
        "total_tests": len(results),
        "results": results,
        "web_ui_links": {
            "base_url": "http://127.0.0.1:8081",
            "backtesting_page": "http://127.0.0.1:8081/backtesting",
            "api_backtest": "http://127.0.0.1:8081/api/v1/backtest",
            "api_history": "http://127.0.0.1:8081/api/v1/backtest/history"
        }
    }
    
    with open(index_file, 'w') as f:
        json.dump(index_data, f, indent=2)
    
    print(f"\n📊 Индекс создан: {index_file}")
    return index_file


def generate_web_ui_instructions(results: List[Dict]):
    """Генерирует инструкции для просмотра в Web UI"""
    instructions = f"""
# 🌐 Как просмотреть результаты в Freqtrade Web UI

## Прямые ссылки:

### 1. Страница Backtesting (основная):
http://127.0.0.1:8081/backtesting

### 2. API для получения результатов:
"""
    
    for result in results:
        if result.get("filename"):
            instructions += f"""
**{result['strategy']}** ({result['pair']}):
- Файл: `{result['filename']}`
- API: http://127.0.0.1:8081/api/v1/backtest/history/result?filename={result['filename']}&strategy={result['strategy']}
"""
    
    instructions += """
## Как использовать:

1. **Откройте веб-интерфейс:**
   ```
   http://127.0.0.1:8081/backtesting
   ```

2. **Войдите:**
   - Логин: `freqtrader`
   - Пароль: см. `config/freqtrade_config.json`

3. **Результаты автоматически появятся в разделе Backtesting**

4. **Или используйте API напрямую:**
   ```bash
   curl -u freqtrader:PASSWORD \\
     http://127.0.0.1:8081/api/v1/backtest/history
   ```

## 📊 Статистика тестирования:
"""
    
    for result in results:
        instructions += f"- {result['strategy']}: {result['pair']} ({result['timerange']})\n"
    
    instructions_file = FREQTRADE_DIR / "WEB_UI_INSTRUCTIONS.md"
    with open(instructions_file, 'w') as f:
        f.write(instructions)
    
    print(f"📝 Инструкции сохранены: {instructions_file}")
    return instructions_file


def main():
    """Главная функция"""
    print("🚀 Интеграция результатов с Freqtrade Web UI")
    print(f"📅 Период: {TIMERANGE}")
    print(f"💰 Пара: {PAIR}\n")
    
    # Находим стратегии
    strategies = []
    for file in STRATEGIES_DIR.glob("*.py"):
        if file.name != "__init__.py" and not file.name.startswith("_"):
            strategy_name = file.stem
            if strategy_name != "TestStrategy":
                strategies.append(strategy_name)
    
    print(f"🔍 Найдено стратегий: {len(strategies)}")
    
    # Тестируем каждую стратегию
    results = []
    for strategy in strategies:
        result = run_backtest_with_metadata(strategy)
        if result:
            results.append(result)
    
    if results:
        # Создаем индекс
        index_file = create_results_index(results)
        
        # Генерируем инструкции
        instructions_file = generate_web_ui_instructions(results)
        
        print(f"\n{'='*60}")
        print("✅ Интеграция завершена!")
        print(f"{'='*60}")
        print(f"\n📊 Откройте результаты в веб-интерфейсе:")
        print(f"   http://127.0.0.1:8081/backtesting")
        print(f"\n📁 Индекс результатов: {index_file}")
        print(f"📝 Инструкции: {instructions_file}")
    else:
        print("❌ Нет результатов для интеграции")


if __name__ == "__main__":
    main()

