#!/bin/bash
# Скрипт для запуска freqtrade с веб-интерфейсом

cd "$(dirname "$0")"
source .venv/bin/activate

# Путь к конфигу (относительно freqtrade/)
CONFIG_PATH="../config/freqtrade_config.json"

echo "🚀 Запуск Freqtrade с веб-интерфейсом..."
echo "📊 Веб-интерфейс будет доступен по адресу: http://127.0.0.1:8081"
echo "👤 Логин: freqtrader / Пароль: (см. config/freqtrade_config.json)"
echo ""
echo "⚠️  Для остановки нажмите Ctrl+C"
echo ""

freqtrade trade --config "$CONFIG_PATH" "$@"

