#!/bin/bash
# Запуск сервера и автоматическое тестирование

cd "$(dirname "$0")"
source .venv/bin/activate

echo "🚀 Запуск сервера в фоне..."
python3 rating_api_server.py > /tmp/rating_server.log 2>&1 &
SERVER_PID=$!

echo "⏳ Ожидание запуска сервера..."
sleep 3

echo "🧪 Запуск тестов..."
python3 test_api_endpoints.py
TEST_RESULT=$?

echo ""
echo "📋 Логи сервера:"
tail -20 /tmp/rating_server.log

if [ $TEST_RESULT -eq 0 ]; then
    echo ""
    echo "✅ Все тесты прошли!"
    echo "🌐 Сервер работает на http://localhost:8889"
    echo "   PID: $SERVER_PID"
    echo ""
    echo "Для остановки: kill $SERVER_PID"
else
    echo ""
    echo "❌ Некоторые тесты не прошли"
    echo "Остановка сервера..."
    kill $SERVER_PID 2>/dev/null
fi

