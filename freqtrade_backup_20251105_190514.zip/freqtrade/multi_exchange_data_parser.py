#!/usr/bin/env python3
"""
Парсер данных с нескольких бирж (Binance, Gate.io, KuCoin и др.)
Поддержка автоматического выбора биржи с лучшими данными
"""

import requests
import json
import time
from pathlib import Path
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Tuple

# Поддерживаемые биржи в порядке приоритета (лучшие данные первыми)
SUPPORTED_EXCHANGES = [
    "binance",  # Лучшая ликвидность и история
    "kucoin",   # Хорошая история
    "gateio",   # Текущая биржа
    "okx",      # Альтернатива
    "bybit"     # Альтернатива
]

def download_from_binance(pair: str, timeframe: str, start_date: datetime, end_date: datetime) -> List[Dict]:
    """Скачать данные с Binance"""
    try:
        # Binance API не требует ключей для публичных данных
        base_url = "https://api.binance.com/api/v3/klines"
        
        # Преобразуем timeframe в формат Binance
        tf_map = {
            "1m": "1m", "3m": "3m", "5m": "5m", "15m": "15m",
            "30m": "30m", "1h": "1h", "2h": "2h", "4h": "4h",
            "6h": "6h", "8h": "8h", "12h": "12h", "1d": "1d"
        }
        binance_tf = tf_map.get(timeframe, "5m")
        
        # Преобразуем пару в формат Binance (BTC/USDT -> BTCUSDT)
        binance_pair = pair.replace("/", "").upper()
        
        candles = []
        current_start = start_date
        
        while current_start < end_date:
            # Binance ограничивает 1000 свечей за запрос
            params = {
                "symbol": binance_pair,
                "interval": binance_tf,
                "startTime": int(current_start.timestamp() * 1000),
                "limit": 1000
            }
            
            response = requests.get(base_url, params=params, timeout=10)
            if response.status_code != 200:
                print(f"⚠️  Binance API error: {response.status_code}")
                break
            
            data = response.json()
            if not data:
                break
            
            for candle in data:
                candles.append({
                    "timestamp": candle[0] / 1000,  # Binance возвращает в миллисекундах
                    "open": float(candle[1]),
                    "high": float(candle[2]),
                    "low": float(candle[3]),
                    "close": float(candle[4]),
                    "volume": float(candle[5])
                })
            
            # Следующая итерация начинается с последней свечи
            if len(data) < 1000:
                break
            current_start = datetime.fromtimestamp(data[-1][0] / 1000) + timedelta(seconds=1)
            time.sleep(0.2)  # Rate limiting
        
        print(f"✅ Binance: скачано {len(candles)} свечей для {pair}")
        return candles
    except Exception as e:
        print(f"❌ Ошибка при скачивании с Binance: {e}")
        return []

def download_from_gateio(pair: str, timeframe: str, start_date: datetime, end_date: datetime) -> List[Dict]:
    """Скачать данные с Gate.io (используем существующую логику)"""
    try:
        from gateio_data_parser import download_candles
        return download_candles(pair, timeframe, start_date, end_date)
    except Exception as e:
        print(f"❌ Ошибка при скачивании с Gate.io: {e}")
        return []

def download_best_available(pair: str, timeframe: str, days: int = 30, preferred_exchange: Optional[str] = None) -> Tuple[List[Dict], str]:
    """
    Скачать данные с лучшей доступной биржи
    
    Returns:
        (candles, exchange_name)
    """
    end_date = datetime.now()
    start_date = end_date - timedelta(days=days)
    
    # Если указана предпочтительная биржа, пробуем её первой
    exchanges_to_try = []
    if preferred_exchange:
        exchanges_to_try.append(preferred_exchange.lower())
    
    # Добавляем остальные биржи в порядке приоритета
    for exch in SUPPORTED_EXCHANGES:
        if exch not in exchanges_to_try:
            exchanges_to_try.append(exch)
    
    last_error = None
    for exchange in exchanges_to_try:
        try:
            print(f"🔄 Попытка скачать с {exchange}...")
            
            if exchange == "binance":
                candles = download_from_binance(pair, timeframe, start_date, end_date)
            elif exchange == "gateio":
                candles = download_from_gateio(pair, timeframe, start_date, end_date)
            else:
                # Для других бирж используем Freqtrade
                candles = []
            
            if candles and len(candles) > 0:
                print(f"✅ Успешно скачано с {exchange}: {len(candles)} свечей")
                return candles, exchange
            
        except Exception as e:
            last_error = e
            print(f"⚠️  {exchange} недоступна: {e}")
            continue
    
    # Если все биржи недоступны, пробуем через Freqtrade
    print(f"⚠️  Все прямые API недоступны, используем Freqtrade...")
    return [], "gateio"  # Fallback на текущую настройку

def save_to_freqtrade_format(candles: List[Dict], pair: str, timeframe: str, exchange: str, output_dir: Path):
    """Сохранить данные в формате Freqtrade"""
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Формат имени файла: BTC_USDT-5m.json
    file_pair = pair.replace("/", "_")
    filename = output_dir / f"{file_pair}-{timeframe}.json"
    
    # Конвертируем в формат Freqtrade
    freqtrade_data = []
    for candle in candles:
        freqtrade_data.append([
            int(candle["timestamp"] * 1000),  # timestamp в миллисекундах
            candle["open"],
            candle["high"],
            candle["low"],
            candle["close"],
            candle["volume"]
        ])
    
    # Сохраняем
    with open(filename, 'w') as f:
        json.dump(freqtrade_data, f)
    
    print(f"✅ Данные сохранены: {filename} ({len(freqtrade_data)} свечей)")
    return filename

def download_and_save(pair: str, timeframe: str, days: int = 30, exchange: Optional[str] = None, output_dir: Optional[Path] = None):
    """
    Скачать и сохранить данные для пары
    
    Args:
        pair: Торговая пара (например, "BTC/USDT")
        timeframe: Таймфрейм (например, "5m")
        days: Количество дней истории
        exchange: Предпочтительная биржа (None = автоматический выбор)
        output_dir: Директория для сохранения (None = стандартная Freqtrade)
    
    Returns:
        (exchange_used, file_path)
    """
    if output_dir is None:
        freqtrade_dir = Path(__file__).parent
        output_dir = freqtrade_dir / "user_data" / "data" / (exchange or "binance")
    
    # Скачиваем данные
    candles, exchange_used = download_best_available(pair, timeframe, days, exchange)
    
    if not candles:
        print(f"❌ Не удалось скачать данные для {pair}")
        return None, None
    
    # Сохраняем
    file_path = save_to_freqtrade_format(candles, pair, timeframe, exchange_used, output_dir)
    
    return exchange_used, file_path

if __name__ == "__main__":
    # Тест
    print("🧪 Тестирование мультибиржевого парсера...")
    
    # Тест с Binance (лучшие данные)
    exchange, file = download_and_save("BTC/USDT", "5m", days=30, exchange="binance")
    print(f"Результат: биржа={exchange}, файл={file}")


