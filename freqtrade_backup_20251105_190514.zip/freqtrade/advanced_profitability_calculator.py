#!/usr/bin/env python3
"""
Расширенный калькулятор доходности с учетом:
- Кешбека по рефералке (Binance 30%, Bybit 40%, Gate.io 50%/60%)
- Проскальзываний в зависимости от депозита
- Спредов
- Комиссий спот/фьючерсы
- Разных плеч
- Доходности для клиента и реферера
"""

from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from enum import Enum
import math

class Exchange(Enum):
    BINANCE = "binance"
    BYBIT = "bybit"
    GATEIO = "gateio"

class TradingType(Enum):
    SPOT = "spot"
    FUTURES = "futures"

@dataclass
class ExchangeConfig:
    """Конфигурация биржи"""
    name: Exchange
    spot_fee_maker: float  # Комиссия maker для спота
    spot_fee_taker: float  # Комиссия taker для спота
    futures_fee_maker: float  # Комиссия maker для фьючерсов
    futures_fee_taker: float  # Комиссия taker для фьючерсов
    rebate_spot: float  # Кешбек для спота (0.5 = 50%)
    rebate_futures: float  # Кешбек для фьючерсов (0.6 = 60%)
    spread_bps: float  # Спред в базисных пунктах (0.1 = 0.1%)
    referral_rebate: float  # Кешбек для реферера (0.3 = 30%)

# Конфигурации бирж
EXCHANGE_CONFIGS = {
    Exchange.BINANCE: ExchangeConfig(
        name=Exchange.BINANCE,
        spot_fee_maker=0.001,  # 0.1%
        spot_fee_taker=0.001,  # 0.1%
        futures_fee_maker=0.0002,  # 0.02%
        futures_fee_taker=0.0004,  # 0.04%
        rebate_spot=0.30,  # 30% кешбек
        rebate_futures=0.30,  # 30% кешбек
        spread_bps=0.05,  # 0.05% спред
        referral_rebate=0.30  # 30% для реферера
    ),
    Exchange.BYBIT: ExchangeConfig(
        name=Exchange.BYBIT,
        spot_fee_maker=0.001,  # 0.1%
        spot_fee_taker=0.001,  # 0.1%
        futures_fee_maker=0.0001,  # 0.01%
        futures_fee_taker=0.0006,  # 0.06%
        rebate_spot=0.40,  # 40% кешбек
        rebate_futures=0.40,  # 40% кешбек
        spread_bps=0.08,  # 0.08% спред
        referral_rebate=0.40  # 40% для реферера
    ),
    Exchange.GATEIO: ExchangeConfig(
        name=Exchange.GATEIO,
        spot_fee_maker=0.002,  # 0.2%
        spot_fee_taker=0.002,  # 0.2%
        futures_fee_maker=0.0002,  # 0.02%
        futures_fee_taker=0.0005,  # 0.05%
        rebate_spot=0.50,  # 50% кешбек
        rebate_futures=0.60,  # 60% кешбек
        spread_bps=0.10,  # 0.1% спред
        referral_rebate=0.50  # 50% для реферера (спот)
    )
}

# Проскальзывание в зависимости от депозита (в базисных пунктах)
SLIPPAGE_BY_DEPOSIT = {
    200: 5.0,      # 0.5% для депозита $200
    500: 3.0,      # 0.3% для депозита $500
    1000: 2.0,     # 0.2% для депозита $1000
    10000: 1.0,    # 0.1% для депозита $10000
    100000: 0.5,   # 0.05% для депозита $100000
}

# Доступные плечи
AVAILABLE_LEVERAGES = [1, 3, 5, 10, 50, 100, 125]

class ProfitabilityCalculator:
    """Калькулятор доходности с учетом всех факторов"""
    
    def __init__(self, exchange: Exchange, trading_type: TradingType, 
                 leverage: int = 1, deposit: float = 1000):
        self.exchange = exchange
        self.trading_type = trading_type
        self.leverage = leverage
        self.deposit = deposit
        self.config = EXCHANGE_CONFIGS[exchange]
        
        # Определяем проскальзывание
        self.slippage_bps = self._calculate_slippage(deposit)
        
    def _calculate_slippage(self, deposit: float) -> float:
        """Рассчитать проскальзывание в зависимости от депозита"""
        # Находим ближайший депозит из таблицы
        closest_deposit = min(SLIPPAGE_BY_DEPOSIT.keys(), 
                             key=lambda x: abs(x - deposit))
        base_slippage = SLIPPAGE_BY_DEPOSIT[closest_deposit]
        
        # При увеличении депозита проскальзывание уменьшается логарифмически
        if deposit > closest_deposit:
            ratio = deposit / closest_deposit
            # Логарифмическое уменьшение
            reduction = math.log10(ratio) * 0.1
            slippage = max(base_slippage * (1 - reduction), 0.1)
        else:
            slippage = base_slippage
        
        return slippage
    
    def calculate_fees(self, trade_amount: float, is_maker: bool = True) -> Dict[str, float]:
        """Рассчитать комиссии для сделки"""
        if self.trading_type == TradingType.SPOT:
            fee_rate = self.config.spot_fee_maker if is_maker else self.config.spot_fee_taker
            rebate = self.config.rebate_spot
        else:
            fee_rate = self.config.futures_fee_maker if is_maker else self.config.futures_fee_taker
            rebate = self.config.rebate_futures
        
        # Базовая комиссия
        base_fee = trade_amount * fee_rate
        
        # Кешбек для клиента
        client_rebate = base_fee * rebate
        client_fee = base_fee - client_rebate
        
        # Кешбек для реферера (комиссия реферера)
        referrer_rebate = base_fee * self.config.referral_rebate
        
        return {
            "base_fee": base_fee,
            "client_fee": client_fee,
            "client_rebate": client_rebate,
            "referrer_rebate": referrer_rebate,
            "total_cost": client_fee + (self.slippage_bps / 10000) * trade_amount + (self.config.spread_bps / 10000) * trade_amount
        }
    
    def calculate_trade_cost(self, trade_amount: float, is_maker: bool = True) -> Dict[str, float]:
        """Рассчитать полную стоимость сделки"""
        fees = self.calculate_fees(trade_amount, is_maker)
        
        # Проскальзывание
        slippage_cost = trade_amount * (self.slippage_bps / 10000)
        
        # Спред
        spread_cost = trade_amount * (self.config.spread_bps / 10000)
        
        # Общая стоимость
        total_cost = fees["client_fee"] + slippage_cost + spread_cost
        
        return {
            **fees,
            "slippage_cost": slippage_cost,
            "slippage_bps": self.slippage_bps,
            "spread_cost": spread_cost,
            "spread_bps": self.config.spread_bps,
            "total_cost": total_cost,
            "total_cost_pct": (total_cost / trade_amount) * 100
        }
    
    def calculate_profitability(self, trades: List[Dict], 
                                is_referrer: bool = False) -> Dict[str, float]:
        """
        Рассчитать доходность с учетом всех факторов
        
        Args:
            trades: Список сделок с полями:
                - profit_pct: Прибыль в процентах
                - trade_amount: Сумма сделки
                - is_maker: Является ли сделка maker
            is_referrer: Рассчитывать для реферера или клиента
        
        Returns:
            Словарь с метриками доходности
        """
        total_profit = 0
        total_fees = 0
        total_rebates = 0
        total_slippage = 0
        total_spread = 0
        total_cost = 0
        total_trades = len(trades)
        
        for trade in trades:
            trade_amount = trade.get("trade_amount", 1000)
            profit_pct = trade.get("profit_pct", 0)
            is_maker = trade.get("is_maker", True)
            
            # Прибыль от сделки
            gross_profit = trade_amount * (profit_pct / 100)
            
            # Стоимость сделки
            costs = self.calculate_trade_cost(trade_amount, is_maker)
            
            # Чистая прибыль
            if is_referrer:
                # Для реферера: кешбек от комиссий
                net_profit = costs["referrer_rebate"]
            else:
                # Для клиента: прибыль минус все расходы
                net_profit = gross_profit - costs["total_cost"]
            
            total_profit += gross_profit
            total_fees += costs["client_fee"]
            total_rebates += costs["client_rebate"]
            total_slippage += costs["slippage_cost"]
            total_spread += costs["spread_cost"]
            total_cost += costs["total_cost"]
        
        # С учетом плеча (для фьючерсов)
        if self.trading_type == TradingType.FUTURES and self.leverage > 1:
            # Прибыль/убыток умножается на плечо
            leverage_multiplier = self.leverage
            total_profit *= leverage_multiplier
            total_cost *= leverage_multiplier  # Комиссии тоже умножаются
            net_profit = total_profit - total_cost
        else:
            net_profit = total_profit - total_cost
        
        # ROI
        roi_pct = (net_profit / self.deposit) * 100 if self.deposit > 0 else 0
        
        return {
            "total_profit": total_profit,
            "gross_profit": total_profit,
            "total_fees": total_fees,
            "total_rebates": total_rebates,
            "total_slippage": total_slippage,
            "total_spread": total_spread,
            "total_cost": total_cost,
            "net_profit": net_profit,
            "roi_pct": roi_pct,
            "total_trades": total_trades,
            "avg_cost_per_trade": total_cost / total_trades if total_trades > 0 else 0,
            "profit_after_all_costs": net_profit,
            "is_referrer": is_referrer
        }

def compare_exchanges(trades: List[Dict], deposit: float = 1000, 
                     leverage: int = 1, trading_type: TradingType = TradingType.SPOT) -> Dict:
    """Сравнить доходность на разных биржах"""
    results = {}
    
    for exchange in Exchange:
        calc = ProfitabilityCalculator(exchange, trading_type, leverage, deposit)
        
        # Для клиента
        client_result = calc.calculate_profitability(trades, is_referrer=False)
        
        # Для реферера
        referrer_result = calc.calculate_profitability(trades, is_referrer=True)
        
        results[exchange.value] = {
            "client": client_result,
            "referrer": referrer_result,
            "config": {
                "rebate_spot": calc.config.rebate_spot,
                "rebate_futures": calc.config.rebate_futures,
                "slippage_bps": calc.slippage_bps,
                "spread_bps": calc.config.spread_bps,
                "referral_rebate": calc.config.referral_rebate
            }
        }
    
    return results

def calculate_optimal_strategy(trades: List[Dict], deposit: float = 1000) -> Dict:
    """Найти оптимальную комбинацию биржи, типа торговли и плеча"""
    best_result = None
    best_config = None
    
    for exchange in Exchange:
        for trading_type in TradingType:
            for leverage in AVAILABLE_LEVERAGES:
                if trading_type == TradingType.SPOT and leverage > 1:
                    continue  # Спот без плеча
                
                calc = ProfitabilityCalculator(exchange, trading_type, leverage, deposit)
                result = calc.calculate_profitability(trades, is_referrer=False)
                
                if best_result is None or result["roi_pct"] > best_result["roi_pct"]:
                    best_result = result
                    best_config = {
                        "exchange": exchange.value,
                        "trading_type": trading_type.value,
                        "leverage": leverage,
                        "deposit": deposit
                    }
    
    return {
        "best_config": best_config,
        "best_result": best_result,
        "all_comparisons": compare_exchanges(trades, deposit, 
                                            best_config["leverage"] if best_config else 1,
                                            TradingType(best_config["trading_type"]) if best_config else TradingType.SPOT)
    }

if __name__ == "__main__":
    # Тест
    print("🧪 Тестирование калькулятора доходности...")
    
    # Пример сделок
    test_trades = [
        {"profit_pct": 2.0, "trade_amount": 1000, "is_maker": True},
        {"profit_pct": -1.0, "trade_amount": 1000, "is_maker": False},
        {"profit_pct": 3.0, "trade_amount": 1000, "is_maker": True},
    ]
    
    # Сравнение бирж для спота
    print("\n📊 Сравнение бирж (Spot, депозит $1000):")
    spot_comparison = compare_exchanges(test_trades, deposit=1000, leverage=1, trading_type=TradingType.SPOT)
    for exchange, data in spot_comparison.items():
        print(f"\n{exchange.upper()}:")
        print(f"  Клиент ROI: {data['client']['roi_pct']:.2f}%")
        print(f"  Реферер кешбек: ${data['referrer']['net_profit']:.2f}")
        print(f"  Проскальзывание: {data['config']['slippage_bps']:.2f} bps")
        print(f"  Спред: {data['config']['spread_bps']:.2f} bps")
    
    # Сравнение для фьючерсов
    print("\n📊 Сравнение бирж (Futures, плечо 10x, депозит $1000):")
    futures_comparison = compare_exchanges(test_trades, deposit=1000, leverage=10, trading_type=TradingType.FUTURES)
    for exchange, data in futures_comparison.items():
        print(f"\n{exchange.upper()}:")
        print(f"  Клиент ROI: {data['client']['roi_pct']:.2f}%")
        print(f"  Реферер кешбек: ${data['referrer']['net_profit']:.2f}")


