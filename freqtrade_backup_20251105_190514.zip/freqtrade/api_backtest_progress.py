#!/usr/bin/env python3
"""
API для отслеживания прогресса бэктестов
"""

from pathlib import Path
from datetime import datetime
from fastapi import APIRouter
import json

router = APIRouter()

RESULTS_DIR = Path(__file__).parent / "user_data" / "backtest_results"
FREQTRADE_DIR = Path(__file__).parent

@router.get("/api/backtest/progress")
async def get_backtest_progress():
    """Получить прогресс текущих бэктестов"""
    try:
        # Проверяем активные процессы
        import subprocess
        processes = []
        
        try:
            result = subprocess.run(
                ["ps", "aux"],
                capture_output=True,
                text=True,
                timeout=2
            )
            for line in result.stdout.split('\n'):
                if 'freqtrade' in line and 'backtest' in line.lower():
                    processes.append({
                        "pid": line.split()[1] if len(line.split()) > 1 else "unknown",
                        "command": line[:100]
                    })
        except:
            pass
        
        # Проверяем последние результаты
        zip_files = sorted(RESULTS_DIR.glob("*.zip"), key=lambda x: x.stat().st_mtime, reverse=True)
        recent_results = []
        for zip_file in zip_files[:5]:
            mtime = datetime.fromtimestamp(zip_file.stat().st_mtime)
            recent_results.append({
                "file": zip_file.name,
                "modified": mtime.isoformat(),
                "age_seconds": (datetime.now() - mtime).total_seconds()
            })
        
        # Проверяем логи
        log_files = sorted(FREQTRADE_DIR.glob("backtest_*.log"), key=lambda x: x.stat().st_mtime, reverse=True)
        recent_logs = []
        for log_file in log_files[:3]:
            mtime = datetime.fromtimestamp(log_file.stat().st_mtime)
            try:
                with open(log_file, 'r') as f:
                    content = f.read()
                    recent_logs.append({
                        "file": log_file.name,
                        "modified": mtime.isoformat(),
                        "size": len(content),
                        "last_line": content.split('\n')[-2] if len(content.split('\n')) > 1 else ""
                    })
            except:
                pass
        
        return {
            "active_processes": len(processes),
            "processes": processes,
            "recent_results": recent_results,
            "recent_logs": recent_logs,
            "status": "running" if processes else "idle"
        }
    except Exception as e:
        return {"error": str(e), "status": "error"}

